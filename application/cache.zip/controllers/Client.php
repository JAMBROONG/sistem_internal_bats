<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {
	public function __construct(){
        parent:: __construct();
		if ($this->session->userdata('status') != "login") {
            redirect('Login');
        }
		if ($this->session->userdata('status_id') == 4) {
			redirect('Employee');
		}	
		if ($this->session->userdata('status_id') == 3) {
			redirect('SuperAdmin');
		}
		if ($this->session->userdata('status_id') == 5) {
			redirect('Administrasi');
		}
		if ($this->session->userdata('status_id') == 2) {
			redirect('Admin');
		}
		if ( time() - $this->session->userdata('last_login_time') > 43200) {
            $id = $this->session->userdata('key');
            $data['logout'] = date("Y-m-d H:i:s");
            $this->M_table->updateTable('history_login',$data,array('login' =>$id));
            redirect('Logout');
        }
		$_SESSION['last_login_time'] = time();
    }
	public function index(){
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
        $data['news']       = $this->M_table->getAll('news order by create_date desc');
        $data['serv']       = $this->M_table->getServRecommendation($id);
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_dashboard',$data);
		} else{
			$this->load->view('client/v_dashboard',$data);
		}
	}

	// ==================== PROFILE ====================

	public function profile(){
		$id                       = $this->session->userdata('id');
        $data['user']             = $this->M_user->profile($id);
        $data['dataUser']         = $this->M_user->profile($id);
		$data['country']			= $this->M_table->getAll('country');
		$data['total_login']          = count($this->M_user->getLogin($id));

		
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_profile',$data);
		} else{
			$this->load->view('client/v_profile',$data);
		}

	}
	public function _do_upload_client() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/client/";
        $config["allowed_types"]                = "jpg|png|jpeg";
        $config["max_size"]                     = 1000;
        $config["max_widht"]                    = 1500;
        $config["max_height"]                   = 1500;
        $config["file_name"]                    = $image_name;

        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
	public function updateProfile(){
		$id                     = $this->session->userdata('id');
		$data['name']           = addslashes($this->input->post('name'));
		$data['phone']          = addslashes($this->input->post('phone'));
		$data['address']        = addslashes($this->input->post('address'));
		$data['NPWP']    = addslashes($this->input->post('NPWP'));
		$data['NIK']    = addslashes($this->input->post('NIK'));
		$data['position']    = addslashes($this->input->post('position'));
		$data['nationality']    = addslashes($this->input->post('nationality'));

		if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_client();
            $upload                             = $this->M_table->getById("user", $id);
            if (file_exists("assets/upload/images/client/" . $upload["image"]) && $upload["image"]) {
                unlink("assets/upload/images/client/" . $upload["image"]);
            }
            $data["image"]                      = $image;
        }
		$data ['update_date']   = date("Y-m-d H:i:s");
        $this->M_table->updateTable('user',$data,array('id' =>$id));
		
		redirect('Client/profile');
	}

	// ==================== FEEDBACK ====================

	public function feedback(){
		$id                     = $this->session->userdata('id');
        $data['user']           = $this->M_user->profile($id);
		$order_id					= $this->input->post('id_order');
		
		$data['validate2'] = "true";

		if ($order_id == "") {
			$order_id = $this->uri->rsegment(3);
		}
		if ($order_id == "" && $this->uri->rsegment(3)=="") {
			$order_id                   = $this->M_table->orderId($id);
			if (empty($order_id)) {
				$data['validate2'] = "false";
				if ($this->session->userdata('from') == 2) {
					return $this->load->view('clientAHR/v_feedback',$data);
				} else{
					return $this->load->view('client/v_feedback',$data);
				}
			}
			else{
			$order_id    = $order_id[0]['id'];
			}
		}

		$data['selected']             = $this->M_table->getOrder($order_id);
		$data['criteria']             = $this->M_user->getCriteria('criteria');
		$data['dataOrder']            = $this->M_table->dataOrder2($id);
		$data['staff']                = $this->M_table->getDataStaff($order_id);
		$data['staff2']               = $this->M_user->getStaffFromFeedback($order_id);
		$data['validate']             = $this->M_table->totalDataTableWhere('feedback','order_id',$order_id .' AND categoryFeedback_id = 2');
		$data['dataFeedbackC'] 		  = $this->M_user->companyFeedback($order_id);
        $data['dataFeedback']   	  = $this->M_user->dataFeedback($id,$order_id);
		
				
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_feedback',$data);
		} else{
			$this->load->view('client/v_feedback',$data);
		}
	}
	public function processCreateFeedback(){
		$total = $this->input->post('total');
		$bantu = [];
		$rat   = [];
		for ($i=1; $i <= $total ; $i++) {
			$rating = "rating".$i;
			$number = $this->input->post($rating);
			array_push($bantu,$number);
		}
		$forCriteria['order_id']              = addslashes($this->input->post('order_id'));
		$forCriteria['employee_id']           = addslashes($this->input->post('employee_id'));
		$forCriteria ['update_date']          = date("Y-m-d H:i:s");
        $forCriteria ['create_date']    	  = date("Y-m-d H:i:s");
		foreach ($bantu as $row) {
			$forCriteria['rating']		=substr($row,0,strlen($row)-(strlen($row)-1));
			array_push($rat,$forCriteria['rating']);
			$forCriteria['criteria_id'] = substr($row,1);
			$this->M_table->createTable('feedback_criteria',$forCriteria);
		}
		$data['user_id']                = $this->session->userdata('id');
		$data['feedback']               = addslashes($this->input->post('feedback'));
		$data['star']                   = array_sum($rat)/count($bantu);
		$data['employee_id']            = addslashes($this->input->post('employee_id'));
		$data['categoryFeedback_id']    = addslashes($this->input->post('categoryFeedback_id'));
		$data['order_id']    			= addslashes($this->input->post('order_id'));
		$data ['update_date']           = date("Y-m-d H:i:s");
        $data ['create_date']     		= date("Y-m-d H:i:s");
        $this->M_table->createTable('feedback',$data);
		redirect('Client/feedback/'.$data['order_id']);
	}
	public function processCreateFeedbackC()
	{
		$data['user_id']              = $this->session->userdata('id');
		$data['order_id']             = addslashes($this->input->post('order_id'));
		$data['star']             = addslashes($this->input->post('rating'));
		$data['feedback']             = addslashes($this->input->post('feedback'));
		$data['categoryFeedback_id']  = addslashes($this->input->post('categoryFeedback_id'));
		$data['update_date']          = date("Y-m-d H:i:s");
        $data['create_date']    	  = date("Y-m-d H:i:s");
		// print_r($data);
		// exit();
        $this->M_table->createTable('feedback',$data);
		redirect('Client/feedback/'.$data['order_id']);

	}
	public function detailFeedback(){
		$feedback_id                    = $this->uri->rsegment(3);
        $data['user']           		= $this->M_user->profile($this->session->userdata('id'));
		if ($feedback_id=="") {
			redirect('Client/lock');
		}
		else{
			if(is_numeric($feedback_id)){
				if ($this->M_table->totalByCon('feedback','id', $feedback_id)==0) {
					redirect('Client/lock');
				}
				else{
					$data['validate'] = true;
					$data['dataFeedback'] 			= $this->M_user->detailFeedback($feedback_id);
					$data['dataFeedback2'] = $this->M_employee->getFeedback($data['dataFeedback']['order_id'],$data['dataFeedback']['employee_id']);
					$data['dataCriteria'] = $this->M_employee->getCriteria($data['dataFeedback']['order_id'],$data['dataFeedback']['employee_id']);
				}
				if ($this->session->userdata('from') == 2) {
					$this->load->view('clientAHR/v_detailFeedback',$data);
				} else{
					$this->load->view('client/v_detailFeedback',$data);
				}
			}
			else{
				redirect('Client/lock');
			}
		}
	}

	// ============ PASSWORD ============

	public function updatePassword()
	{
		$id                   = $this->session->userdata('id');
        $data['user']   	  = $this->M_user->profile($id);
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_updatePassword',$data);
		} else{
			$this->load->view('client/v_updatePassword',$data);
		}
	}
	public function processUpdatePassword()
	{
		$data['password']          	= md5($this->input->post('password'));
		$data ['update_date']   	= date("Y-m-d H:i:s");
        $this->M_table->updateTable('user',$data,array('id' =>$this->session->userdata('id')));
		redirect('Client/profile');
	}

	// ============ TYPE OF DATA ============

	public function typeOfData()
	{
		$data2                    = $this->M_table->getByCon('order','user_id',$this->session->userdata('id'));
		$order_id                 = $this->input->post('id_order');
		$id                       = $this->session->userdata('id');
        $data['user']       	  = $this->M_user->profile($id);
		$data['dataOrder']        = $this->M_table->dataOrder2($id);
		
		if ($order_id == "") {
			$order_id                = $this->M_table->orderId($id);
			if (empty($order_id)) {
			}
			else{
			$data['selected']        = $order_id[0];
			}
		}
		else{
			$data['selected']     = $this->M_table->getOrder($order_id);
		}
		if (empty($data2)) {
			if ($this->session->userdata('from') == 2) {
				$this->load->view('clientAHR/v_typeOfData',$data);
			} else{
				$this->load->view('client/v_typeOfData',$data);
			}
		}
		else{
			$id                       = $data2['service_id'];
			
			$data['dataOrder2']   = $this->M_table->getDataOrder($data['selected']['id']);
			$data['dataStaff']   = $this->M_table->getDataStaff($data['selected']['id']);
			$data['step']       	  = $this->M_table->getFlow($data['selected']['id']);
			$data['substep']       	  = $this->M_table->getSubFlow($data['selected']['id']);
			$data["person"]             = $this->M_user->person($data['selected']['id']);
			$data["pic"]    			   = $this->M_table->dataTableWhere('person_in_charge','order_id',$data['selected']['id']);
			if ($this->session->userdata('from') == 2) {
				$this->load->view('clientAHR/v_typeOfData',$data);
			} else{
				$this->load->view('client/v_typeOfData',$data);
			}
		}
	}
	public function desc()
	{
		$id                       = $this->session->userdata('id');
        $data['dataUser']       	  = $this->M_user->profile($id);
		$employee_id = $this->input->post('employee_id');
        $data['user']       = $this->M_employee->getEmployee($employee_id);
        $data["resume"]                         = $this->M_employee->getResume($employee_id);
        $data["sub_resume"]                     = $this->M_employee->getSubResume($employee_id);
        $data["sr"]                             = $this->M_table->getAll('sub_resume');
        $data["scr"]                            = $this->M_table->getAll('sub_category_resume');
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_desc',$data);
		} else{
			$this->load->view('client/v_desc',$data);
		}
	}

	// ============ OUR SERVICES ============

	public function ourServices()
	{
		$id                   = $this->session->userdata('id');
        $data['user']   	  = $this->M_user->profile($id);
		$data['dataProject']  = $this->M_table->getAll('services');
		$data['youServices']   = [];
		foreach ($this->M_table->dataTableWhere('order','user_id',$id) as $row) {
			 array_push($data['youServices'],$row['service_id']);
		}
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_ourServices',$data);
		} else{
			$this->load->view('client/v_ourServices',$data);
		}
		
	}

	// ============ JOB TRACK ============

	public function jobTrack()
	{
		$id                         = $this->session->userdata('id');
        $data['user']         		= $this->M_user->profile($id);
		$order_id					= $this->input->post('id_order');
		$data['condition'] = "true";
		
		if ($order_id == "" && $this->uri->rsegment(3) == "") {
			$order_id                   = $this->M_table->orderId($id);
			if (empty($order_id)) {
				if ($this->session->userdata('from') == 2) {
					return $this->load->view('clientAHR/v_jobTrack',$data);
				} else{
					return $this->load->view('client/v_jobTrack',$data);
				}
			}
			else{
			$order_id    = $order_id[0];
			}
		}
		else{
			if ($order_id == "") {
				if (is_numeric($this->uri->rsegment(3))) {
					if ($this->M_table->totalByCon("order", "id", $this->uri->rsegment(3)) == 0) {
						$data['condition'] = "false";
						if ($this->session->userdata('from') == 2) {
							return $this->load->view('clientAHR/v_jobTrack',$data);
						} else{
							return $this->load->view('client/v_jobTrack',$data);
						}
					}
					$order_id = $this->uri->rsegment(3);
					$order_id = $this->M_table->getOrder($order_id);
				}
				else{
					redirect('Client/lock');
				}
				
			}
			else{
				$order_id = $this->M_table->getOrder($order_id);
			}
		}
		
		$data['selectedService']    = $order_id; //service now
		$data['idOrder']            = $order_id['id']; //id order
		$data['dataOrder']         = $this->M_table->dataOrder($id);
		$data['dataOrder2']         = $this->M_table->dataOrder2($id);
		$data['dataOrder3']         = $this->M_table->dataOrder3($id);
		
        $data['user']         		= $this->M_user->profile($id);
		$data['letter']             = $this->M_table->letter($order_id['id']);
		$data['dataProcess']        = $this->M_table->getProcess($order_id['id']);
		$data['conOutput']          = false;
		$data["review"]             = $this->M_table->getReview($order_id['id']);
		$data['report']             = $this->M_table->getReport($order_id['id']);
		
		$data["dataMeeting"]            = $this->M_table->getAllMeeting($order_id['id']);
		
		// percentage input
		$total 						= count($data['letter']);
		$done						= count($this->M_table->percenLetter($order_id['id'],'done'));
		$data['percentinput'] 		= round(((20)/$total)*$done,1);
		$data['percentInputNow']    = round(($done/$total)*100,0);

		// percentage progress
		$total                		= count($this->M_table->getSubFlow($order_id['id']));
		if ($total == 0) {
			$total = 1;
		}
		$data['total']        		= $total;
		$done                 		= count($this->M_table->getProcessDone($order_id['id']));
		$data['totalDone']   		= $done;
		
		$data['percentProgressNow']    = round(($done/$total)*100,0);
		if ($total == 0) {
			if ($done == 0) {
				$data['percentprocess'] = round(60,1);
			}
			else{
				$data['percentprocess'] = round(60*$done,1);
			}
		}
		else{
			$data['percentprocess'] = round((60/$total)*$done,1);
		}

		// percentage output
		$outputDone = $this->M_table->getReport($order_id['id']);
		$outputDone = count($outputDone);
		$data['percentoutput'] = (20)/$total;
		$data['percentoutput'] = round($data['percentoutput'] * $outputDone,1);
		$data['conOutput'] = true;
		

		// percentage all
		$data['percentall'] 		= $data['percentinput'] + $data['percentprocess']  +  $data['percentoutput'];

		$data['chatt']              = $this->M_table->chatt($order_id['id']);
		if ($this->session->userdata('from') == 2) {
			return $this->load->view('clientAHR/v_jobTrack',$data);
		} else{
			return $this->load->view('client/v_jobTrack',$data);
		}
	}
	public function addChatt()
	{
		$serviceNow             = $this->uri->rsegment(4);
		$data['user_id']        = $this->session->userdata('id');
		$data['order_id']       = str_replace("'", "", $this->uri->rsegment(3));
		$order_id               = str_replace("'", "", $this->uri->rsegment(3));
		$data['chatt']          = str_replace("'", "", $this->input->post('chatt'));
		$data['create_date']    = date("Y-m-d H:i:s");
        $this->M_table->createTable('chatt',$data);
		redirect('Client/jobTrack/'.$order_id.'/'.$serviceNow);
	}
	public function updateMeeting() {
        $id = str_replace("'", "", $this->input->post("id"));
        $data['via'] = str_replace("'", "", $this->input->post("via"));
        $data['link'] = str_replace("'", "", $this->input->post("link"));
        $data['update_date'] = date('Y-m-d H:i:s');
        $order_id = str_replace("'", "", $this->input->post("order_id"));
        $data['date'] = str_replace("'", "", $this->input->post("date")).' '.str_replace("'", "", $this->input->post("time"));
        $this->M_table->updateTable("meeting", $data, ["id" => $id]);
        redirect('Client/jobtrack/'.$order_id);
    }
	public function updateReview() {
        $id = str_replace("'", "", $this->input->post("report_id"));
        $data['message'] = str_replace("'", "", $this->input->post("message"));
        $this->M_table->updateTable("report_review", $data, ["report_id" => $id]);
        redirect('Client/detailReport/'.$id);
    }
	
	// ============ REPORT ============

	public function report()
	{
		$id                         = $this->session->userdata('id');
        $data['user']         		= $this->M_user->profile($id);
		$order_id                 = $this->input->post('id_order');
		$data['dataOrder']        = $this->M_table->dataOrder2($id);
		
		$data['validate'] = "true";
		if ($order_id == "") {
			$order_id                = $this->M_table->orderId($id);
			if (empty($order_id)) {
				$data['validate'] = "false";
				if ($this->session->userdata('from') == 2) {
					return $this->load->view('clientAHR/v_report',$data);
				} else{
					return $this->load->view('client/v_report',$data);
				}
			}
			else{
			$order_id        = $order_id[0]['id'];
			}
		}
		$data['selected']    	 = $this->M_table->getOrder($order_id);
		$data['report']             = $this->M_table->getReport($order_id);
		if ($this->session->userdata('from') == 2) {
			return $this->load->view('clientAHR/v_report',$data);
		} else{
			return $this->load->view('client/v_report',$data);
		}

	}
	public function detailReport()
	{
		
		$id                         = $this->session->userdata('id');
        $data['user']         		= $this->M_user->profile($id);

		$report_id = $this->uri->rsegment(3);
		if ($report_id=="") {
			redirect('Client/lock');
		}
		else{
			if(is_numeric($report_id)){
				if ($this->M_table->totalByCon('process_report','id', $report_id)==0) {
					redirect('Client/lock');
				}
				else{
					$data['validate'] = true;
					$data["dataReport"] = $this->M_table->detailReport($report_id);
                    $data["review"] = $this->M_user->getReview($report_id);
				}
				if ($this->session->userdata('from') == 2) {
					return $this->load->view('clientAHR/v_detailReport',$data);
				} else{
					return $this->load->view('client/v_detailReport',$data);
				}
			}
			else{
				redirect('Client/lock');
			}
		}
	}
	public function approveReport() {
        $review_id                    	= $this->uri->rsegment(3);
		if ($review_id=="" || $this->uri->rsegment(4) == "") {
			redirect('Client/lock');
		}
		else{
			if(is_numeric($review_id) || is_numeric($this->uri->rsegment(4))){
				if ($this->M_table->totalByCon('report_review','id', $review_id)==0) {
					redirect('Client/lock');
				}
				if ($this->M_table->getById('report_review',$review_id)['review_status'] == "do") {
					$data['review_status'] = "done";
				} else{
					$data['review_status'] = "do";
				}
				$this->M_table->updateTable("report_review", $data, ["id" => $review_id]);
				redirect('Client/jobtrack/'.$this->uri->rsegment(4));
			}
			else{
				redirect('Client/lock');
			}
		}
    }

	// ================== News ====================

	public function deN(){
		$news_id                    	= $this->uri->rsegment(3);
        $data['user']           		= $this->M_user->profile($this->session->userdata('id'));
		if ($news_id=="") {
			redirect('Client/lock');
		}
		else{
			if(is_numeric($news_id)){
				if ($this->M_table->totalByCon('news','id', $news_id)==0) {
					redirect('Client/lock');
				}
				else{
					$data['dataNews'] 			= $this->M_table->getById('news',$news_id);
				}
				if ($this->session->userdata('from') == 2) {
					return $this->load->view('clientAHR/v_detailNews',$data);
				} else{
					return $this->load->view('client/v_detailNews',$data);
				}
			}
			else{
				redirect('Client/lock');
			}
		}
	}
	public function daN(){
        $data['user']   = $this->M_user->profile($this->session->userdata('id'));
		$data['news']  = $this->M_table->getAll('news order by create_date desc');
		if ($this->session->userdata('from') == 2) {
			return $this->load->view('clientAHR/v_allNews',$data);
		} else{
			return $this->load->view('client/v_allNews',$data);
		}
	}

	public function deR(){
		$r_id                    	= $this->uri->rsegment(3);
        $data['user']           		= $this->M_user->profile($this->session->userdata('id'));
		if ($r_id=="") {
			redirect('Client/lock');
		}
		else{
			if(is_numeric($r_id)){
				$data['sr'] 			= $this->M_table->getServRecommendationById($this->session->userdata('id'),$r_id);
				if ($this->session->userdata('from') == 2) {
					return $this->load->view('clientAHR/v_detailServ',$data);
				} else{
					return $this->load->view('client/v_detailServ',$data);
				}
			}
			else{
				redirect('Client/lock');
			}
		}
	}

	// ================== SCURITY ====================

	public function lock()
	{
			$id = $this->session->userdata('key');
			$data['logout'] = date("Y-m-d H:i:s");
			$this->M_table->updateTable('history_login',$data,array('login' =>$id));
			$this->session->sess_destroy();
			$this->load->view('v_anonymous');
	}

	// ================== WHATSNEW ====================

	public function whatsNew()
	{
        $data['user']           		= $this->M_user->profile($this->session->userdata('id'));
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_whatsNew',$data);
		} else{
			$this->load->view('client/v_whatsNew',$data);
		}
	}

	// ================= CONTRACT =====================

	public function contract(){
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
        $data["dataOrder"]                      = $this->M_table->dataOrder2($id);
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_contract',$data);
		} else{
			$this->load->view('client/v_contract',$data);
		}
	}
	public function detailContract(){
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
		$order_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($order_id)) {
                if ($this->M_table->totalByCon("order", "id", $order_id) == 0) {
                    redirect("Client/Lock");
                } else {
					$data["dataContract"] = $this->M_administrasi->getContract($order_id);
					$data['order_id'] = $order_id;
                }
				
				if ($this->session->userdata('from') == 2) {
					$this->load->view("clientAHR/v_detailContract", $data);
				} else{
					$this->load->view("client/v_detailContract", $data);
				}
				
            } else {
                redirect("Client/lock");
            }
        }
	}
	public function receiveFile()
	{
		$contract_id       	= str_replace("'", "", $this->uri->rsegment(3));
        if ($contract_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($contract_id)) {
                if ($this->M_table->totalByCon("employment_contract","id", $contract_id) == 0) {
                    redirect("Client/Lock");
				}
				if ($this->M_table->getById('employment_contract',$contract_id)['receive_hardfile'] == "no") {
					$data['receive_hardfile'] = "yes";
					$data['receive_date'] = date("Y-m-d H:i:s");
				} else{
					$data['receive_hardfile'] = "no";
					$data['receive_date'] = NULL;
				}
				$this->M_table->updateTable("employment_contract", $data, ["id" => $contract_id]);
				redirect('Client/detailContract/'.$this->M_table->getById('employment_contract',$contract_id)['order_id']);
            } else {
                redirect("Client/lock");
            }
        }
	}
	public function turnFix()
	{
		$contract_id       	= str_replace("'", "", $this->uri->rsegment(3));
        if ($contract_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($contract_id)) {
                if ($this->M_table->totalByCon("employment_contract","id", $contract_id) == 0) {
                    redirect("Client/Lock");
				}
				if ($this->M_table->getById('employment_contract',$contract_id)['status'] == "do") {
					$data['status'] = "done";
				} else{
					$data['status'] = "do";
				}
				$this->M_table->updateTable("employment_contract", $data, ["id" => $contract_id]);
				redirect('Client/detailContract/'.$this->M_table->getById('employment_contract',$contract_id)['order_id']);
            } else {
                redirect("Client/lock");
            }
        }
	}
	public function _do_upload_contract() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/doc/";
        $config["allowed_types"]                = "pdf|jpg|png|jpeg|xlsx|doc|odt";
        $config["max_size"]                     = 10000;
        $config["max_widht"]                    = 15000;
        $config["max_height"]                   = 15000;
        $config["file_name"]                    = $image_name;
        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
	public function processCreateContract()
	{
		$data                                   = [
		"message" => str_replace("'", "", $this->input->post("message")),
		"filename" => str_replace("'", "", $this->input->post("filename")),
		"from" => 'client',
		"order_id" => str_replace("'", "", $this->input->post("order_id"))
	];
	if (!empty($_FILES["image"]["name"])) {
		$image                              = $this->_do_upload_contract();
		$data["softfile"]                     = $image;
	}
	$this->M_table->createTable("employment_contract", $data);
	redirect("Client/detailContract/" . str_replace("'", "", $this->input->post("order_id")));
	}
	public function updateStatusFile()
	{
		$contract_id       	= str_replace("'", "", $this->uri->rsegment(3));
        if ($contract_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($contract_id)) {
                if ($this->M_table->totalByCon("employment_contract","id", $contract_id) == 0) {
                    redirect("Client/Lock");
				}
				if ($this->M_table->getById('employment_contract',$contract_id)['sent_hardfile'] == "no") {
					$data['sent_hardfile'] = "yes";
					$data['sent_date'] = date("Y-m-d H:i:s");
				} else{
					$data['sent_hardfile'] = "no";
					$data['sent_date'] = NULL;
				}
				$this->M_table->updateTable("employment_contract", $data, ["id" => $contract_id]);
				redirect('Client/detailContract/'.$this->M_table->getById('employment_contract',$contract_id)['order_id']);
            } else {
                redirect("Client/lock");
            }
        }
	}
	public function deleteFile()
	{
		$id                                     = str_replace("'", "", $this->uri->rsegment(3));
        $data                                   = $this->M_table->getById("employment_contract", $id);
        if (file_exists("assets/upload/doc/" . $data["softfile"]) && $data["softfile"]) {
            unlink("assets/upload/doc/" . $data["softfile"]);
        }
        $this->M_table->deleteTable("employment_contract", $id);
		redirect('Client/detailContract/'.str_replace("'", "", $this->uri->rsegment(4)));
		# code...
	}
	public function deleteFileOnly()
	{
		$id                                     = str_replace("'", "", $this->uri->rsegment(3));
        $data                                   = $this->M_table->getById("employment_contract", $id);
        if (file_exists("assets/upload/doc/" . $data["softfile"]) && $data["softfile"]) {
            unlink("assets/upload/doc/" . $data["softfile"]);
        }
		$data["softfile"]                      = "";
		$this->M_table->updateTable("employment_contract", $data, ["id" => $id]);
		redirect('Client/detailContract/'.str_replace("'", "", $this->uri->rsegment(4)));
	}
	// =========== INVOICE ============

	public function invoice()
	{
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
        $data["dataOrder"]                      = $this->M_table->dataOrder2($id);
		
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_invoice',$data);
		} else{
			$this->load->view('client/v_invoice',$data);
		}
	}
	public function detailInvoice()
	{
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
		$order_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($order_id)) {
                if ($this->M_table->totalByCon("order", "id", $order_id) == 0) {
                    redirect("Client/Lock");
                } else {
					$data["dataInvoice"] = $this->M_administrasi->getInvoice($order_id);
					$data["dataFile"] = $this->M_table->dataTableWhere('proof_of_payment','order_id',$order_id);
					$data['order_id'] = $order_id;
                }
				if ($this->session->userdata('from') == 2) {
					$this->load->view("clientAHR/v_detailInvoice", $data);
				} else{
					$this->load->view("client/v_detailInvoice", $data);
				}
            } else {
                redirect("Client/lock");
            }
        }
	}
	public function updateStatusInvoice()
	{
		$contract_id       	= str_replace("'", "", $this->uri->rsegment(3));
        if ($contract_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($contract_id)) {
                if ($this->M_table->totalByCon("invoice","id", $contract_id) == 0) {
                    redirect("Client/Lock");
				}
				if ($this->M_table->getById('invoice',$contract_id)['receive_hardfile'] == "no") {
					$data['receive_hardfile'] = "yes";
					$data['receive_date'] = date("Y-m-d H:i:s");
				} else{
					$data['receive_hardfile'] = "no";
					$data['receive_date'] = NULL;
				}
				$this->M_table->updateTable("invoice", $data, ["id" => $contract_id]);
				redirect('Client/detailInvoice/'.$this->M_table->getById('invoice',$contract_id)['order_id']);
            } else {
                redirect("Client/lock");
            }
        }
	}
	
    public function deleteInvoiceOnly()
	{
		$id                                     = str_replace("'", "", $this->uri->rsegment(3));
        $data                                   = $this->M_table->getById("invoice", $id);
        if (file_exists("assets/upload/invoice/" . $data["softfile"]) && $data["softfile"]) {
            unlink("assets/upload/invoice/". $data["softfile"]);
        }
		$data["softfile"]                      = "";
		$this->M_table->updateTable("invoice", $data, ["id" => $id]);
		redirect('Client/detailInvoice/'.str_replace("'", "", $this->uri->rsegment(4)));
	}
	public function turnFixInvoice()
	{
		$invoice_id       	= str_replace("'", "", $this->uri->rsegment(3));
        if ($invoice_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($invoice_id)) {
                if ($this->M_table->totalByCon("invoice","id", $invoice_id) == 0) {
                    redirect("Client/Lock");
				}
				if ($this->M_table->getById('invoice',$invoice_id)['status'] == "do") {
					$data['status'] = "done";
				} else{
					$data['status'] = "do";
				}
				$this->M_table->updateTable("invoice", $data, ["id" => $invoice_id]);
				redirect('Client/detailInvoice/'.$this->M_table->getById('invoice',$invoice_id)['order_id']);
            } else {
                redirect("Client/lock");
            }
        }
	}

	// =========== FILES ============

	public function file()
	{
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
        $data["dataOrder"]                      = $this->M_table->dataOrder2($id);
		
		if ($this->session->userdata('from') == 2) {
			$this->load->view('clientAHR/v_file',$data);
		} else{
			$this->load->view('client/v_file',$data);
		}
	}
	public function detailFile()
	{
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_user->profile($id);
		$order_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("Client/Lock");
        } else {
            if (is_numeric($order_id)) {
                if ($this->M_table->totalByCon("order", "id", $order_id) == 0) {
                    redirect("Client/Lock");
                } else {
					$data["dataFile"] = $this->M_administrasi->getFile($order_id);
					$data['order_id'] = $order_id;
                }
				if ($this->session->userdata('from') == 2) {
					$this->load->view("clientAHR/v_detailFile", $data);
				} else{
					$this->load->view("client/v_detailFile", $data);
				}
            } else {
                redirect("Client/lock");
            }
        }
	}
	public function addFile()
	{
		$data                                   = [
		"link" => str_replace("'", "", $this->input->post("link")),
		"description" => str_replace("'", "", $this->input->post("description")),
		"order_id" => str_replace("'", "", $this->input->post("order_id")),
		"filename" => str_replace("'", "", $this->input->post("filename")),
		"create_date" => date("Y-m-d H:i:s"),
		"update_date" => date("Y-m-d H:i:s")
	];
	$this->M_table->createTable("client_file", $data);
	redirect("Client/detailFile/" . str_replace("'", "", $this->input->post("order_id")));
	}
	public function updateClientFile()
	{
		$data                                   = [
		"link" => str_replace("'", "", $this->input->post("link")),
		"description" => str_replace("'", "", $this->input->post("description")),
		"filename" => str_replace("'", "", $this->input->post("filename")),
		"update_date" => date("Y-m-d H:i:s")
	];
	$this->M_table->updateTable('client_file',$data,array('id' =>  str_replace("'", "", $this->input->post("file_id"))));
	redirect("Client/detailFile/" . str_replace("'", "", $this->input->post("order_id")));
	}
	public function deleteClientFile()
	{
        $this->M_table->deleteTable("client_file", str_replace("'", "", $this->input->post("file_id")));
		redirect("Client/detailFile/" . str_replace("'", "", $this->input->post("order_id")));
	}

	public function processCreatePayment()
	{
		$data                                   = [
		"message" => str_replace("'", "", $this->input->post("message")),
		"filename" => str_replace("'", "", $this->input->post("filename")),
		"order_id" => str_replace("'", "", $this->input->post("order_id")),
		"create_date" => date("Y-m-d H:i:s")
	];
	if (!empty($_FILES["image"]["name"])) {
		$image                              = $this->_do_upload_contract();
		$data["softfile"]                     = $image;
	}
	$this->M_table->createTable("proof_of_payment", $data);
	redirect("Client/detailInvoice/" . str_replace("'", "", $this->input->post("order_id")));
	}

}
