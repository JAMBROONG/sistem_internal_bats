<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {
	public function __construct(){
        parent:: __construct();
		if ($this->session->userdata('status') != "login") {
            redirect('Login');
        }
		if ($this->session->userdata('status_id') == 3) {
			redirect('SuperAdmin');
		}
		if ($this->session->userdata('status_id') == 5) {
			redirect('Administrasi');
		}	
		if ($this->session->userdata('status_id') == 2) {
			redirect('Admin');
		}
        if ($this->session->userdata('status_id') == 1) {
			redirect('Client');
		}
		if ( time() - $this->session->userdata('last_login_time') > 43200) {
			$id = $this->session->userdata('key');
			$data['logout_date'] = date("Y-m-d H:i:s");
			$this->M_table->updateTable('history_login_employee',$data,array('login_date' =>$id));
            redirect('Logout/logoutEmployee');
        }
		$_SESSION['last_login_time'] = time();
    }
	public function index()
	{
		$id                 = $this->session->userdata('id');
        $data['user']       = $this->M_employee->getEmployee($id);
        $data['order']      = $this->M_employee->totalOrder($id);
        $data['history']    = $this->M_employee->totalTable('history_action_employee','employee_id',$id);
        $data['report']     = $this->M_employee->totalReport($id);
        $data['feedback']   = $this->M_employee->totalFeedback($id);
        $data['deadline']   = $this->M_employee->processDeadline($id);
        $data['orderDo']   = $this->M_table->totalStatusOrder(1,$id);
        $data['orderDone']   = $this->M_table->totalStatusOrder(2,$id);
        $data['orderCancel']   = $this->M_table->totalStatusOrder(3,$id);
        $data['orderAll']   = $data['orderDo'] + $data['orderDone'] + $data['orderCancel'] ;

		$this->load->view('employee/v_dashboard',$data);
	}

	// =========== profile ============

	public function profile()
	{
		$id                   = $this->session->userdata('id');
        $data['user']         = $this->M_employee->getEmployee($id);
        $data["resume"]       = $this->M_employee->getResume($id);
        $data["sub_resume"]   = $this->M_employee->getSubResume($id);
        $data["sr"]           = $this->M_table->getAll('sub_resume');
        $data["scr"]          = $this->M_table->getAll('sub_category_resume');
		$this->load->view('employee/v_profile',$data);
	}

	public function processUpdateProfile()
	{
		$id				        	= $this->session->userdata('id');
		$data = array(
            'employee_name' =>  str_replace("'", "", $this->input->post('employee_name')),
            'phone' =>  str_replace("'", "", $this->input->post('phone')),
            'gender' =>  str_replace("'", "", $this->input->post('gender')),
            'position' =>  str_replace("'", "", $this->input->post('position')),
            'address' =>  str_replace("'", "", $this->input->post('address')),
            'date_of_birth' =>  str_replace("'", "", $this->input->post('date_of_birth')),
			'update_date' => date("Y-m-d H:i:s")
        );
        if (!empty($_FILES['image']['name'])) {
            $image = $this->_do_upload_employee();
			
			$upload = $this->M_table->getById('employee', $id);
            if (file_exists('assets/upload/images/employee/'.$upload['image']) && $upload['image']) {
                unlink('assets/upload/images/employee/'.$upload['image']);
            }
			$data['image'] = $image;
        }

		$action = array(
            'employee_id' =>  $id,
			'action' => "Update profile ",
			'update_date' => date("Y-m-d H:i:s")
        );
		$this->M_table->createTable("history_action_employee", $action);

        $this->M_table->updateTable('employee',$data,array('id' =>$id));
		redirect('Employee/profile');
	}
    public function processCreateCategory() {
        $data = ["subCategory" => str_replace("'", "", $this->input->post("subCategory"))];
        $action                                 = ["admin_id" => $this->session->userdata("id"), "action" => "Create sub Category Resume : " . $data['subCategory'], "action_date" => date("Y-m-d H:i:s"), ];
        $this->M_table->createTable("history_action_admin",$action);
        $this->M_table->createTable('sub_category_resume',$data);
        redirect("Employee/profile");
    }
    public function processCreateSubR() {
        $data = [
            "subCategory_id" => str_replace("'", "", $this->input->post("subCategory_id")),
            "resume_id" => str_replace("'", "", $this->input->post("resume_id")),
            "date" => str_replace("'", "", $this->input->post("date")),
            "subResume" => str_replace("'", "", $this->input->post("subResume")),
            "update_date" => date("Y-m-d H:i:s"),
            "create_date" => date("Y-m-d H:i:s"),
        ];
		$dataResume['user_id'] = $this->session->userdata('id');
		$dataResume["update_date"] = date("Y-m-d H:i:s");
		$dataResume["create_date"] = date("Y-m-d H:i:s");
		if ($data['resume_id'] == "") {
			$data['resume_id']                = $this->M_table->createTableOrder("resume",$dataResume);
		}
        $action                                 = ["employee_id" => $this->session->userdata("id"), "action" => "Create sub Resume : " . $data['subResume'], "update_date" => date("Y-m-d H:i:s"), ];
        $this->M_table->createTable("history_action_employee",$action);
        $this->M_table->createTable('sub_resume',$data);
        redirect("Employee/profile");
    }
    public function processUpdateSubR() {
        $id = str_replace("'", "", $this->input->post("id"));
        $data = [
            "subCategory_id" => str_replace("'", "", $this->input->post("subCategory_id")),
            "date" => str_replace("'", "", $this->input->post("date")),
            "subResume" => str_replace("'", "", $this->input->post("subResume")),
            "update_date" => date("Y-m-d H:i:s")
        ];
        $action                                 = ["admin_id" => $this->session->userdata("id"), "action" => "Update sub Resume id : ".$id, "action_date" => date("Y-m-d H:i:s"), ];
        $this->M_table->createTable("history_action_admin",$action);
        $this->M_table->updateTable('sub_resume',$data,array('id' => $id));
        redirect("Employee/profile");
    }
    public function processDeleteSubR() {
        
        $id                       = str_replace("'", "", $this->uri->rsegment(3));
        $name = $this->M_table->getById('sub_resume',$id)['subResume'];
        $action                                 = ["admin_id" => $this->session->userdata("id"), "action" => "Delete sub Resume id : ".$name, "action_date" => date("Y-m-d H:i:s"), ];
        $this->M_table->createTable("history_action_admin",$action);
        $this->M_table->deleteTable('sub_resume', $id);
        redirect("Employee/profile");
    }

	public function _do_upload_employee()
    {
        $image_name = time().'-'.$_FILES["image"]['name'];
        $config['upload_path'] 		= 'assets/upload/images/employee/';
        $config['allowed_types'] 	= 'gif|jpg|png';
        $config['file_name'] 		= $image_name;

        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image')) {
            $this->session->set_flashdata('msg', $this->upload->display_errors('', ''));
            redirect('');
        }
        return $this->upload->data('file_name');
    }

	public function updatePassword()
	{
		$id                   = $this->session->userdata('id');
        $data['user']   	  = $this->M_employee->getEmployee($id);
		$this->load->view('employee/v_updatePassword',$data);
	}
	public function processUpdatePassword()
	{
		$data['password']          	= md5($this->input->post('password'));
		$data ['update_date']   	= date("Y-m-d H:i:s");
        $this->M_table->updateTable('employee',$data,array('id' =>$this->session->userdata('id')));
		$action = array(
            'employee_id' =>  $this->session->userdata('id'),
			'action' => "Update password ",
			'update_date' => date("Y-m-d H:i:s")
        );
		$this->M_table->createTable("history_action_employee", $action);
		redirect('Client/profile');
	}

	// =========== order ============

	public function order()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$data['orderDo']      = $this->M_employee->dataOrder('1',$id);
		$data['orderDone']    = $this->M_employee->dataOrder('2',$id);
		$this->load->view('employee/v_order',$data);
	}
	public function detailOrder()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$id_order         	  = str_replace("'", "", $this->uri->rsegment(3));
		if ($id_order=="") {
			redirect('Employee/order');
		}
		else{
			if(is_numeric($id_order)){
				if ($this->M_table->totalByCon('order','id', $id_order)==0) {
					$data['validate'] = false;
				}
				else{
					$data['validate']              = true;
					$data['dataOrder']             = $this->M_table->getDataOrder($id_order);
					$data['dataStaff']             = $this->M_table->getDataStaff($id_order);
					$data['step']                  = $this->M_table->getFlow($id_order);
                    $data["letter"]             = $this->M_table->letter($id_order);
					$data['substep']               = $this->M_table->getSubFlow($id_order);
					$data['person']                = $this->M_user->person($id_order);
					$data['dataProcessDo']         = $this->M_employee->getProcess($id_order,$id,'do');
					$data['dataProcessDone']       = $this->M_employee->getProcess($id_order,$id,'done');
					$data['meeting']       		   = $this->M_table->getMeeting($id_order);
                    $data["pic"]    			   = $this->M_table->dataTableWhere('person_in_charge','order_id',$id_order);
                    $data["dataProcess"]           = $this->M_table->getProcess($id_order);
					$data["dataUser"]              = $this->M_user->profile($data['dataOrder']['user_id']);
                    $data["dataMeeting"]            = $this->M_table->getAllMeeting($id_order);

                    // percentage input
                    $total 						= count($data['letter']);
                    $done						= count($this->M_table->percenLetter($id_order,'done'));
                    $data['percentinput'] 		= round(((20)/$total)*$done,1);
                    $data['percentInputNow']    = round(($done/$total)*100,0);
                    // percentage progress
                    $total                		= count($this->M_table->getSubFlow($id_order));
                    if ($total == 0) {
                        $total = 1;
                    }
                    $data['total']        		= $total;
                    $done                 		= count($this->M_table->getProcessDone($id_order));
                    $data['totalDone']   		= $done;
                    $data['percentProgressNow']    = round(($done/$total)*100,0);
                    
                    if ($total == 0) {
                        if ($done == 0) {
                            $data['percentprocess'] = round(60,1);
                        }
                        else{
                            $data['percentprocess'] = round(60*$done,1);
                        }
                    }
                    else{
                        $data['percentprocess'] = round((60/$total)*$done,1);
                    }
                    // percentage output
                    $outputDone = $this->M_table->getReport($id_order);
                    $outputDone = count($outputDone);
                    $data['percentoutput'] = (20)/$total;
                    $data['percentoutput'] = round($data['percentoutput'] * $outputDone,1);
                    $data['conOutput'] = true;
                    

                    // percentage all
                    $data['percentall'] 		= $data['percentinput'] + $data['percentprocess']  +  $data['percentoutput'];
				}
				$this->load->view('employee/v_detailOrder',$data);
			}
			else{
				redirect('Employee/lock');
			}
		}
	}
	public function updateStatusProcess()
	{
		$process_id			        = str_replace("'", " ", $this->uri->rsegment(3));
		$data ['update_date']   	= date("Y-m-d H:i:s");
		
		$cek = $this->M_table->getByCon('process','id', $process_id);
		if ($cek['status'] == "do") {
			$data['status'] 			= "done";
			$action = array(
				'employee_id' =>  $this->session->userdata('id'),
				'action' => "Turn done process ",
				'update_date' => date("Y-m-d H:i:s")
			);
		} else{
			$action = array(
				'employee_id' =>  $this->session->userdata('id'),
				'action' => "Turn do process ",
				'update_date' => date("Y-m-d H:i:s")
			);
			$data['status'] 			= "do";
			$validate = $this->M_table->getByCon('process_report','process_id', $process_id);
			if (file_exists('assets/upload/images/employee/'.$validate['report']) && $validate['report']) {
				unlink('assets/upload/report/'.$validate['report']);
			}
			$this->M_table->deleteTableCon('process_report','process_id',$process_id);
		}
		$this->M_table->updateTable('process',$data,array('id' => $process_id));
		
		$this->M_table->createTable("history_action_employee", $action);
		redirect('Employee/detailOrder/'.str_replace("'", " ", $this->uri->rsegment(4)));

	}

	public function _do_upload_report()
    {
        $image_name = time().'-'.$_FILES["image"]['name'];
        $config['upload_path'] 		= 'assets/upload/report/';
        $config['allowed_types'] 	= 'pdf|jpg|png|jpeg|xlsx|doc|odt';
        $config['max_size'] 		= 1000;
        $config['max_widht'] 		= 1500;
        $config['max_height']  		= 1500;
        $config['file_name'] 		= $image_name;

        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image')) {
            $this->session->set_flashdata('msg', $this->upload->display_errors('', ''));
            redirect('');
        }
        return $this->upload->data('file_name');
    }
	
	// ==================== WORKFLOW ====================
    public function dataWorkflow() {
		$id             = $this->session->userdata('id');
        $data['user']   = $this->M_employee->getEmployee($id);
        $data["c1"]     = $this->M_table->getByCon("categoryservice", "id", 1);
        $data["c2"]     = $this->M_table->getByCon("categoryservice", "id", 2);
        $data["c3"]     = $this->M_table->getByCon("categoryservice", "id", 3);
        $data["c4"]     = $this->M_table->getByCon("categoryservice", "id", 4);
        $data["data1"]  = $this->M_table->totalByCon("services", "category_service_id", 1);
        $data["data2"]  = $this->M_table->totalByCon("services", "category_service_id", 2);
        $data["data3"]  = $this->M_table->totalByCon("services", "category_service_id", 3);
        $data["data4"]  = $this->M_table->totalByCon("services", "category_service_id", 4);
        $data["data0"]  = $this->M_table->totalByCon("services", "category_service_id", 0);
        $this->load->view("employee/v_dataWorkflow", $data);
    }

    public function detailWorkflow() {
        $id                                     = $this->session->userdata("id");
        $data['user']   = $this->M_employee->getEmployee($id);
        $id                                     = str_replace("'", "	", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("Employee/dataWorkflow");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("categoryservice", "id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["selected"]           = $this->M_table->getByCon("categoryservice", "id", $id);
                    $data["service"]            = $this->M_table->getService($id);
                }
                $this->load->view("employee/v_detailWorkflow", $data);
            } else {
                redirect("Employee/lock");
            }
        }
    }
    public function workflow() {
        $id                                     = $this->session->userdata("id");
        $data['user']   = $this->M_employee->getEmployee($id);
        $id                                     = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("Employee/dataWorkflow");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("services", "id", $id) > 0) {
                    $data["service"]            = $this->M_table->getByCon("services", "id", $id);
                }
                if ($this->M_table->totalByCon("step", "service_id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = "hm";
                    $data["selected"]           = $this->M_table->dataTableWhere("step", "service_id", $id);
                }
                $this->load->view("employee/v_step", $data);
            } else {
                redirect("Employee/lock");
            }
        }
    }
    public function updateDataStep()
    {
        $data["step"]                           = str_replace("'", "", $this->input->post("step"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $id                    = str_replace("'", "", $this->input->post("id"));
        $data["drive"]                    = str_replace("'", "", $this->input->post("drive"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->updateTable("step", $data, ["id" => $id]);
        redirect('Employee/workflow/'.str_replace("'", "", $this->input->post("service_id")));
    }
    public function processCreateStep() {
        $data["step"]                           = str_replace("'", "", $this->input->post("name"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $data["drive"]                    = str_replace("'", "", $this->input->post("drive"));
        $con                                    = str_replace("'", "", $this->input->post("con"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        if (is_numeric($category)) {
            $data["service_id"]                 = str_replace("'", "", $category);
            $this->M_table->createTable("step", $data);
            $action                             = ["admin_id" => $this->session->userdata("id"), "action" => "Create Step : " . $data['step'], "action_date" => date("Y-m-d H:i:s"), ];
            $this->M_table->createTable("history_action_admin", $action);
        }
        if ($con == "") {
            redirect("Employee/workflow/" . $category);
        } else {
            $order_id                           = str_replace("'", "", $this->input->post("order_id"));
            redirect("Employee/updateOrderStep/" . $order_id);
        }
    }
    public function deleteStep() {
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        $service                                = str_replace("'", "", $this->uri->rsegment(4));
        if ($category == "" || $service == "") {
            redirect("Employee/dataWorkflow");
        } else {
            if (is_numeric($category) && is_numeric($service)) {
                $this->M_table->deleteTable("step", $category);
                $step                           = $this->M_table->getByCon("step", "id", $category) ["step"];
                $action                         = ["admin_id" => $this->session->userdata("id"), "action" => "Delete Step : " . $step, "action_date" => date("Y-m-d H:i:s"), ];
                $this->M_table->createTable("history_action_admin", $action);
                redirect("Employee/workflow/" . $service);
            } else {
                redirect("Employee/lock");
            }
        }
    }
    public function detailStep() {
        $id                                     = $this->session->userdata("id");
        $data['user']   = $this->M_employee->getEmployee($id);
        $id_category                            = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_category == "") {
            redirect("Employee/dataWorkflow");
        } else {
            if (is_numeric($id_category)) {
                if ($this->M_table->totalByCon("step", "id", $id_category) > 0) {
                    $data["step"]               = $this->M_table->getByCon("step", "id", $id_category);
                }
                if ($this->M_table->totalByCon("substep", "step_id", $id_category) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = "hm";
                    $data["subStep"]            = $this->M_table->dataTableWhere("substep", "step_id", $id_category);
                    $data["step"]               = $this->M_table->getByCon("step", "id", $id_category);
                }
                $this->load->view("employee/v_subStep", $data);
            } else {
                redirect("Employee/lock");
            }
        }
    }
    public function updateSubStep() {
        $subStep                                        = str_replace("'", "", $this->input->post("subStep_id"));
        $step                                        = str_replace("'", "", $this->input->post("step_id"));
        $data['subStep']                              = str_replace("'", "", $this->input->post("subStep"));
        $data["update_date"]                         = date("Y-m-d H:i:s");
        if ($subStep == "") {
            redirect("Employee/lock");
        } else {
            if (is_numeric($subStep)) {
                $this->M_table->updateTable("substep", $data, ["id" => $subStep]);
                redirect("Employee/detailStep/". $step);
            } else {
                redirect("Employee/lock");
            }
        }
    }
    public function processCreateSubStep() {
        $data["subStep"]                        = str_replace("'", "", $this->input->post("name"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["step_id"]                        = str_replace("'", "", $this->input->post("step_id"));
        // print_r($data); exit();
        $this->M_table->createTable("substep", $data);
        $step                                   = $this->M_table->getByCon("step", "id", $data['step_id']) ["step"];
        $action                                 = ["admin_id" => $this->session->userdata("id"), "action" => "Create sub step : " . $data['subStep'] . " to step : " . $step, "action_date" => date("Y-m-d H:i:s"), ];
        $this->M_table->createTable("history_action_admin", $action);
        if (str_replace("'", "", $this->input->post("order_id")) == "") {
            redirect("Employee/detailStep/" . $data["step_id"]);
        } else {
            redirect("Employee/updateOrderStep/" . str_replace("'", "", $this->input->post("order_id")));
        }
    }
    public function deleteSubStep() {
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        $service                                = str_replace("'", "", $this->uri->rsegment(4));
        if ($category == "" || $service == "") {
            redirect("Employee/dataWorkflow");
        } else {
            if (is_numeric($category) && is_numeric($service)) {
                $substep                        = $this->M_table->getByCon("substep", "id", $category) ["subStep"];
                $action                         = ["admin_id" => $this->session->userdata("id"), "action" => "Delete sub step : " . $substep, "action_date" => date("Y-m-d H:i:s"), ];
                $this->M_table->createTable("history_action_admin", $action);
                $this->M_table->deleteTable("substep", $category);
                redirect("Employee/detailStep/" . $service);
            } else {
                redirect("Employee/lock");
            }
        }
    }

    // ================= service ==================

    public function dataProject()
    {
        
        $id                                     = $this->session->userdata("id");
        $data['user']       = $this->M_employee->getEmployee($id);
		$data['dataProject']  = $this->M_table->getAll('services');
        $this->load->view('employee/v_dataProject',$data);
    }
	// ================== report ====================

	public function processCreateReport()
	{
		$data = array(
            'process_id' =>  str_replace("'", "", $this->input->post('process_id')),
            'message' =>  str_replace("'", "", $this->input->post('message')),
			'update_date' => date("Y-m-d H:i:s"),
			'create_date' => date("Y-m-d H:i:s"),
        );
		
        if (!empty($_FILES['image']['name'])) {
            $image = $this->_do_upload_report();
			$data['report'] = $image;
        }
		$forReview['report_id']         = $this->M_table->createTableOrder('process_report',$data);
		$forReview['ending_date']       = str_replace("'", "", $this->input->post('ending_date'));
		$forReview['create_date']       = date("Y-m-d H:i:s");
		$forReview['update_date']       = date("Y-m-d H:i:s");
		$this->M_table->createTable('report_review',$forReview);
		$action = array(
            'employee_id' =>  $this->session->userdata('id'),
			'action' => "Upload report",
			'update_date' => date("Y-m-d H:i:s")
        );
		$this->M_table->createTable("history_action_employee", $action);
		redirect('Employee/orderReport/'.str_replace("'", "", $this->input->post('order_id')));
	}
	public function deleteReport()
	{
		$id               = str_replace("'", "", $this->uri->rsegment(3));
		$data = $this->M_table->getById('process_report', $id);
        if (file_exists('assets/upload/report/'.$data['report'])) {
            unlink('assets/upload/report/'.$data['report']);
        }
		$this->M_table->deleteTable('process_report',$id);
		$this->M_table->deleteTableCon('report_review','report_id',$id);
		$action = array(
            'employee_id' =>  $this->session->userdata('id'),
			'action' => "Delete report",
			'update_date' => date("Y-m-d H:i:s")
        );
		$this->M_table->createTable("history_action_employee", $action);
		redirect('Employee/orderReport/'.str_replace("'", "", $this->uri->rsegment(4)));
	}
	public function updateReport()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$report_id = str_replace("'", "", $this->uri->rsegment(3));
		if ($report_id=="") {
			redirect('Employee/report');
		}
		else{
			if(is_numeric($report_id)){
				if ($this->M_table->totalByCon('process_report','id', $report_id)==0) {
					$data['validate'] = false;
				}
				else{
					$data['validate'] = true;
					$data['dataReport'] = $this->M_table->detailReport($report_id);
				}
				$this->load->view('employee/v_updateReport',$data);
			}
			else{
				redirect('Employee/lock');
			}
		}
	}

	public function report()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$data['orderDo']      = $this->M_employee->dataOrder('1',$id);
		$data['orderDone']    = $this->M_employee->dataOrder('2',$id);
		$this->load->view('employee/v_report',$data);
	}
	public function orderReport()
	{
		$id                         = $this->session->userdata('id');
		$id_order                   = str_replace("'", " ", $this->uri->rsegment(3));
        $data['user']         		= $this->M_employee->getEmployee($id);
		$data['dataOrder']          = $this->M_table->getDataOrder($id_order);
		$data['report']             = $this->M_employee->getReport($id_order,$id);
		$data['dataProcessDone']    = $this->M_employee->getProcessDone($id_order,$id);
		$this->load->view('employee/v_orderReport',$data);
	}
	public function processUpdateReport()
	{
		$id				        	= $this->input->post('report_id');
		$data = array(
            'message' =>  str_replace("'", "", $this->input->post('message')),
            'sent_hardfile' =>  str_replace("'", "", $this->input->post('sent_hardfile')),
			'update_date' => date("Y-m-d H:i:s")
        );
        $cek = $this->M_table->getById('process_report',$id);
		if ($cek['sent_hardfile'] != "sent" && $this->input->post('sent_hardfile') == "sent") {
			$data['sent_date'] =  date("Y-m-d H:i:s");
		}
        if (!empty($_FILES['image']['name'])) {
            $image = $this->_do_upload_report();
			$upload = $this->M_table->getById('process_report', $id);

            if (file_exists('assets/upload/report/'.$upload['report'])) {
                unlink('assets/upload/report/'.$upload['report']);
            }
			$data['report'] = $image;
        }
		$action = array(
            'employee_id' =>  $this->session->userdata('id'),
			'action' => "Update report",
			'update_date' => date("Y-m-d H:i:s")
        );
		$this->M_table->createTable("history_action_employee", $action);
        $this->M_table->updateTable('process_report',$data,array('id' =>$id));
		redirect('Employee/orderReport/'.$this->input->post('order_id'));
	}

	// ================== REVIEW ====================

	public function review()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$data['orderDo']      = $this->M_employee->dataOrder('1',$id);
		$data['orderDone']    = $this->M_employee->dataOrder('2',$id);
		$this->load->view('employee/v_review',$data);
	}
	public function reportReview()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		
		$id_order                   = str_replace("'", " ", $this->uri->rsegment(3));
		if ($id_order=="") {
			redirect('Employee/review');
		}
		else{
			if(is_numeric($id_order)){
				$data['dataOrder']    = $this->M_table->getDataOrder($id_order);
				$data['dataStaff']    = $this->M_table->getDataStaff($id_order);
				$data['person']       = $this->M_user->person($id_order);
				$data['review']       = $this->M_employee->reviewByCon($id_order,$id);
				
		$data['report']             = $this->M_table->getReport($id_order);
				if ($data['dataOrder']['supervisor_id'] == $id) {
					$data['supervisor'] = "true";
				} else{
					$data['supervisor'] = "false";
				}
				$this->load->view('employee/v_reportReview',$data);
			}
			else{
				redirect('Employee/lock');
			}
		}
	}
	public function approveReport() {
        $review_id                    	= $this->uri->rsegment(3);
		if ($review_id=="" || $this->uri->rsegment(4) == "") {
			redirect('Employee/lock');
		}
		else{
			if(is_numeric($review_id) || is_numeric($this->uri->rsegment(4))){
				if ($this->M_table->totalByCon('report_review','id', $review_id)==0) {
					redirect('Employee/lock');
				}
				if ($this->M_table->getById('report_review',$review_id)['review_supervisor'] == "do") {
					$data['review_supervisor'] = "done";
				} else{
					$data['review_supervisor'] = "do";
				}
				$this->M_table->updateTable("report_review", $data, ["id" => $review_id]);
				redirect('Employee/reportReview/'.$this->uri->rsegment(4));
			}
			else{
				redirect('Employee/lock');
			}
		}
    }
	public function updateStatusReview()
	{
		$id_review                   = str_replace("'", " ", $this->uri->rsegment(3));
		$id_order                   = str_replace("'", " ", $this->uri->rsegment(4));
		if ($id_order == "" || $id_order == "") {
			redirect('Employee/review');
		}
		else{
			if(is_numeric($id_order) && is_numeric($id_review)){
				$data['review_status']    = "done";
				$this->M_table->updateTable('report_review',$data,array('id' => $id_review));
				$action = array(
					'employee_id' =>  $this->session->userdata('id'),
					'action' => "Update review",
					'update_date' => date("Y-m-d H:i:s")
				);
				$this->M_table->createTable("history_action_employee", $action);
				redirect('Employee/reportReview/'.$id_order);
			}
			else{
				redirect('Employee/lock');
			}
		}
	}
	public function updateReview()
	{
		$review_id = str_replace("'", "", $this->uri->rsegment(3));
		$report_id = $this->M_table->getById('report_review',$review_id)['report_id'];
		redirect('Employee/updateReport/'.$report_id);
	}
	
	// ================== FEEDBACK ====================

	public function feedback()
	{
		
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$data['dataClient']   = $this->M_table->dataTableWhere('user','status_id','1');
		$data['dataServices']   = $this->M_table->getAll('services');
		$data['orderDone']    = $this->M_employee->dataOrder('1',$id);	
		$this->load->view('employee/v_feedback.php',$data);
	}
	public function detailFeedback()
	{
		$id                   = $this->session->userdata('id');
        $data['user']   	  = $this->M_employee->getEmployee($id);
		$order_id             = str_replace("'", "", $this->uri->rsegment(3));
		if ($order_id=="") {
			redirect('Employee/feedback');
		}
		else{
			if(is_numeric($order_id)){
				if ($this->M_employee->totalFeedbackOrder($order_id,$id)==0) {
					$data['validate'] = false;
				}
				else{
					$data['validate'] 	  = true;
					$data['dataFeedback'] = $this->M_employee->getFeedback($order_id,$id);
					$data['dataCriteria'] = $this->M_employee->getCriteria($order_id,$id);
				}
				$this->load->view('employee/v_detailFeedback',$data);
			}
			else{
				redirect('Employee/lock');
			}
		}

	}
	
	// ================== HISTORY ====================

	public function history()
	{
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$data['history']   	  = $this->M_table->dataTableWhere('history_login_employee','employee_id',$id);
		$data['action']   	  = $this->M_employee->getAction($id);
		$this->load->view('employee/v_history.php',$data);
	}

	// ================== SCURITY ====================

	public function lock()
	{
			$id = $this->session->userdata('key');
			$data['logout_date'] = date("Y-m-d H:i:s");
			$this->M_table->updateTable('history_login_employee',$data,array('login_date' =>$id));
			$this->session->sess_destroy();
			$this->load->view('v_anonymous');
	}
	 // ================= SPECIAL TASK ==================
    public function specialTask()
    {
        $id                   = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
        $data['dataCategory'] = $this->M_table->getAll('category_specialtask');
        $data['dataTask']      = $this->M_table->getTaskByEmployee($id);
        $this->load->view("employee/v_specialTask", $data);
    }
    public function updateTask()
    {
        $data["task"]           = str_replace("'", "", $this->input->post("task"));
        $data["description"]    = str_replace("'", "", $this->input->post("description"));
        $data["id_category"]    = str_replace("'", "", $this->input->post("category_id"));
        $data["update_date"]    = date("Y-m-d H:i:s");
        
        $this->M_table->updateTable("specialtask", $data,array('id'=>$this->input->post("task_id")));
        redirect("Employee/specialTask");
    }
	public function uploadTask()
    {
		$id                   = $this->session->userdata('id');
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$task_id             = str_replace("'", "", $this->uri->rsegment(3));
		$bantu = [];
		foreach ($this->M_table->getTaskByEmployee($id) as $row) {
			array_push($bantu,$row['id']);
		}
		if (in_array($task_id, $bantu)) {
			if ($task_id=="") {
				redirect('Employee/lock');
			}
			else{
				if(is_numeric($task_id)){
					$data['dataTask'] = $this->M_table->getById('specialtask',$task_id);
					
					$this->load->view('employee/v_uploadTask',$data);
				}
				else{
					redirect('Employee/lock');
				}
			}
		}
		else{
			redirect('Employee/lock');
		}
	}
	public function _do_upload_task()
    {
        $image_name = time().'-'.$_FILES["image"]['name'];
        $config['upload_path'] 		= 'assets/upload/task/';
        $config['allowed_types'] 	= 'pdf|jpg|png|jpeg|xlsx|doc|odt';
        $config['file_name'] 		= $image_name;

        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('image')) {
            $this->session->set_flashdata('msg', $this->upload->display_errors('', ''));
            redirect('');
        }
        return $this->upload->data('file_name');
    }
	
    public function processCreateTask()
    {
        $data["employee_id"]    = $this->session->userdata('id');
        $data["task"]           = str_replace("'", "", $this->input->post("task"));
        $data["description"]    = str_replace("'", "", $this->input->post("description"));
        $data["estimasi"]       = date("Y-m-d H:i:s");
        $data["id_category"]    = str_replace("'", "", $this->input->post("category_id"));
        $data["update_date"]    = date("Y-m-d H:i:s");
        $data["create_date"]    = date("Y-m-d H:i:s");
        $this->M_table->createTable("specialtask", $data);
        redirect("Employee/specialTask"); 
    }

	public function processUploadTask()
	{
		$id				        	= $this->session->userdata('id');
		
		$task_id =  str_replace("'", "", $this->input->post('task_id'));
		$data = array(
			'description' => str_replace("'", "", $this->input->post('description')),
			'update_date' => date("Y-m-d H:i:s")	
        );
        if (!empty($_FILES['image']['name'])) {
            $image = $this->_do_upload_task();
			$data['file'] = $image;
			$upload = $this->M_table->getById('specialtask',$task_id);
            if (file_exists('assets/upload/task/'.$upload['file'])) {
                unlink('assets/upload/task/'.$upload['file']);
            }
        }
		$action = array(
            'employee_id' =>  $id,
			'action' => "upload special task",
			'update_date' => date("Y-m-d H:i:s")
        );
		$this->M_table->createTable("history_action_employee", $action);

        $this->M_table->updateTable('specialtask',$data,array('id' =>$task_id));
		redirect('Employee/specialTask');
	}

	//============ training ============

	public function training()
    {
        $id                                     = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
        $data["data_category"]                  = $this->M_table->getAll('content_training_category');
        $this->load->view("employee/v_training", $data);   
    }

    public function dtraining()
    {
        $id                             = $this->session->userdata("id");
        $data['user']  		            = $this->M_employee->getEmployee($id);
        $id                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("Employee/lock");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("content_training_category", "id", $id) == 0) {
                    redirect("Employee/lock");
                } else {
                    $data["category"]                  = $this->M_table->getById('content_training_category',$id);
                    $data["title_content"]                  = $this->M_table->dataTableWhere('content_training_title','id_category',$id);
                }
                $this->load->view("employee/landingpage/index", $data);
            } else {
                redirect("Employee/lock");
            }
        }
    }
    public function content()
    {
        $id                             = $this->session->userdata("id");
        $data['user']  		            = $this->M_employee->getEmployee($id);
        $id                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("Employee/lock");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("content_training_title", "id", $id) == 0) {
                    redirect("Employee/lock");
                } else {
                    $data["title_content"]                  = $this->M_table->getById('content_training_title',$id);
                    $data["category"]                  = $this->M_table->getById('content_training_category',$data['title_content']['id_category']);
                    $data['data_pdf']   = $this->M_table->dataTableWhere('content_training_type_pdf','id_content_title',$id);
                    $data['data_ppt']   = $this->M_table->dataTableWhere('content_training_type_ppt','id_content_title',$id);
                    $data['data_yt']   = $this->M_table->dataTableWhere('content_training_type_yt','id_content_title',$id);
                }
                $this->load->view("employee/landingpage/content", $data);
            } else {
                redirect("Employee/lock");
            }
        }
    }

	//============ tax update ============

	public function taxUpdate(){
        $id                                     = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
        $this->load->view("employee/v_taxUpdate", $data);   
    }

	//============ accountingUpdate ============

	public function accountingUpdate()
	{
		$id                                     = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
		$this->load->view("employee/v_accountingUpdate", $data);   
	}

	//============ employeeScore ============

	public function employeeScore(){
		$id                                     = $this->session->userdata("id");
		$data['user']  		  = $this->M_employee->getEmployee($id);
		$this->load->view("employee/v_employeeScore", $data);   
	}

    // =========== daily report =============

    
    public function dailyReport()
    {
		$id                                     = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
        $type = $this->input->post("type");
        if ($this->input->post("totalData")) {
            for ($i=1; $i < $this->input->post("totalData"); $i++) {
                $report_id                = $this->input->post('report_id'.$i);
                $newData['planing']       = $this->input->post('planing'.$report_id);
                $newData['doing']         = $this->input->post('doing'.$report_id);
                $newData['problem']       = $this->input->post('problem'.$report_id);
                $newData['solution']      = $this->input->post('solution'.$report_id);
                $newData['description']   = $this->input->post('description'.$report_id);
                $this->M_table->updateTable('dailyreport',$newData,array('id' =>$report_id));
            }
            $date     = strval($this->input->post('date'));
            $data['dailyReport']    = $this->M_employee->dR_ED($id,$date);
            $data['message'] = "Menampilkan data laporan : ". date("F j, Y", strtotime($date));
            $data['date'] = $date;
            $data['type'] = "day";
            return $this->load->view('employee/v_dailyReport',$data);
        }
        if ($type) {
            if ($type == "day") {
                ($this->input->post("date") ? $date = $this->input->post("date") : $date= $this->input->post("day"));
                $data['dailyReport']    = $this->M_employee->dR_ED($id,$date);
                $data['message'] = "Menampilkan data Harian pada: "  . date("F j, Y", strtotime($date));
            } else{
                ($this->input->post("date") ? $date = $this->input->post("date") : $date= $this->input->post("month"));
                $m = date("m", strtotime($date));
                $y = date("Y", strtotime($date));
                $data['dailyReport'] =$this->M_employee->dR_ED_Month($id,$m,$y);
                $data['message'] = "Menampilkan data Bulanan pada: " . date("F Y", strtotime($date));
            }
            $data['date'] = $date;
            $data['type'] = $type;
        } else{
            $date = date('Y-m-d');
            $data['dailyReport']    = $this->M_employee->dR_ED($id,$date);
            $data['message'] = "Menampilkan data laporan Hari ini";
            $data['date'] = date('Y-m-d');
            $data['type'] = "day";
        }
        $this->load->view('employee/v_dailyReport',$data);
    }
    public function createTemplateReport()
    {
	    $id                             = $this->session->userdata("id");
        if (empty($this->M_employee->dR_ED($id,date('Y-m-d')))) {
            $time_start = ['08:00', '08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00', '14:30','15:00','15:30','16:00','16:30','17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30', '00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', '06:30', '07:00', '07:30'];
            $time_end = ['08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00', '14:30','15:00','15:30','16:00','16:30','17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30', '00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', '06:30', '07:00', '07:30', '08:00'];
            $data['date']       = date('Y-m-d');
            $data['create_date']       = date("Y-m-d H:i:s");
            $data['update_date']       = date("Y-m-d H:i:s");
            $data['employee_id']       = $id;
            for ($i=0; $i < 48; $i++) { 
                $data['start_time'] = $time_start[$i];
                $data['end_time'] = $time_end[$i];
                $this->M_table->createTable('dailyreport',$data);
            }
            redirect('Employee/dailyReport');
        } else{
            redirect('Employee/dailyReport');
        }
        
    }

    // ============= data information ==================

    public function dataInformation()
    {
		$id                   = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
        $data['seminar']      = $this->M_table->getAll('news');
        $this->load->view('employee/v_dataInformation',$data);
    }
    public function detailInformation()
    {
		$id                   = $this->session->userdata("id");
        $data['user']  		  = $this->M_employee->getEmployee($id);
        $news_id                    	= $this->uri->rsegment(3);
		if ($news_id=="") {
			redirect('Employee/lock');
		}
		else{
			if(is_numeric($news_id)){
				if ($this->M_table->totalByCon('news','id', $news_id)==0) {
					redirect('Employee/lock');
				}
				else{
					$data['dataNews'] 			= $this->M_table->getById('news',$news_id);
				}
					return $this->load->view('employee/v_detailNews',$data);
				
			}
			else{
				redirect('Employee/lock');
			}
		}
    }
}