<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct(){	
        parent:: __construct();
			if ($this->session->userdata('status_id') == 5) {
				redirect('Administrasi');
			}
			if ($this->session->userdata('status_id') == 4) {
				redirect('Employee');
			}
            if ($this->session->userdata('status_id') == 3) {
				redirect('SuperAdmin');
			}	
			if ($this->session->userdata('status_id') == 2) {
				redirect('Admin');
			}	
			if ($this->session->userdata('status_id') == 6) {
				redirect('Guest');
			}	
		  
			if ($this->session->userdata('status_id') == 1) {
				redirect('Client');
			}
    }
	public function index(){
		$this->load->view('v_login');
	}
	function proses_login(){
		$email = str_replace("'", "", $this->input->post('email'));
		$password = str_replace("'", "", $this->input->post('password'));
		$password = md5($password);
		$result     = $this->M_login->getUser($email,$password);
		$employee     = $this->M_login->getEmployee($email,$password);
		
		if ($result) {
			$newdata   = array(
				'id'        => $result['id'],
				'name'      => $result['name'],
				'status_id' => $result['status_id'],
				'from' => $result['user_to_company_id'],
				'status'    => "login",
				'key' => date("Y-m-d H:i:s"),
				'last_login_time' => time()
			);

			$this->session->set_userdata($newdata);
			
			$data['user_id'] = $this->session->userdata('id');
			$data['login'] = $this->session->userdata('key');
			$this->M_table->createTable('history_login',$data);

			if ($this->session->userdata('status_id') == 3) {
				redirect('SuperAdmin');
			}
			if ($this->session->userdata('status_id') == 5) {
				redirect('Administrasi');
			}	
			if ($this->session->userdata('status_id') == 2) {
				redirect('Admin');
			}
			if ($this->session->userdata('status_id') == 6) {
				redirect('Guest');
			}
			if ($this->session->userdata('status_id') == 1) {
				redirect('Client');
			}
        }
		else if ($employee) {
				$newdata   = array(
				'id'        => $employee['id'],
				'name'      => $employee['employee_name'],
				'status_id' => $employee['login_status_id'],
				'position' => $employee['status_id'],
				'status'    => "login",
				'key' => date("Y-m-d H:i:s"),
				'last_login_time' => time()
			);
			$this->session->set_userdata($newdata);
			
			$data['employee_id'] = $this->session->userdata('id');
			$data['login_date'] = $this->session->userdata('key');;
			$this->M_table->createTable('history_login_employee',$data);
			
			if ($this->session->userdata('status_id') == 4) {
				redirect('Employee');
			}	
			if ($this->session->userdata('status_id') == 3) {
				redirect('SuperAdmin');
			}
			if ($this->session->userdata('status_id') == 5) {
				redirect('Administrasi');
			}
			if ($this->session->userdata('status_id') == 2) {
				redirect('Admin');
			}
			if ($this->session->userdata('status_id') == 1) {
				redirect('Client');
			}
		}
        else{
			$data['err'] = "wrong email or password!";
			$this->load->view('v_login',$data);
		}

	}
}
