<?php
defined("BASEPATH") or exit("No direct script access allowed");
class SuperAdmin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if ($this->session->userdata("status") != "login") {
            redirect("Login");
        }
        if ($this->session->userdata("status_id") == 4) {
            redirect("Employee");
        }
        if ($this->session->userdata("status_id") == 2) {
            redirect("Admin");
        }
        if ($this->session->userdata("status_id") == 1) {
            redirect("Client");
        }
        if (time() - $this->session->userdata("last_login_time") > 7200) {
            $id                                 = $this->session->userdata('key');
            $data['logout']                     = date("Y-m-d H:i:s");
            $this->M_table->updateTable('history_login', $data, array('login' => $id));
            
        
            redirect("Logout");
        }
        $_SESSION["last_login_time"]            = time();
    }
    public function index() {
        $id                           = $this->session->userdata("id");
        $data["user"]                 = $this->M_user->profile($id);
        $data["totalFeedback"]        = $this->M_table->getTotalData("feedback");
        $data["totalClient"]          = $this->M_table->totalDataTableWhere("user", "status_id", 1);
        $data["totalAdmin"]           = $this->M_table->totalDataTableWhere("user", "status_id", 2);
        $data["totalProject"]         = $this->M_table->getTotalData("services");
        $data["totalEmployee"]        = $this->M_table->getTotalData("employee");
        $data["totalCompany"]         = $this->M_table->getTotalData("company");
        $data["totalWorkflow"]        = $this->M_table->getTotalData("step");
        $data['orderDo']              = $this->M_table->totalStatusOrderAll(1);
        $data['orderDone']            = $this->M_table->totalStatusOrderAll(2);
        $data['orderCancel']          = $this->M_table->totalStatusOrderAll(3);
        $data['news']                 = $this->M_table->getAll('news order by create_date desc');
        $data['loginEmployee']        = [];
        $data['loginEmployeeFinal']   = [];
        $data['reportToday']          = $this->M_employee->dR_AD(date('Y-m-d'));
        foreach ($this->M_table->getAll('employee') as $key) {
            $a = $this->M_employee->getAction($key['id']);
            $data['loginEmployee']['id'] = $key['id'];
            $nama = explode(' ',$key['employee_name']);
            $data['loginEmployee']['name'] =  "$nama[0]";
            $data['loginEmployee']['image']['src'] = 'assets/upload/images/employee/'. $key['image'];
            $data['loginEmployee']['total'] = count($a);
            array_push($data['loginEmployeeFinal'],$data['loginEmployee']);
        }
        usort($data['loginEmployeeFinal'], function($x, $y) {
            return $x['total'] <=> $y['total'];
        });
        $data['loginEmployeeFinal'] = array_reverse($data['loginEmployeeFinal']);
        $data['loginEmployeeFinal'] = array_slice( $data['loginEmployeeFinal'], 0, 5);
        $data['orderAll']         = $data['orderDo'] + $data['orderDone'] + $data['orderCancel'];
        $this->load->view("superAdmin/v_dashboard", $data);
    }
    // ============== USER =============
    public function dataUser() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["totalClient"]                    = $this->M_table->totalDataTableWhere("user", "status_id", 1);
        $data["totalAdmin"]                     = $this->M_table->totalDataTableWhere("user", "status_id", 2);
        $data["totalAdministrasi"]                     = $this->M_table->totalDataTableWhere("user", "status_id", 5);
        $data["totalEmployee"]                  = $this->M_table->totalDataTableWhere("employee", "login_status_id", 4);
        $this->load->view("superAdmin/v_dataUser", $data);
    }
    public function dataAdministrasi() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["country"]                        = $this->M_table->getAll("country");
        $data["company"]                        = $this->M_table->getAll("company");
        $data["dataAdministrasi"]                    =$this->M_user->getByWhere("status_id", 5);
        $this->load->view("superAdmin/v_dataAdministrasi", $data);
    }
    public function processCreateAdministrasi() {
        $data["name"]                           = str_replace("'", "", $this->input->post("name"));
        $data["position"]                       = str_replace("'", "", $this->input->post("position"));
        $data["email"]                          = str_replace("'", "", $this->input->post("email"));
        $data["password"]                       = md5(str_replace("'", "", $this->input->post("password")));
        $data["phone"]                          = str_replace("'", "", $this->input->post("phone"));
        $data["NPWP"]                           = str_replace("'", "", $this->input->post("NPWP"));
        $data["NIK"]                            = str_replace("'", "", $this->input->post("NIK"));
        $data["user_to_company_id"]             = str_replace("'", "", $this->input->post("user_to_company_id"));
        $data["nationality"]                    = str_replace("'", "", $this->input->post("nationality"));
        $data["company_id"]                     = str_replace("'", "", $this->input->post("company_id"));
        $data["address"]                        = str_replace("'", "", $this->input->post("address"));
        $data["status_id"]                      = 5;
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["update_date"]                    = date("Y-m-d H:i:s");
         if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_client();
            $data["image"]                      = $image;
        }
        $this->M_table->createTable("user", $data);
        redirect("SuperAdmin/dataAdministrasi");
    }
    public function dataClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataClient"]                     = $this->M_user->getByWhere("status_id", 1);
        $this->load->view("superAdmin/v_dataClient", $data);
    }
    public function deleteClient() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                               = $this->M_table->dataTableWhere("order", "user_id", $id);
        foreach ($order_id as $key) {
            $this->M_table->deleteTableCon("order", "id", $key["id"]);
            $this->M_table->deleteTableCon("order_staff", "order_id", $key["id"]);
            $this->M_table->deleteTableCon("order_step", "order_id", $key["id"]);
            $this->M_table->deleteTableCon("data", "order_id", $key["id"]);
            $this->M_table->deleteTableCon("chatt", "order_id", $key["id"]);
            $this->M_table->deleteTableCon("process_report", "order_id", $key["id"]);
            $id_output                          = $this->M_table->getByCon("output", "order_id", $key["id"]);
            $this->M_table->deleteTableCon("output", "order_id", $key["id"]);
            $this->M_table->deleteTableCon("meeting", "output_id", $id_output["id"]);
            $this->M_table->deleteTableCon("process", "order_id", $key["id"]);
        }
        $this->M_table->deleteTable("user", $id);
        redirect("SuperAdmin/dataClient");
    }
    public function updateClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_user                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_user == "") {
            redirect("SuperAdmin/dataClient");
        } else {
            if (is_numeric($id_user)) {
                if ($this->M_table->totalByCon("user", "id", $id_user) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataClient"]         = $this->M_user->profile($id_user);
                    $data["company"]            = $this->M_table->getAll("company");
                    $data["country"]            = $this->M_table->getAll("country");
                }
                $this->load->view("superAdmin/v_updateClient", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdateClient() {
        $id  = str_replace("'", "", $this->input->post("user_id"));
        $data["name"]                           = str_replace("'", "", $this->input->post("name"));
        $data["position"]                       = str_replace("'", "", $this->input->post("position"));
        $data["email"]                          = str_replace("'", "", $this->input->post("email"));
        $data["phone"]                          = str_replace("'", "", $this->input->post("phone"));
        $data["NPWP"]                           = str_replace("'", "", $this->input->post("NPWP"));
        $data["NIK"]                            = str_replace("'", "", $this->input->post("NIK"));
        $data["nationality"]                    = str_replace("'", "", $this->input->post("nationality"));
        $data["company_id"]                     = str_replace("'", "", $this->input->post("company_id"));
        $data["address"]                        = str_replace("'", "", $this->input->post("address"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
         if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_client();
            $upload                             = $this->M_table->getById("user", $id);
            if (file_exists("assets/upload/images/client/" . $upload["image"]) && $upload["image"]) {
                unlink("assets/upload/images/client/" . $upload["image"]);
            }
            $data["image"]                      = $image;
        }
        $this->M_table->updateTable("user", $data, ["id" => $id]);
        redirect("SuperAdmin/updateClient/" . $id);
    }
    public function processUpdatePersonResponsible() {
        $id  = str_replace("'", "", $this->input->post("user_id"));
        $data["name"]                           = str_replace("'", "", $this->input->post("name"));
        $data["position"]                       = str_replace("'", "", $this->input->post("position"));
        $data["email"]                          = str_replace("'", "", $this->input->post("email"));
        $data["phone"]                          = str_replace("'", "", $this->input->post("phone"));
        $data["NPWP"]                           = str_replace("'", "", $this->input->post("NPWP"));
        $data["NIK"]                            = str_replace("'", "", $this->input->post("NIK"));
        $data["nationality"]                    = str_replace("'", "", $this->input->post("nationality"));
        $data["address"]                        = str_replace("'", "", $this->input->post("address"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->updateTable("person_responsible", $data, ["user_id" => $id, ]);
        redirect("SuperAdmin/updateClient/" . $id);
    }
    public function createClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["company"]                        = $this->M_table->getAll("company");
        $data["country"]                        = $this->M_table->getAll("country");
        $this->load->view("superAdmin/v_createClient", $data);
    }
    public function processCreateClient() {
        $data["name"]                           = str_replace("'", "", $this->input->post("name"));
        $data["position"]                       = str_replace("'", "", $this->input->post("position"));
        $data["email"]                          = str_replace("'", "", $this->input->post("email"));
        $data["password"]                       = md5(str_replace("'", "", $this->input->post("password")));
        $data["phone"]                          = str_replace("'", "", $this->input->post("phone"));
        $data["NPWP"]                           = str_replace("'", "", $this->input->post("NPWP"));
        $data["NIK"]                            = str_replace("'", "", $this->input->post("NIK"));
        $data["user_to_company_id"]             = str_replace("'", "", $this->input->post("user_to_company_id"));
        $data["nationality"]                    = str_replace("'", "", $this->input->post("nationality"));
        $data["company_id"]                     = str_replace("'", "", $this->input->post("company_id"));
        
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_client();
            $data["image"]                      = $image;
        }
        $data["address"]                        = str_replace("'", "", $this->input->post("address"));
        $data["status_id"]                      = 1;
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->createTable("user", $data);
        redirect("SuperAdmin/dataClient");
    }
    public function _do_upload_client() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/client/";
        $config["allowed_types"]                = "jpg|png|jpeg";
        $config["max_size"]                     = 1000;
        $config["max_widht"]                    = 1500;
        $config["max_height"]                   = 1500;
        $config["file_name"]                    = $image_name;

        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
    // ============ superAdmin ============
    public function dataAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataAdmin"]                      = $this->M_user->getByWhere("status_id", 2);
        $this->load->view("superAdmin/v_dataAdmin", $data);
    }
    public function detailAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_user                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_user == "") {
            redirect("SuperAdmin/dataAdmin");
        } else {
            if (is_numeric($id_user)) {
                if ($this->M_table->totalByCon("user", "id", $id_user) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataClient"]         = $this->M_user->profile($id_user);
                }
                $this->load->view("superAdmin/v_detailAdmin", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }

    // ============ ADMIN ===========

    public function createAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["company"]                        = $this->M_table->getAll("company");
        $data["country"]                        = $this->M_table->getAll("country");
        $this->load->view("superAdmin/v_createAdmin", $data);
    }
    public function processCreateAdmin() {
        $data["name"]                           = str_replace("'", "", $this->input->post("name"));
        $data["position"]                       = str_replace("'", "", $this->input->post("position"));
        $data["email"]                          = str_replace("'", "", $this->input->post("email"));
        $data["password"]                       = md5(str_replace("'", "", $this->input->post("password")));
        $data["phone"]                          = str_replace("'", "", $this->input->post("phone"));
        $data["NPWP"]                           = str_replace("'", "", $this->input->post("NPWP"));
        $data["NIK"]                            = str_replace("'", "", $this->input->post("NIK"));
        $data["nationality"]                    = str_replace("'", "", $this->input->post("nationality"));
        $data["company_id"]                     = str_replace("'", "", $this->input->post("company_id"));
        $data["address"]                        = str_replace("'", "", $this->input->post("address"));
        $data["status_id"]                      = 2;
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["update_date"]                    = date("Y-m-d H:i:s");
        // print_r($data);exit();
        $this->M_table->createTable("user", $data);
        redirect("SuperAdmin/dataAdmin");
    }

    // ============ PASSWORD ============
    public function updatePassword() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $data["user"]                           = $this->M_user->profile($this->session->userdata("id"));
        if ($id == "") {
            redirect("SuperAdmin/dataClient");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("user", "id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["id"]                 = $id;
                    $data["client"]             = $this->M_table->getById("user", $id);
                }
                $this->load->view("superAdmin/v_updatePassword", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdatePassword() {
        $data["password"]                       = md5(str_replace("'", "", $this->input->post("password")));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        if ($this->M_table->getByCon("user", "id", $id)['status_id'] == 5) {
                        
            redirect("SuperAdmin/dataAdministrasi");
            } else{
                
            redirect("SuperAdmin/dataClient");
            }
        $this->M_table->updateTable("user", $data, ["id" => $id]);
        redirect("SuperAdmin/dataClient");
    }
    public function updatePasswordA() {
        $id  = $this->session->userdata("id");
        if ($id == "") {
            redirect("SuperAdmin/profile");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("user", "id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["id"]                 = $id;
                    $data["user"]               = $this->M_user->profile($id);
                }
                $this->load->view("superAdmin/v_updatePasswordA", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdatePasswordA() {
        $data["password"]                       = md5(str_replace("'", "", $this->input->post("password")));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $id  = $this->session->userdata("id");
        $this->M_table->updateTable("user", $data, ["id" => $id]);
        redirect("SuperAdmin/profile");
    }
    public function processUpdatePasswordE() {
        $data["password"]                       = md5(str_replace("'", "", $this->input->post("password")));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $this->M_table->updateTable("employee", $data, ["id" => $id]);
        redirect("SuperAdmin/detailEmployee/" . $id);
    }
    // ============ EMPLOYEE ============
    public function dataEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataEmployee"]                   = $this->M_table->getEmployee();
        $this->load->view("superAdmin/v_dataEmployee", $data);
    }
    public function deleteEmployee() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $upload                                 = $this->M_table->getById("employee", $id);
        if (file_exists("assets/upload/images/employee/" . $upload["image"]) && $upload["image"]) {
            unlink("assets/upload/images/employee/" . $upload["image"]);
        }
        $this->M_table->deleteTable("employee", $id);
        redirect("SuperAdmin/dataEmployee");
    }
    public function detailEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_user                                = $this->uri->rsegment(3);
        if ($id_user == "") {
            redirect("SuperAdmin/dataEmployee");
        } else {
            if (is_numeric($id_user)) {
                if ($this->M_table->totalByCon("employee", "id", $id_user) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataEmployee"]       = $this->M_table->getEmployeeById($id_user);
                    $data["company"]                             = $this->M_table->getAll('company');
                    $data["position"]           = $this->M_table->getAll("position");
                }
                $this->load->view("superAdmin/v_detailEmployee", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdateEmployee() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $data                                   = [
            "employee_name" => str_replace("'", "", $this->input->post("name")), 
            "phone" => str_replace("'", "", $this->input->post("phone")), 
            "email" => str_replace("'", "", $this->input->post("email")), 
            "gender" => str_replace("'", "", $this->input->post("gender")), 
            "company_id" => str_replace("'", "", $this->input->post("company_id")), 
            "position" => str_replace("'", "", $this->input->post("position")), 
            "status_id" => str_replace("'", "", $this->input->post("status_id")), 
            "address" => str_replace("'", "", $this->input->post("address")), 
            "date_of_birth" => str_replace("'", "", $this->input->post("birth")), 
            "update_date" => date("Y-m-d H:i:s"), 
            "create_date" => date("Y-m-d H:i:s")
        ];
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_employee();
            $upload                             = $this->M_table->getById("employee", $id);
            if (file_exists("assets/upload/images/employee/" . $upload["image"]) && $upload["image"]) {
                unlink("assets/upload/images/employee/" . $upload["image"]);
            }
            $data["image"]                      = $image;
        }
        $this->M_table->updateTable("employee", $data, ["id" => $id]);
        redirect("SuperAdmin/detailEmployee/" . $id);
    }
    public function updatePasswordEmployee() {
        $id  = $this->session->userdata("id");
        $employee_id                            = str_replace("'", "", $this->uri->rsegment(3));
        $data["user"]                           = $this->M_user->profile($id);
        if ($employee_id == "") {
            redirect("SuperAdmin/dataEmployee");
        } else {
            if (is_numeric($employee_id)) {
                if ($this->M_table->totalByCon("employee", "id", $employee_id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["employee"]           = $this->M_table->getEmployeeById($employee_id);
                    $data["id"]                 = $this->M_table->getEmployeeById($employee_id) ["id"];
                }
                $this->load->view("superAdmin/v_updatePasswordEmployee", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function createEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["status"]                         = $this->M_table->getAll("position");
        $this->load->view("superAdmin/v_createEmployee", $data);
    }
    public function processCreateEmployee() {
        $data                                   = [
            "employee_name" => str_replace("'", "", $this->input->post("name")), 
            "phone" => str_replace("'", "", $this->input->post("phone")), 
            "gender" => str_replace("'", "", $this->input->post("gender")), 
            "position" => str_replace("'", "", $this->input->post("position")), 
            "address" => str_replace("'", "", $this->input->post("address")), 
             "email" => str_replace("'", "", $this->input->post("email")), 
             "password" => md5(str_replace("'", "", $this->input->post("password"))), 
            "status_id" => str_replace("'", "", $this->input->post("status_id")), 
            "date_of_birth" => str_replace("'", "", $this->input->post("birth")), 
            "update_date" => date("Y-m-d H:i:s"), 
            "create_date" => date("Y-m-d H:i:s")
            ];
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_employee();
            $data["image"]                      = $image;
        }
        $this->M_upload->insertEmployee($data);
        redirect("SuperAdmin/dataEmployee");
    }
    // ==================== PROFILE ====================
    public function profile() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataUser"]                       = $this->M_user->profile($id);
        $data["resume"]                         = $this->M_table->getResume($id);
        $data["sub_resume"]                     = $this->M_table->getSubResume($id);
        $data["sr"]                             = $this->M_table->getAll('sub_resume');
        $data["scr"]                            = $this->M_table->getAll('sub_category_resume');
        // print_r($data['resume']); exit();
        $this->load->view("superAdmin/v_profile", $data);
    }
    public function updateProfile() {
        $id                     = $this->session->userdata('id');
		$data['name']           = addslashes($this->input->post('name'));
		$data['phone']          = addslashes($this->input->post('phone'));
		$data['email']          = addslashes($this->input->post('email'));
		$data['address']        = addslashes($this->input->post('address'));
		$data['NPWP']           = addslashes($this->input->post('NPWP'));
		$data['NIK']            = addslashes($this->input->post('NIK'));
		$data['position']       = addslashes($this->input->post('position'));
		$data['nationality']    = addslashes($this->input->post('nationality'));

		if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_profile();
            $upload                             = $this->M_table->getById("user", $id);
            if (file_exists("assets/upload/images/admin/" . $upload["image"]) && $upload["image"]) {
                unlink("assets/upload/images/admin/" . $upload["image"]);
            }
            $data["image"]                      = $image;
        }
		$data ['update_date']   = date("Y-m-d H:i:s");
        $this->M_table->updateTable('user',$data,array('id' =>$id));
        redirect("SuperAdmin/profile");
    }
    public function _do_upload_profile() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/admin/";
        $config["allowed_types"]                = "jpg|png|jpeg";
        $config["file_name"]                    = $image_name;

        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
    public function _do_upload_resume() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/resume/";
        $config["allowed_types"]                = "jpg|png|jpeg";
        $config["max_size"]                     = 10000;
        $config["max_widht"]                    = 15000;
        $config["max_height"]                   = 15000;
        $config["file_name"]                    = $image_name;
        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            echo "image format not met";
            exit(); 
        }
        return $this->upload->data("file_name");
    }
    public function processCreateResume() {
        $data                                   = [
            "user_id" => $this->session->userdata("id"),
             "update_date" => date("Y-m-d H:i:s"),
             "create_date" => date("Y-m-d H:i:s") ];
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_resume();
            $data["image"]                      = $image;
        }
        $this->M_table->createTable('resume',$data);
        redirect("SuperAdmin/profile");
    }
    public function processUpdateResume() {
    $id  = str_replace("'", "", $this->input->post("resume_id"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_resume();
            $upload                             = $this->M_table->getById("resume", $id);
            if (file_exists("assets/upload/images/resume/" . $upload["image"]) && $upload["image"]) {
                unlink("assets/upload/images/resume/" . $upload["image"]);
            }
            $data["image"]                      = $image;
        }
        $this->M_table->updateTable("resume", $data, ["id" => $id]);
        redirect("SuperAdmin/profile");
    }
    public function processCreateCategory() {
        $data = ["subCategory" => str_replace("'", "", $this->input->post("subCategory"))];
        $this->M_table->createTable('sub_category_resume',$data);
        redirect("SuperAdmin/profile");
    }
    public function processCreateSubR() {
        $data = [
            "subCategory_id" => str_replace("'", "", $this->input->post("subCategory_id")),
            "resume_id" => str_replace("'", "", $this->input->post("resume_id")),
            "date" => str_replace("'", "", $this->input->post("date")),
            "subResume" => str_replace("'", "", $this->input->post("subResume")),
            "update_date" => date("Y-m-d H:i:s"),
            "create_date" => date("Y-m-d H:i:s"),
        ];
        $this->M_table->createTable('sub_resume',$data);
        redirect("SuperAdmin/profile");
    }
    public function processUpdateSubR() {
        $id = str_replace("'", "", $this->input->post("id"));
        $data = [
            "subCategory_id" => str_replace("'", "", $this->input->post("subCategory_id")),
            "date" => str_replace("'", "", $this->input->post("date")),
            "subResume" => str_replace("'", "", $this->input->post("subResume")),
            "update_date" => date("Y-m-d H:i:s")
        ];
        $this->M_table->updateTable('sub_resume',$data,array('id' => $id));
        redirect("SuperAdmin/profile");
    }
    public function processDeleteSubR() {
        $id                       = str_replace("'", "", $this->uri->rsegment(3));
        $this->M_table->deleteTable('sub_resume', $id);
        redirect("SuperAdmin/profile");
    }
    // ==================== PCOMPANY ====================
    public function dataCompany() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataCompany"]                    = $this->M_table->getAll("company");
        $this->load->view("superAdmin/v_dataCompany", $data);
    }
    public function createCompany() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $this->load->view("superAdmin/v_createCompany", $data);
    }
    public function processCreateCompany() {
        $data["company"]                        = str_replace("'", "", $this->input->post("company"));
        $data["company_phone"]                  = str_replace("'", "", $this->input->post("company_phone"));
        $data["company_email"]                  = str_replace("'", "", $this->input->post("company_email"));
        $data["NPWP"]                           = str_replace("'", "", $this->input->post("company_NPWP"));
        $data["typeBusiness"]                   = str_replace("'", "", $this->input->post("typeBusiness"));
        $data["addressOfDomicile"]              = str_replace("'", "", $this->input->post("addressOfDomicile"));
        $data["businessEntity"]                 = str_replace("'", "", $this->input->post("businessEntity"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        // print_r($data);
        // exit();
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload();
            $data["image"]                      = $image;
        }
        $this->M_upload->insert($data);
        redirect("SuperAdmin/dataCompany");
    }
    public function updateCompany() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_company                             = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_company == "") {
            redirect("SuperAdmin/dataCompany");
        } else {
            if (is_numeric($id_company)) {
                if ($this->M_table->totalByCon("company", "id", $id_company) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["id"]                 = $id_company;
                    $data["dataUser"]           = $this->M_table->getById("company", $id_company);
                }
                $this->load->view("superAdmin/v_updateCompany", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdateCompany() {
        $id                               = str_replace("'", "", $this->uri->rsegment(3));
        $data["company"]                  = str_replace("'", "", $this->input->post("company"));
        $data["company_phone"]            = str_replace("'", "", $this->input->post("company_phone"));
        $data["company_email"]            = str_replace("'", "", $this->input->post("company_email"));
        $data["NPWP"]                     = str_replace("'", "", $this->input->post("company_NPWP"));
        $data["typeBusiness"]             = str_replace("'", "", $this->input->post("typeBusiness"));
        $data["addressOfDomicile"]        = str_replace("'", "", $this->input->post("addressOfDomicile"));
        $data["businessEntity"]           = str_replace("'", "", $this->input->post("businessEntity"));
        $data["website"]                  = str_replace("'", "", $this->input->post("website"));
        $data["SKMHHAM"]                  = str_replace("'", "", $this->input->post("SKMHHAM"));
        $data["deeds_of_establishment"]   = str_replace("'", "", $this->input->post("deeds_of_establishment"));
        $data["deeds_of_revisions"]       = str_replace("'", "", $this->input->post("deeds_of_revisions"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload();
            $upload                             = $this->M_table->getById("company", $id);
            if (file_exists("assets/upload/images/" . $upload["image"]) && $upload["image"]) {
                unlink("assets/upload/images/" . $upload["image"]);
            }
            $data["image"]                      = $image;
        }
        $this->M_table->updateTable("company", $data, ["id" => $id]);
        redirect("SuperAdmin/dataCompany");
    }
    // ==================== REPORT ====================
    public function processCreateReport() {
        $data                                   = ["process_id" => str_replace("'", "", $this->input->post("process_id")), "message" => str_replace("'", "", $this->input->post("message")), "update_date" => date("Y-m-d H:i:s"), "create_date" => date("Y-m-d H:i:s"), ];
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_report();
            $data["report"]                     = $image;
        }
        $forReview["report_id"]                 = $this->M_table->createTableOrder("process_report", $data);
        $forReview["ending_date"]               = str_replace("'", "", $this->input->post("ending_date"));
        $forReview["create_date"]               = date("Y-m-d H:i:s");
        $forReview["update_date"]               = date("Y-m-d H:i:s");
        $this->M_table->createTable("report_review", $forReview);
        redirect("SuperAdmin/progressOrder/" . str_replace("'", "", $this->input->post("order_id")));
    }
    public function deleteReport() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $data                                   = $this->M_table->getById("process_report", $id);
        if (file_exists("assets/upload/images/employee/" . $data["report"]) && $data["report"]) {
            unlink("assets/upload/report/" . $data["report"]);
        }
        $this->M_table->deleteTable("process_report", $id);
        redirect("SuperAdmin/progressOrder/" . str_replace("'", "", $this->uri->rsegment(4)));
    }
    public function updateReport() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $report_id                              = str_replace("'", "", $this->uri->rsegment(3));
        if ($report_id == "") {
            redirect("SuperAdmin/dataAdmin");
        } else {
            if (is_numeric($report_id)) {
                if ($this->M_table->totalByCon("process_report", "id", $report_id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataReport"]         = $this->M_table->detailReport($report_id);
                }
                $this->load->view("superAdmin/v_updateReport", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    // ==================== UPLOAD FILE ====================
    public function _do_upload() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/";
        $config["allowed_types"]                = "gif|jpg|png|webp";
        $config["max_size"]                     = 10000;
        $config["max_widht"]                    = 15000;
        $config["max_height"]                   = 15000;
        $config["file_name"]                    = $image_name;
        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
    public function _do_upload_news() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/news/";
        $config["allowed_types"]                = "jpg|png|jpeg";
        $config["max_size"]                     = 10000;
        $config["max_widht"]                    = 15000;
        $config["max_height"]                   = 15000;
        $config["file_name"]                    = $image_name;
        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            echo "image format not met";
            exit(); 
        }
        return $this->upload->data("file_name");
    }
    public function _do_upload_employee() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/images/employee/";
        $config["allowed_types"]                = "gif|jpg|png";
        $config["max_size"]                     = 1000;
        $config["max_widht"]                    = 1500;
        $config["max_height"]                   = 1500;
        $config["file_name"]                    = $image_name;
        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
    public function _do_upload_report() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/report/";
        $config["allowed_types"]                = "pdf|jpg|png|jpeg|xlsx|doc|odt";
        $config["max_size"]                     = 10000;
        $config["max_widht"]                    = 15000;
        $config["max_height"]                   = 15000;
        $config["file_name"]                    = $image_name;
        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
    // ==================== FEEDBACK ====================
    public function dataFeedback() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataOrder"]                      = $this->M_table->dataOrderAll();
        $this->load->view("superAdmin/v_dataFeedback", $data);
    }
    public function feedbackOrder() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $order_id                               = str_replace("'", "", $this->uri->rsegment(3));

        if ($order_id == "") {
            redirect("SuperAdmin/dataFeedback");
        } else {
            if (is_numeric($order_id)) {
               
                $data["feedbackEmployee"]       = $this->M_user->dataFeedback2(1 . ' AND feedback.order_id = ' . $order_id);
                $data["feedbackCompany"]        = $this->M_user->dataFeedback3(2 . ' AND feedback.order_id = ' . $order_id);

                
                $data['selected']             = $this->M_table->getOrder($order_id);
                $data['criteria']             = $this->M_user->getCriteria('criteria');
                $data['staff']                = $this->M_table->getDataStaff($order_id);
                $data['staff2']               = $this->M_table->getStaffFromFeedbackFromCeo($order_id);
                $data['dataFeedback']   	  = $this->M_table->dataFeedbackFromCEO($order_id);
                // print_r($data['dataFeedback']);exit();

                $this->load->view("superAdmin/v_feedbackOrder", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processCreateFeedback(){
		$total = $this->input->post('total');
		$bantu = [];
		$rat   = [];
		for ($i=1; $i <= $total ; $i++) {
			$rating = "rating".$i;
			$number = $this->input->post($rating);
			array_push($bantu,$number);
		}
		$forCriteria['order_id']              = addslashes($this->input->post('order_id'));
		$forCriteria['employee_id']           = addslashes($this->input->post('employee_id'));
		$forCriteria ['update_date']          = date("Y-m-d H:i:s");
        $forCriteria ['create_date']    	  = date("Y-m-d H:i:s");
        
		foreach ($bantu as $row) {
			$forCriteria['rating']		=substr($row,0,strlen($row)-(strlen($row)-1));
			array_push($rat,$forCriteria['rating']);
			$forCriteria['criteria_id'] = substr($row,1);
			$this->M_table->createTable('feedback_criteria_from_ceo',$forCriteria);
		}
		$data['feedback']               = addslashes($this->input->post('feedback'));
		$data['star']                   = array_sum($rat)/count($bantu);
		$data['employee_id']            = addslashes($this->input->post('employee_id'));
		$data['categoryFeedback_id']    = addslashes($this->input->post('categoryFeedback_id'));
		$data['order_id']    			= addslashes($this->input->post('order_id'));
		$data ['update_date']           = date("Y-m-d H:i:s");
        $data ['create_date']     		= date("Y-m-d H:i:s");
        $this->M_table->createTable('feedback_from_ceo',$data);
		redirect('SuperAdmin/feedbackOrder/'.$data['order_id']);
	}
    public function detailFeedbackEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);

        $id_feedback                            = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_feedback == "") {
            redirect("SuperAdmin/dataFeedback");
        } else {
            if (is_numeric($id_feedback)) {
                if ($this->M_table->totalByCon("feedback", "id", $id_feedback) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["feedbackEmployee"]   = $this->M_user->detailFeedback1($id_feedback);
                    $data['dataCriteria']       = $this->M_employee->getCriteria($data["feedbackEmployee"]['order_id'],$data["feedbackEmployee"]['employee_id']);
                    // print_r($data['dataCriteria']);
                    // exit();
                }
                $this->load->view("superAdmin/v_detailFeedbackE", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function detailFeedbackCompany() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("SuperAdmin/dataFeedback");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("feedback", "id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["feedbackEmployee"]   = $this->M_user->detailFeedback2($id);
                }
                $this->load->view("superAdmin/v_detailFeedbackC", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    
	public function detailFeedback(){
		$feedback_id                    = $this->uri->rsegment(3);
        $data['user']           		= $this->M_user->profile($this->session->userdata('id'));
		if ($feedback_id=="") {
			redirect('SuperAdmin/Lock');
		}
		else{
			if(is_numeric($feedback_id)){
				if ($this->M_table->totalByCon('feedback_from_ceo','id', $feedback_id)==0) {
                    redirect('SuperAdmin/Lock');
				}
				else{
					$data['validate']        = true;
					$data['dataFeedback']    = $this->M_table->detailFeedback($feedback_id); 
					$data['dataFeedback2']   = $this->M_table->getFeedback($data['dataFeedback']['order_id'],$data['dataFeedback']['employee_id']);
					$data['dataCriteria']    = $this->M_table->getCriteria($data['dataFeedback']['order_id'],$data['dataFeedback']['employee_id']);
				}
				$this->load->view('superAdmin/v_detailFeedback',$data);
			}
			else{
                redirect('SuperAdmin/Lock');
			}
		}
	}
    // ==================== PROJECT ====================
    public function dataProject() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataProject"]                    = $this->M_table->getAll("services");
        $this->load->view("superAdmin/v_dataProject", $data);
    }
    public function createProject() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["category"]                       = $this->M_table->getAll("categoryservice");
        $this->load->view("superAdmin/v_createProject", $data);
    }
    public function processCreateProject() {
        $data["service_name"]                   = str_replace("'", "", $this->input->post("name"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($category == "") {
            $data["category_service_id"]        = str_replace("'", "", $this->input->post("category_id"));
            $this->M_table->createTable("services", $data);
            redirect("SuperAdmin/dataProject");
        } else {
            if (is_numeric($category)) {
                $data["category_service_id"]    = str_replace("'", "", $category);
                $this->M_table->createTable("services", $data);
                redirect("SuperAdmin/detailWorkflow/" . $category);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function deleteProject() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $this->M_table->deleteTable("services", $id);
        redirect("SuperAdmin/dataProject");
    }
    public function updateProject() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_service                             = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_service == "") {
            redirect("SuperAdmin/dataProject");
        } else {
            if (is_numeric($id_service)) {
                if ($this->M_table->totalByCon("services", "id", $id_service) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["project"]            = $this->M_table->getById("services", $id_service);
                    $data["category"]           = $this->M_table->getAll("categoryservice");
                }
                $this->load->view("superAdmin/v_updateProject", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdateProject() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $data["service_name"]                   = str_replace("'", "", $this->input->post("name"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $data["category_service_id"]            = str_replace("'", "", $this->input->post("category_id"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->updateTable("services", $data, ["id" => $id]);
        redirect("SuperAdmin/dataProject");
    }
    // ==================== ORDER ====================
    public function dataOrder() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["orderOn"]                        = $this->M_table->dataOrder("'do'");
        $data["orderOff"]                       = $this->M_table->dataOrder("'done'");
        $this->load->view("superAdmin/v_dataOrder", $data);
    }
    public function addOrder() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataClient"]                     = $this->M_user->getByWhere("status_id", 1);
        $data["dataService"]                    = $this->M_table->getAll("services");
        $data["partner"]                        = $this->M_table->getEmployeeStatus(1);
        $data["manager"]                        = $this->M_table->getEmployeeStatus(2);
        $data["supervisor"]                     = $this->M_table->getEmployeeStatus(3);
        $data["staff"]                          = $this->M_table->getEmployeeStatus(4);
        $data["country"]                        = $this->M_table->getAll("country");
        $this->load->view("superAdmin/v_createOrder", $data);
    }
    public function updateOrder() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_order                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_order == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order)) {
                if ($this->M_table->totalByCon("order", "id", $id_order) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataService"]        = $this->M_table->getAll("services");
                    $data["dataClient"]         = $this->M_user->getByWhere("status_id", 1);
                    $data["partner"]            = $this->M_table->getEmployeeStatus(1);
                    $data["manager"]            = $this->M_table->getEmployeeStatus(2);
                    $data["supervisor"]         = $this->M_table->getEmployeeStatus(3);
                    $data["staff"]              = $this->M_table->getEmployeeStatus(4);
                    $data["staffSelected"]      = $this->M_table->getDataStaff($id_order);
                    $data["stepSelected"]       = $this->M_table->getFlow($id_order);
                    $data["subSelected"]        = $this->M_table->getSubFlow($id_order);
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["person"]             = $this->M_user->person($id_order);
                    $data["country"]            = $this->M_table->getAll("country");
                }
                $this->load->view("superAdmin/v_updateOrder", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    
    public function deleteActivities() {
        $subStep                               = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                                = str_replace("'", "", $this->uri->rsegment(4));
        if ($subStep == "" || $order_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($subStep) && is_numeric($order_id)) {
                $this->M_table->deleteTable("substep", $subStep);
                redirect("SuperAdmin/updateOrderStep/" . $order_id);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function updateActivities() {
        $subStep                               = str_replace("'", "", $this->input->post("subStep_id"));
        $order_id                              = str_replace("'", "", $this->input->post("order_id"));
        $data['subStep']                              = str_replace("'", "", $this->input->post("subStep"));
        $data["update_date"]                         = date("Y-m-d H:i:s");
        if ($subStep == "" || $order_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($subStep) && is_numeric($order_id)) {
                $this->M_table->updateTable("substep", $data, ["id" => $subStep]);
                redirect("SuperAdmin/updateOrderStep/" . $order_id);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function updateSubStep() {
        $subStep     = str_replace("'", "", $this->input->post("subStep_id"));
        $step     = str_replace("'", "", $this->input->post("step_id"));
        $data['subStep']                              = str_replace("'", "", $this->input->post("subStep"));
        $data["update_date"]                         = date("Y-m-d H:i:s");
        if ($subStep == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($subStep)) {
                $this->M_table->updateTable("substep", $data, ["id" => $subStep]);
                redirect("SuperAdmin/detailStep/". $step);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function updateDataStep()
    {
        $data["step"]                           = str_replace("'", "", $this->input->post("step"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $id                    = str_replace("'", "", $this->input->post("id"));
        $data["drive"]                    = str_replace("'", "", $this->input->post("drive"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->updateTable("step", $data, ["id" => $id]);
        redirect('SuperAdmin/workflow/'.str_replace("'", "", $this->input->post("service_id")));
    }
    public function processUpdateOrder() {
        $data["user_id"]                        = str_replace("'", "", $this->input->post("client"));
        $data["message"]                        = str_replace("'", "", $this->input->post("message"));
        $data["partner_id"]                     = str_replace("'", "", $this->input->post("partner"));
        $data["financial_statements"]           = str_replace("'", "", $this->input->post("financial_statements"));
        $data["manager_id"]                     = str_replace("'", "", $this->input->post("manager"));
        $data["supervisor_id"]                  = str_replace("'", "", $this->input->post("supervisor"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $order_id                               = str_replace("'", "", $this->input->post("order_id"));
        $service_id                             = str_replace("'", "", $this->input->post("service_id_s"));
        $service                                = str_replace("'", "", $this->input->post("service"));
        $forPerson["name"]                      = str_replace("'", "", $this->input->post("person_responsible"));
        $forPerson["NIK"]                       = str_replace("'", "", $this->input->post("NIK"));
        $forPerson["NPWP"]                      = str_replace("'", "", $this->input->post("NPWP"));
        $forPerson["position"]                  = str_replace("'", "", $this->input->post("position"));
        $forPerson["nationality"]               = str_replace("'", "", $this->input->post("nationality"));
        $forPerson["address"]                   = str_replace("'", "", $this->input->post("address"));
        $forPerson["phone"]                     = str_replace("'", "", $this->input->post("phone"));
        $forPerson["email"]                     = str_replace("'", "", $this->input->post("email"));
        $forPerson["order_id"]                  = $order_id;

        $this->M_table->updateTable("person_responsible", $forPerson, ["order_id" => $order_id, ]);
        if ($service != $service_id) {
            $data["service_id"]                 = $service;
            $this->M_table->deleteTableCon("order_step", "order_id", $order_id); //delete staff lama
            
        }
        $this->M_table->updateTable("order", $data, ["id" => $order_id]); //update tabel order
        $this->M_table->deleteTableCon("order_staff", "order_id", $order_id); //delete staff lama
        $staff_id                               = str_replace("'", "", $this->input->post("staff"));
        $data_staff["order_id"]                 = $order_id;
        foreach ($staff_id as $user_id) {
            $data_staff["employee_id"]          = $user_id;
            $this->M_table->createTable("order_staff", $data_staff); //create staff baru
            
        }
        redirect("SuperAdmin/detailOrder/" . $order_id);
    }
    public function updateOrderStep() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_order                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_order == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order)) {
                if ($this->M_table->totalByCon("order", "id", $id_order) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["substep"]            = $this->M_table->getSubFlowByService($data["dataOrder"]["service_id"]);
                    $data["substepOld"]         = $this->M_table->getSubFlow($id_order);
                    $data["step"]               = $this->M_table->dataTableWhere("step", "service_id", $data["dataOrder"]["service_id"]);
                }
                $this->load->view("superAdmin/v_updateOrderStep", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processUpdateOrderStep() {
        $id  = str_replace("'", "", $this->input->post("step"));
        $data["order_id"]                       = str_replace("'", "", $this->input->post("order_id"));
        $tSubOld                                = [];
        $tSubNew                                = [];
        $subOld                                 = $this->M_table->getSubFlow($data["order_id"]);
        foreach ($subOld as $row) {
            array_push($tSubOld, $row["subStep_id"]);
        }
        foreach ($id as $row) {
            if (in_array($row, $tSubOld)) {
                continue;
            } else {
                array_push($tSubNew, $row);
            }
        }
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        foreach ($tSubNew as $row) {
            $data["subStep_id"]                 = $row;
            $this->M_table->createTable("order_step", $data);
        }
        redirect("SuperAdmin/detailOrder/" . $data["order_id"]);
    }
    public function deleteOrder() {
        $id_order                               = str_replace("'", "", $this->uri->rsegment(3));
        $this->M_table->deleteTableCon("order", "id", $id_order);
        $this->M_table->deleteTableCon("order_staff", "order_id", $id_order);
        $this->M_table->deleteTableCon("order_step", "order_id", $id_order);
        $this->M_table->deleteTableCon("data", "order_id", $id_order);
        $this->M_table->deleteTableCon("chatt", "order_id", $id_order);
        foreach ($this->M_table->getByCon("process", "order_id", $id_order) as $row) {
            $this->M_table->deleteTableCon("process_report", "process_id", $row['id']);
        }
        $id_output  = $this->M_table->getByCon("output", "order_id", $id_order);
        $this->M_table->deleteTableCon("output", "order_id", $id_order);
        $this->M_table->deleteTableCon("meeting", "output_id", $id_output["id"]);
        $this->M_table->deleteTableCon("process", "order_id", $id_order);
        redirect("SuperAdmin/dataOrder");
    }
    public function processCreateOrder() {
        $data["service_id"]                     = str_replace("'", "", $this->input->post("service"));
        $data["user_id"]                        = str_replace("'", "", $this->input->post("client"));
        $data["financial_statements"]           = str_replace("'", "", $this->input->post("financial_statements"));
        $data["message"]                        = str_replace("'", "", $this->input->post("message"));
        $data["partner_id"]                     = str_replace("'", "", $this->input->post("partner"));
        $data["manager_id"]                     = str_replace("'", "", $this->input->post("manager"));
        $data["supervisor_id"]                  = str_replace("'", "", $this->input->post("supervisor"));
        $data["statusOrder_id"]                 = 1;
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data_staff["order_id"]                 = $this->M_table->createTableOrder("order", $data);
        $forPerson["name"]                      = str_replace("'", "", $this->input->post("person_responsible"));
        $forPerson["NIK"]                       = str_replace("'", "", $this->input->post("NIK"));
        $forPerson["NPWP"]                      = str_replace("'", "", $this->input->post("NPWP"));
        $forPerson["position"]                  = str_replace("'", "", $this->input->post("position"));
        $forPerson["nationality"]               = str_replace("'", "", $this->input->post("nationality"));
        $forPerson["address"]                   = str_replace("'", "", $this->input->post("address"));
        $forPerson["phone"]                     = str_replace("'", "", $this->input->post("phone"));
        $forPerson["email"]                     = str_replace("'", "", $this->input->post("email"));
        $forPerson["order_id"]                  = $data_staff["order_id"];
        $this->M_table->createTable("person_responsible", $forPerson);
        $forOutput["update_date"]               = date("Y-m-d H:i:s");
        $forOutput["create_date"]               = date("Y-m-d H:i:s");
        $forOutput["order_id"]                  = $data_staff["order_id"];
        $forMeeting["output_id"]                = $this->M_table->createTableOrder("output", $forOutput);
        $this->M_table->createTable("meeting", $forMeeting);
        $forData["user_id"]                     = $data["user_id"];
        $forData["order_id"]                    = $data_staff["order_id"];
        $forData["create_date"]                 = date("Y-m-d H:i:s");
        $forData["update_date"]                 = date("Y-m-d H:i:s");
        $forData["status"]                      = "not yet";
        for ($i = 1;$i < 3;$i++) {
            $forData["data_id"]                 = $i;
            $this->M_table->createTable("data", $forData);
        }
        $forReport["order_id"]                  = $data_staff["order_id"];
        $forReport["create_date"]               = date("Y-m-d H:i:s");
        $forReport["update_date"]               = date("Y-m-d H:i:s");
        $staff_id                               = str_replace("'", "", $this->input->post("staff"));
        foreach ($staff_id as $user_id) {
            $data_staff["employee_id"]          = $user_id;
            $this->M_table->createTable("order_staff", $data_staff);
        }
        redirect("SuperAdmin/dataOrder");
    }
    public function detailOrder() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_order                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_order == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order)) {
                if ($this->M_table->totalByCon("order", "id", $id_order.' AND statusOrder_id = 1') == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["dataStaff"]          = $this->M_table->getDataStaff($id_order);
                    $id                         = $data["dataOrder"]["service_id"];
                    $data["step"]               = $this->M_table->getFlow($id_order);
                    $data["substep"]            = $this->M_table->getSubFlow($id_order);
                    $data["person"]             = $this->M_user->person($id_order);
                }
                $this->load->view("superAdmin/v_detailOrder", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function approveReport() {
        $review_id                    	= $this->uri->rsegment(3);
		if ($review_id=="" || $this->uri->rsegment(4) == "") {
			redirect('SuperAdmin/lock');
		}
		else{
			if(is_numeric($review_id) || is_numeric($this->uri->rsegment(4))){
				if ($this->M_table->totalByCon('report_review','id', $review_id)==0) {
					redirect('SuperAdmin/lock');
				}
				if ($this->M_table->getById('report_review',$review_id)['review_ceo'] == "do") {
					$data['review_ceo'] = "done";
				} else{
					$data['review_ceo'] = "do";
				}
				$this->M_table->updateTable("report_review", $data, ["id" => $review_id]);
				redirect('SuperAdmin/progressOrder/'.$this->uri->rsegment(4));
			}
			else{
				redirect('SuperAdmin/lock');
			}
		}
    }
    public function updateStatusMeeting()
    {
        $meeting_id                             = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                               = str_replace("'", "", $this->uri->rsegment(4));
        if ($meeting_id == "" || $order_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($meeting_id) && is_numeric($order_id)) {
                if ($this->M_table->getById('meeting',$meeting_id)['status']=="do") {
                    $data['status']         = "done";
                } else{
                    $data['status']         = "do";
                }
                $this->M_table->updateTable("meeting", $data, ["id" => $meeting_id]);
                redirect('SuperAdmin/progressOrder/'.$order_id);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function deleteMeeting() {
        $id_order  = str_replace("'", "", $this->uri->rsegment(4));
        $id_meeting  = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_order == "" || $id_meeting == "" ) {
            redirect('SuperAdmin/lock');
        } else{
            if (is_numeric($id_order) && is_numeric($id_meeting) ) {
                if ($this->M_table->totalByCon("order", "id", $id_order) == 0) {
                    redirect('SuperAdmin/lock');
                } else {
                    $meeting = $this->M_table->getMeeting($id_order);
                    $action                                 = ["admin_id" => $this->session->userdata("id"), "action" => "Delete Meeting in " . $meeting['via'], "action_date" => date("Y-m-d H:i:s"), ];
                    $this->M_table->createTable("history_action_admin", $action);
                    $this->M_table->deleteTable("meeting", $id_meeting);
                    redirect("SuperAdmin/progressOrder/".$id_order);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function createMeeting() {
        $data['via']                            = str_replace("'", "", $this->input->post("via"));
        $data['link']                           = str_replace("'", "", $this->input->post("link"));
        $data['message']                           = str_replace("'", "", $this->input->post("message"));
        $order_id                               = str_replace("'", "", $this->input->post("id_order"));
        $data['output_id']                      = $this->M_table->getByCon('output','order_id',$order_id)['id'];
        $data['date']                           = str_replace("'", "", $this->input->post("date")).' '.str_replace("'", "", $this->input->post("time"));
        $this->M_table->createTable("meeting", $data);
        redirect('SuperAdmin/progressOrder/'.$order_id);
    }
    public function progressOrder() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_order                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_order == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order)) {
                if ($this->M_table->totalByCon("order", "id", $id_order.' AND statusOrder_id = 1') == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["letter"]             = $this->M_table->letter($id_order);
                    $data["dataProcess"]        = $this->M_table->getProcess($id_order);
                    $data["output"]             = $this->M_table->getOutput($id_order);
                    $data["dataStaff"]          = $this->M_table->getDataStaff($id_order);
                    $data["step"]               = $this->M_table->getFlow($id_order);
                    $data["subStep"]            = $this->M_table->getSubFlow($id_order);
                    $data["dataProcessDone"]    = $this->M_table->getProcessDone($id_order);
                    $data["report"]             = $this->M_table->getReport($id_order);
                    $data["review"]             = $this->M_table->getReview($id_order);
                    $data["dataMeeting"]        = $this->M_table->getAllMeeting($id_order);
					$data["dataContract"]       = $this->M_administrasi->getContract($id_order);
					$data["dataInvoice"] = $this->M_administrasi->getInvoice($id_order);
					$data["dataFile"] = $this->M_administrasi->getFile($id_order);
					$data["dataPayment"] = $this->M_table->dataTableWhere('proof_of_payment','order_id',$id_order);
                    
                    // percentage input
                    $total 						= count($data['letter']);
                    $done						= count($this->M_table->percenLetter($id_order,'done'));
                    $data['percentinput'] 		= round(((20)/$total)*$done,0);
                    $data['percentInputNow']    = round(($done/$total)*100,0);

                    // percentage progress
                    $total                		= count($this->M_table->getSubFlow($id_order));
                    if ($total == 0) {
                        $total = 1;
                    }
                    $data['total']        		= $total;
                    $done                 		= count($this->M_table->getProcessDone($id_order));
                    $data['totalDone']   		= $done;
                    
                    $data['percentProgressNow']    = round(($done/$total)*100,0);
                    if ($total == 0) {
                        if ($done == 0) {
                            $data['percentprocess'] = round(60,0);
                        }
                        else{
                            $data['percentprocess'] = round(60*$done,0);
                        }
                    }
                    else{
                        $data['percentprocess'] = round((60/$total)*$done,0);
                    }
                    // percentage output
                    $outputDone = $this->M_table->getReport($id_order);
                    $outputDone = count($outputDone);
                    $data['percentoutput'] = (20)/$total;
                    $data['percentoutput'] = round($data['percentoutput'] * $outputDone,0);
                    $data['conOutput'] = true;
                    

                    // percentage all
                    $data['percentall'] 		= $data['percentinput'] + $data['percentprocess']  +  $data['percentoutput'];
                    
                }
                $this->load->view("superAdmin/v_progressOrder", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function detailOrderDone() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_order                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_order == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order)) {
                if ($this->M_table->totalByCon("order", "id", $id_order.' AND statusOrder_id = 2') == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["letter"]             = $this->M_table->letter($id_order);
                    $data["dataProcess"]        = $this->M_table->getProcess($id_order);
                    $data["output"]             = $this->M_table->getOutput($id_order);
                    $data["dataStaff"]          = $this->M_table->getDataStaff($id_order);
                    $data["step"]               = $this->M_table->getFlow($id_order);
                    $data["subStep"]            = $this->M_table->getSubFlow($id_order);
                    $data["dataProcessDone"]    = $this->M_table->getProcessDone($id_order);
                    $data["report"]             = $this->M_table->getReport($id_order);
                    $data["review"]             = $this->M_table->getReview($id_order);
                    $data["meeting"]            = $this->M_table->getMeeting($id_order);
                }
                $this->load->view("superAdmin/v_detailOrderDone", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    // ==================== DATA ====================
    public function processUpdateData() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $data["status"]                         = str_replace("'", "", $this->input->post("status[]"));
        $notYet["status"]                       = "not yet";
        $this->M_table->updateTable("data", $notYet, ["order_id" => $id]);
        foreach ($data["status"] as $key) {
            $status["status"]                   = "done";
            $this->M_table->updateTable("data", $status, ["id" => $key]);
        }
        redirect("SuperAdmin/progressOrder/" . $id);
    }
    public function processCreateData() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $data["data"]                           = str_replace("'", "", $this->input->post("data"));
        $addData["data_id"]                     = $this->M_table->createTableOrder("detaildata", $data);
        $addData["order_id"]                    = $id;
        $addData["user_id"]                     = str_replace("'", "", $this->uri->rsegment(4));
        $addData["status"]                      = "not yet";
        $addData["create_date"]                 = date("Y-m-d H:i:s");
        $addData["update_date"]                 = date("Y-m-d H:i:s");
        $this->M_table->createTable("data", $addData);
        redirect("SuperAdmin/progressOrder/" . $id);
    }
    public function deleteData() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                               = str_replace("'", "", $this->uri->rsegment(4));
        $this->M_table->deleteTable("detaildata", $this->M_table->getById('data',$id)['data_id']);
        $this->M_table->deleteTable("data", $id);
        redirect("SuperAdmin/progressOrder/" . $order_id);
    }
    // ==================== PROGRESS ====================
    public function processCreateProgress() {
        $data["order_id"]                       = str_replace("'", "", $this->uri->rsegment(3));
        $data["order_step_id"]                  = str_replace("'", "", $this->input->post("order_step_id"));
        $data["employee_id"]                    = str_replace("'", "", $this->input->post("employee"));
        $data["status"]                         = str_replace("'", "", $this->input->post("status"));
        $data["estimasi"]                       = str_replace("'", "", $this->input->post("estimasi"));
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->createTable("process", $data);
        redirect("SuperAdmin/progressOrder/" . $data["order_id"]);
    }
    public function deleteProgress() {
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                               = str_replace("'", "", $this->uri->rsegment(4));
        $this->M_table->deleteTable("process", $id);
        redirect("SuperAdmin/progressOrder/" . $order_id);
    }
    public function processUpdateProgress() {
        $id  = str_replace("'", "", $this->uri->rsegment(4));
        $data["order_id"]                       = str_replace("'", "", $this->uri->rsegment(3));
        $data["order_step_id"]                  = str_replace("'", "", $this->input->post("os_id"));
        $order_step["subStep_id"]               = str_replace("'", "", $this->input->post("subStep"));
        $data["employee_id"]                    = str_replace("'", "", $this->input->post("employee"));
        $data["status"]                         = str_replace("'", "", $this->input->post("status"));
        $data["estimasi"]                       = str_replace("'", "", $this->input->post("estimasi"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->updateTable("order_step", $order_step, ["id" => $data["order_step_id"], ]);
        $this->M_table->updateTable("process", $data, ["id" => $id]);
        redirect("SuperAdmin/updateProgress/" . $id . "/" . $data["order_id"]);
    }
    public function updateProgress() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_progress                            = str_replace("'", "", $this->uri->rsegment(3));
        $id_order                               = str_replace("'", "", $this->uri->rsegment(4));
        $data["dataProcess"]                    = $this->M_table->getProcessByStep($id_progress);
        if ($id_order == "" || $id_progress == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order) && is_numeric($id_progress)) {
                if ($this->M_table->totalByCon("order", "id", $id_order) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["dataStaff"]          = $this->M_table->getDataStaff($id_order);
                    $data["order_id"]           = $id_order;
                    $data["subStep"]            = $this->M_table->getSubFlow($id_order);
                }
                $this->load->view("superAdmin/v_updateProgress", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function detailProgress() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_progress                            = str_replace("'", "", $this->uri->rsegment(3));
        $id_order                               = str_replace("'", "", $this->uri->rsegment(4));
        $data["dataProcess"]                    = $this->M_table->getProcessByStep($id_progress);
        if ($id_order == "" || $id_progress == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($id_order) && is_numeric($id_progress)) {
                if ($this->M_table->totalByCon("order", "id", $id_order) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["dataOrder"]          = $this->M_table->getDataOrder($id_order);
                    $data["dataStaff"]          = $this->M_table->getDataStaff($id_order);
                    $data["order_id"]           = $id_order;
                    $data["subStep"]            = $this->M_table->getSubFlow($id_order);
                }
                $this->load->view("superAdmin/", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function updateMeeting() {
        $id  = str_replace("'", "", $this->input->post("id"));
        $data['via']                            = str_replace("'", "", $this->input->post("via"));
        $data['link']                           = str_replace("'", "", $this->input->post("link"));
        $order_id                               = str_replace("'", "", $this->input->post("order_id"));
        $data['date']                           = str_replace("'", "", $this->input->post("date")).' '.str_replace("'", "", $this->input->post("time"));
        $this->M_table->updateTable("meeting", $data, ["id" => $id]);
        redirect('superAdmin/progressOrder/'.$order_id);
    }
    public function updateStatusMeetingP()
    {
        $meeting_id                             = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                               = str_replace("'", "", $this->uri->rsegment(4));
        if ($meeting_id == "" || $order_id == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($meeting_id) && is_numeric($order_id)) {
                if ($this->M_table->getById('meeting',$meeting_id)['permission']=="no") {
                    $data['permission']         = "yes";
                } else{
                    $data['permission']         = "no";
                }
                $this->M_table->updateTable("meeting", $data, ["id" => $meeting_id]);
                redirect('superAdmin/progressOrder/'.$order_id);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function updateStatusMeetingF()
    {
        $meeting_id                             = str_replace("'", "", $this->uri->rsegment(3));
        $order_id                               = str_replace("'", "", $this->uri->rsegment(4));
        if ($meeting_id == "" || $order_id == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($meeting_id) && is_numeric($order_id)) {
                if ($this->M_table->getById('meeting',$meeting_id)['fixed']=="no") {
                    $data['fixed']              = "yes";
                } else{
                    $data['fixed']              = "no";
                }
                $this->M_table->updateTable("meeting", $data, ["id" => $meeting_id]);
                redirect('superAdmin/progressOrder/'.$order_id);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function turnFinishOrder()
    {
        $order_id                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($order_id)) {
                $data['statusOrder_id']         = 2;
                $this->M_table->updateTable("order", $data, ["id" => $order_id]);
                redirect('superAdmin/dataOrder');
            } else {
                redirect("SuperAdmin/lock");
            }
        }
        
    }
    public function turnDoOrder()
    {
        $order_id                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("SuperAdmin/dataOrder");
        } else {
            if (is_numeric($order_id)) {
                $data['statusOrder_id']         = 1;
                $this->M_table->updateTable("order", $data, ["id" => $order_id]);
                redirect('superAdmin/dataOrder');
            } else {
                redirect("SuperAdmin/lock");
            }
        }
        
    }
    // ==================== WORKFLOW ====================
    public function dataWorkflow() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["c1"]                             = $this->M_table->getByCon("categoryservice", "id", 1);
        $data["c2"]                             = $this->M_table->getByCon("categoryservice", "id", 2);
        $data["c3"]                             = $this->M_table->getByCon("categoryservice", "id", 3);
        $data["c4"]                             = $this->M_table->getByCon("categoryservice", "id", 4);
        $data["data1"]                          = $this->M_table->totalByCon("services", "category_service_id", 1);
        $data["data2"]                          = $this->M_table->totalByCon("services", "category_service_id", 2);
        $data["data3"]                          = $this->M_table->totalByCon("services", "category_service_id", 3);
        $data["data4"]                          = $this->M_table->totalByCon("services", "category_service_id", 4);
        $data["data0"]                          = $this->M_table->totalByCon("services", "category_service_id", 0);
        $this->load->view("superAdmin/v_dataWorkflow", $data);
    }
    public function detailWorkflow() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id  = str_replace("'", "	", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("SuperAdmin/dataWorkflow");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("categoryservice", "id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["selected"]           = $this->M_table->getByCon("categoryservice", "id", $id);
                    $data["service"]            = $this->M_table->getService($id);
                }
                $this->load->view("superAdmin/v_detailWorkflow", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function workflow() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect("SuperAdmin/dataWorkflow");
        } else {
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("services", "id", $id) > 0) {
                    $data["service"]            = $this->M_table->getByCon("services", "id", $id);
                }
                if ($this->M_table->totalByCon("step", "service_id", $id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = "hm";
                    $data["selected"]           = $this->M_table->dataTableWhere("step", "service_id", $id . ' ORDER BY id');
                }
                $this->load->view("superAdmin/v_step", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processCreateStep() {
        $data["step"]                           = str_replace("'", "", $this->input->post("name"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $con = str_replace("'", "", $this->input->post("con"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        if (is_numeric($category)) {
            $data["service_id"]                 = str_replace("'", "", $category);
            $this->M_table->createTable("step", $data);
        }
        if ($con == "") {
            redirect("SuperAdmin/workflow/" . $category);
        } else {
            $order_id                           = str_replace("'", "", $this->input->post("order_id"));
            redirect("SuperAdmin/updateOrderStep/" . $order_id);
        }
    }
    public function deleteStep() {
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        $service                                = str_replace("'", "", $this->uri->rsegment(4));
        if ($category == "" || $service == "") {
            redirect("SuperAdmin/dataWorkflow");
        } else {
            if (is_numeric($category) && is_numeric($service)) {
                $this->M_table->deleteTable("step", $category);
                $step                           = $this->M_table->getByCon("step", "id", $category) ["step"];
                redirect("SuperAdmin/workflow/" . $service);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function detailStep() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $id_category                            = str_replace("'", "", $this->uri->rsegment(3));
        if ($id_category == "") {
            redirect("SuperAdmin/dataWorkflow");
        } else {
            if (is_numeric($id_category)) {
                if ($this->M_table->totalByCon("step", "id", $id_category) > 0) {
                    $data["step"]               = $this->M_table->getByCon("step", "id", $id_category);
                }
                if ($this->M_table->totalByCon("substep", "step_id", $id_category) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = "hm";
                    $data["subStep"]            = $this->M_table->dataTableWhere("substep", "step_id", $id_category);
                    $data["step"]               = $this->M_table->getByCon("step", "id", $id_category);
                }
                $this->load->view("superAdmin/v_subStep", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processCreateSubStep() {
        $data["subStep"]                        = str_replace("'", "", $this->input->post("name"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["step_id"]                        = str_replace("'", "", $this->input->post("step_id"));
        // print_r($data); exit();
        $this->M_table->createTable("substep", $data);
        if (str_replace("'", "", $this->input->post("order_id")) == "") {
            redirect("SuperAdmin/detailStep/" . $data["step_id"]);
        } else {
            redirect("SuperAdmin/updateOrderStep/" . str_replace("'", "", $this->input->post("order_id")));
        }
    }
    public function deleteSubStep() {
        $category                               = str_replace("'", "", $this->uri->rsegment(3));
        $service                                = str_replace("'", "", $this->uri->rsegment(4));
        if ($category == "" || $service == "") {
            redirect("SuperAdmin/dataWorkflow");
        } else {
            if (is_numeric($category) && is_numeric($service)) {
                $this->M_table->deleteTable("substep", $category);
                redirect("SuperAdmin/detailStep/" . $service);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    // ================== SCURITY ====================
    public function lock() {
        $id  = $this->session->userdata("key");
        $data["logout"]                         = date("Y-m-d H:i:s");
        $this->M_table->updateTable("history_login", $data, ["login" => $id]);
        $this->session->sess_destroy();
        $this->load->view("v_anonymous");
    }
    public function scId($segmen,$table,$col)
    {
        $id  = $segmen;
        if ($id == "") {
            redirect('SuperAdmin/lock');
        }
        else{
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon($table, $col, $id) == 0) {
                    return false;
                } else {
                    return true;
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    // ================== CHATT ====================
    public function dataChatt() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["order"]                          = $this->M_table->dataOrderChatt();
        $this->load->view("superAdmin/v_dataChatt", $data);
    }
    public function selectedChatt() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $order_id                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("SuperAdmin/dataChatt");
        } else {
            if (is_numeric($order_id)) {
                if ($this->M_table->totalByCon("order", "id", $order_id) == 0) {
                    $data["validate"]           = false;
                } else {
                    $data["validate"]           = true;
                    $data["chatt"]              = $this->M_table->dataChatt($order_id);
                    $data["dataOrder"]          = $this->M_table->selectOrder($order_id);
                }
                $this->load->view("superAdmin/v_selectedChatt", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function addChatt() {
        $order_id                               = str_replace("'", "", $this->uri->rsegment(3));
        if ($order_id == "") {
            redirect("SuperAdmin/dataChatt");
        } else {
            if (is_numeric($order_id)) {
                if ($this->M_table->totalByCon("order", "id", $order_id) == 0) {
                } else {
                    $data["order_id"]           = $order_id;
                    $data["user_id"]            = 0;
                    $data["status_id"]          = 1;
                    $data["chatt"]              = str_replace("'", "", $this->input->post("chatt"));
                    $data["create_date"]        = date("Y-m-d H:i:s");
                    $this->M_table->createTable("chatt", $data);
                }
                redirect("SuperAdmin/selectedChatt/" . $order_id);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    // ================== HISTORY ====================
    public function dataHistory() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["admin"]                          = $this->M_table->getTotalData("history_action_admin");
        $data["employee"]                       = $this->M_table->getTotalData("history_action_employee") + $this->M_employee->getLogin();
        $data["client"]                         = $this->M_table->getTotalData("history_action_client") + $this->M_table->totalLogin();
        $this->load->view("superAdmin/v_dataHistory", $data);
    }
    public function historyAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["login"]                          = $this->M_table->totalLoginA();
        $data["activity"]                       = $this->M_table->getTotalData("history_action_admin");
        $this->load->view("superAdmin/v_historyAdmin", $data);
    }
    public function loginAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data['admin']                         = $this->M_user->getByWhere('status_id', 2);
        $this->load->view("superAdmin/v_loginAdmin", $data);
    }
    public function dLoginAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/historyClient");
        } else {
            if (is_numeric($user_id)) {
                $data['admin']                 = $this->M_user->getLogin($user_id);
                $this->load->view("superAdmin/v_dLoginAdmin", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function activityAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data['client']                         = $this->M_user->getByWhere('status_id', 2);
        $this->load->view("superAdmin/v_activityAdmin", $data);
    }
    public function dActivityAdmin() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/historyClient");
        } else {
            if (is_numeric($user_id)) {
                $data['activity']               = $this->M_user->getActionA($user_id);
                $data['admin']               = $this->M_user->getById($user_id);
                $this->load->view("superAdmin/v_dActivityAdmin", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function historyClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["login"]                          = $this->M_table->totalLogin();
        $data["activity"]                       = $this->M_table->getTotalData('history_action_client');
        $this->load->view("superAdmin/v_historyClient", $data);
    }
    public function loginClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data['client']                         = $this->M_user->getByWhere('status_id', 1);
        $this->load->view("superAdmin/v_loginClient", $data);
    }
    public function dLoginClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/historyClient");
        } else {
            if (is_numeric($user_id)) {
                $data['client']                 = $this->M_user->getLogin($user_id);
                $this->load->view("superAdmin/v_dLoginClient", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function activityClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data['client']                         = $this->M_user->getByWhere('status_id', 1);
        $this->load->view("superAdmin/v_activityClient", $data);
    }
    public function dActivityClient() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/historyClient");
        } else {
            if (is_numeric($user_id)) {
                $data['activity']               = $this->M_user->getAction($user_id);
                $data['client']               = $this->M_user->getById($user_id);
                $this->load->view("superAdmin/v_dActivityClient", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function historyEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["login"]                          = $this->M_employee->getLogin();
        $data["activity"]                       = $this->M_table->getTotalData('history_action_employee');
        $this->load->view("superAdmin/v_historyEmployee", $data);
    }
    public function loginEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data['employee']                       = $this->M_table->getAll('employee');
        $this->load->view("superAdmin/v_loginEmployee", $data);
    }
    public function dLoginEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/historyEmployee");
        } else {
            if (is_numeric($user_id)) {
                $data['employee']               = $this->M_employee->getLoginById($user_id);
                $this->load->view("superAdmin/v_dLoginEmployee", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function activityEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data['employee']                       = $this->M_table->getAll('employee');
        $this->load->view("superAdmin/v_activityEmployee", $data);
    }
    public function dActivityEmployee() {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/historyClient");
        } else {
            if (is_numeric($user_id)) {
                $data['activity']               = $this->M_employee->getAction($user_id);
                $data['dataE']               = $this->M_table->getById('employee',$user_id);
                $this->load->view("superAdmin/v_dActivityEmployee", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    
    // ================== INFORMATION ====================

    public function dataInformation()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["information"]                    = $this->M_table->getAll('news');
        $this->load->view("superAdmin/v_dataInformation", $data);
    }
    public function createInformation()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $this->load->view("superAdmin/v_createInformation", $data);
    }
    public function processCreateInformation()
    {
        $data["title"]                          = str_replace("'", "", $this->input->post("title"));
        $data["description"]                    = str_replace("'", "", $this->input->post("description"));
        $data["link"]                           = str_replace("'", "", $this->input->post("link"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_news();
            $data["image"]                      = $image;
        }
        $this->M_table->createTable("news", $data);
        redirect("SuperAdmin/dataInformation");
    }
    public function detailInformation()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $info_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($info_id == "") {
            redirect("SuperAdmin/dataInformation");
        } else {
            if (is_numeric($info_id)) {
                $data["info"]                   = $this->M_table->getById('news',$info_id);
                $this->load->view("superAdmin/v_detailInformation", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function deleteInformation()
    {
        $id  = $this->uri->rsegment(3);
        if ($id=="") {
            redirect('superAdmin/lock');
        }
        else{
            if (is_numeric($id)) {
                $upload                         = $this->M_table->getById("news", $id);
                if (file_exists("assets/upload/images/news/" . $upload["image"]) && $upload["image"]) {
                    unlink("assets/upload/images/news/" . $upload["image"]);
                }
                $this->M_table->deleteTable("news", $id);
                redirect("SuperAdmin/dataInformation");
            }
            else{
                redirect('superAdmin/lock');
            }
        }
    }
    public function updateInformation()
    {
        
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $info_id                                = $this->uri->rsegment(3);
        if ($info_id=="") {
            redirect('superAdmin/lock');
        }
        else{
            if (is_numeric($info_id)) {
                $data['info']                   = $this->M_table->getById('news',$info_id);
                $this->load->view('superAdmin/v_updateInformation',$data);
            }
            else{
                redirect('superAdmin/lock');
            }
        }
    }
    public function processUpdateInformation()
    {
        $info_id                                = $this->input->post("info_id");
        if ($info_id=="") {
            redirect('superAdmin/lock');
        }
        else{
            if (is_numeric($info_id)) {
                $data = [
                    "title" => str_replace("'", "", $this->input->post("title")),
                    "description" => str_replace("'", "", $this->input->post("description")),
                    "link" => str_replace("'", "", $this->input->post("link")),
                    "update_date" => date("Y-m-d H:i:s"),
                    "create_date" => date("Y-m-d H:i:s"), ];
                if (!empty($_FILES["image"]["name"])) {
                    $image                      = $this->_do_upload_news();
                    $upload                     = $this->M_table->getById("news", $info_id);
                    if (file_exists("assets/upload/images/news/" . $upload["image"]) && $upload["image"]) {
                        unlink("assets/upload/images/news/" . $upload["image"]);
                    }
                    $data["image"]              = $image;
                }
                $this->M_table->updateTable("news", $data, ["id" => $info_id]);
                redirect('superAdmin/updateInformation/'.$info_id);
            }
            else{
                redirect('superAdmin/lock');
            }
        }
    }
    
    // ================== INFORMATION ====================

    public function dataRecommendation()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataClient"]                     = $this->M_user->getByWhere("status_id", 1);
        $this->load->view("superAdmin/v_dataRecommendation", $data);
    }
    public function userRecommendation()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($user_id)) {
                $data["serv"]                   = $this->M_table->getServRecommendation($user_id);
                $data["dataUser"]               = $this->M_table->getById('user',$user_id);
                $this->load->view("superAdmin/v_userRecommendation", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function createRecommendation()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($user_id)) {

                $data["dataUser"]               = $this->M_table->getById('user',$user_id);
                $dataId                         = $this->M_table->getServRecommendation($user_id);
                $data['selected']               = [];
                foreach ($dataId as $row) {
                    array_push($data['selected'],$row['id']);
                }
                $data['service']                = $this->M_table->getAll('services');
                $this->load->view("superAdmin/v_createRecommendation", $data);
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processCreateRecommendation()
    {
        $data["service_id"]                     = str_replace("'", "", $this->input->post("service_id"));
        $data["user_id"]                        = str_replace("'", "", $this->input->post("user_id"));
        $data["reason"]                         = str_replace("'", "", $this->input->post("reason"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->createTable("service_recommendation", $data);
        redirect("SuperAdmin/userRecommendation/".$data['user_id']);
    }
    public function deleteRecommendation()
    {
        $serv_id                                = str_replace("'", "", $this->uri->rsegment(3));
        $user_id                                = str_replace("'", "", $this->uri->rsegment(4));
        if ($serv_id == "" || $user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($serv_id) && is_numeric($user_id)) {
                $data                           = $this->M_table->getById('services',$serv_id);
                if (empty($data)) {
                    redirect('superAdmin/lock');
                } else{
                    $this->M_table->deleteTable("service_recommendation", $serv_id);
                    redirect("SuperAdmin/userRecommendation/".$user_id);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }

    public function finances()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["dataClient"]                     = $this->M_user->getByWhere("status_id", 1);
        $data["orderOn"]                        = $this->M_table->dataOrder("'do'");
        $data["spt"]                            = $this->M_table->getAll('`spt_tahunan`');
        $data["type"]                            = $this->M_table->getAll('`type_company`');
        $this->load->view('superAdmin/finance',$data);
        
    }
    public function finance_core()
    {
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($user_id)) {
                $user                           = $this->M_table->getById("user",$user_id);
                if (empty($user)) {
                    redirect('SuperAdmin/lock');
                } else{
                    $data['sptClient']    = $this->M_table->dataTableWhere("spt_tahunan_client","client_id", $user_id);
                    $data["type"]         = $this->M_table->getAll('`type_company`');
                    if ($this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']) {
                        $data["company_type"] = $this->M_table->getByCon('type_company','id', $this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']);
                        $data["dataTahunan"]   = $this->M_table->dataTableWhere("spt_tahunan",'type_company_id',$this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']);
                    }
                    $data["client"] = $this->M_table->getById('user', $user_id);
                    $data["user_id"]      = $user_id;
                    $this->load->view('superAdmin/finance-core',$data);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function finance_manage()
    {
        $user_id                                = str_replace("'", "", $this->uri->rsegment(3));
        $date                                = str_replace("'", "", $this->uri->rsegment(4));
        $data['date']                       = str_replace("'", "", $this->input->post("date"));
        if ($user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($user_id)) {
                $user                           = $this->M_table->getById("user",$user_id);
                if (empty($user)) {
                    redirect('SuperAdmin/lock');
                } else{
                    if ($data['date'] != "") {
                        
                    }
                    if ($date != "") {
                            $data['date'] = $date;
                        }
                    else{
                        $data['sptClient'] = [];
                    }
                        $data['sptClient']    = $this->M_table->get_spt_clientDate($user_id,$data['date']."-02");
                        
                        $data["type"]           = $this->M_table->getAll('`type_company`');
                        $data["company_type"]   = $this->M_table->getByCon('type_company','id', $this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']);
                        $data["dataTahunan"]    = $this->M_table->dataTableWhere("spt_tahunan",'type_company_id',$this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']);
                        $data["client"]         = $this->M_table->getById('user', $user_id);
                        $data["user_id"]        = $user_id;
                        $this->load->view('superAdmin/finance-manage',$data);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function manageFormula()
    {
        $data['dataName']                       = str_replace("'", "", $this->input->post("dataName"));
        $data['user_id']                       = str_replace("'", "", $this->input->post("user_id"));
        $data['dataSptRumus']                   = $this->M_table->dataTableWhere[''];
        print_r($data);
        exit();
    }
    public function finance_input()
    {
        $user_id            = str_replace("'", "", $this->uri->rsegment(3));
        $date               = str_replace("'", "", $this->uri->rsegment(4));
        $data['date']       = str_replace("'", "", $this->input->post("date"));
        $data['message']    = str_replace("'" || "'", "", $this->uri->rsegment(5));
        if ($user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($user_id)) {
                $user                           = $this->M_table->getById("user",$user_id);
                if (empty($user)) {
                    redirect('SuperAdmin/lock');
                } else{
                    if ($data['date'] != "") {
                        
                    }
                    if ($date != "") {
                            $data['date'] = $date;
                        }
                    else{
                        $data['sptClient'] = [];
                    }
                        $data['sptClient']    = $this->M_table->get_spt_client($user_id,$data['date']."-02");
                        $data["type"]         = $this->M_table->getAll('`type_company`');
                        $data["company_type"] = $this->M_table->getByCon('type_company','id', $this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']);
                        $data["client"]       = $this->M_table->getById('user', $user_id);
                        $data["user_id"]      = $user_id;
                        $this->load->view('superAdmin/finance-input',$data);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function finance_formula()
    {
        $user_id        = str_replace("'", "", $this->uri->rsegment(3));
        $date           = str_replace("'", "", $this->uri->rsegment(4));
        $data['date']   = str_replace("'", "", $this->input->post("date"));
        if ($user_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($user_id)) {
                $user                           = $this->M_table->getById("user",$user_id);
                if (empty($user)) {
                    redirect('SuperAdmin/lock');
                } else{
                    if ($data['date'] != "") {
                    }
                    if ($date != "") {
                            $data['date'] = $date;
                        }
                    else{
                        $data['sptClient'] = [];
                    }
                        $data['sptClient']      = $this->M_table->get_spt_client($user_id,$data['date']."-02");
                        $data['formulaFinance'] = $this->M_table->get_formula_finance($user_id,$data['date']."-02");

                        // print_r($data['formulaFinance']); exit();

                        $data["type"]           = $this->M_table->getAll('`type_company`');
                        $data["company_type"]   = $this->M_table->getByCon('type_company','id', $this->M_table->getByCon('type_company_client','client_id', $user_id)['type_company']);
                        $data["client"]         = $this->M_table->getById('user', $user_id);
                        $data["user_id"]        = $user_id;
                        $this->load->view('superAdmin/finance-formula',$data);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function updateValueSptClient()
    {
        $date    = str_replace("'", "", $this->input->post("spt_date"));
        $client_id                       = str_replace("'", "", $this->input->post("client_id"));
        foreach ($this->M_table->get_spt_client($client_id,$date."-02") as $key) {
            $data["value"] = str_replace("'", "", $this->input->post("value".$key['id']));
            $data["update_date"]        = date("Y-m-d H:i:s");
            $this->M_table->updateTable("spt_tahunan_client", $data, ["id" => $key['id']]);
        }
        redirect('SuperAdmin/finance_input/'.$client_id.'/'.$date);
    }
    public function finance_preview()
    {
        $data["dataClient"]                     = $this->M_user->getByWhere("status_id", 1);
        $data["orderOn"]                        = $this->M_table->dataOrder("'do'");
        $this->load->view('superAdmin/finance-preview',$data);
    }
    public function finance_default ()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $type_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($type_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($type_id)) {
                $type                           = $this->M_table->getById("type_company",$type_id);
                if (empty($type)) {
                    redirect('SuperAdmin/lock');
                } else{
                    $data["dataType"]                     = $this->M_table->getByCon("type_company", 'id', $type_id);
                    $data["dataSpt"]                       = $this->M_table->dataTableWhere("spt_tahunan", 'type_company_id', $type_id);
                    $this->load->view('superAdmin/finance-default',$data);
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    
    }
    public function processCreateSpt()
    {
        $data["type_company_id"]    = str_replace("'", "", $this->input->post("type_company_id"));
        $data["description"]        = str_replace("'", "", $this->input->post("description"));
        $data["description_en"]     = str_replace("'", "", $this->input->post("description-en"));
        $data["description_jpn"]    = str_replace("'", "", $this->input->post("description-jpn"));
        $data["description_cna"]    = str_replace("'", "", $this->input->post("description-cna"));
        $data["description_kor"]    = str_replace("'", "", $this->input->post("description-kor"));
        $data["category_element"]   = str_replace("'", "", $this->input->post("category_element"));
        $data["category_jumlah"]    = str_replace("'", "", $this->input->post("category_jumlah"));
        $data["update_date"]        = date("Y-m-d H:i:s");
        $data["create_date"]        = date("Y-m-d H:i:s");
        $this->M_table->createTable("`spt_tahunan`", $data);
        redirect("SuperAdmin/finance_default/".$data["type_company_id"]);
    }
    public function deleteSpt()
    {
        $id  = $this->uri->rsegment(3);
        $type = $this->M_table->getById("spt_tahunan",$id);
        if ($id=="") {
            redirect('superAdmin/lock');
        }
        else{
            if (is_numeric($id)) {
                $this->M_table->deleteTable("`spt_tahunan`", $id);
                redirect("SuperAdmin/finance_default/". $type['type_company_id']);
            }
            else{
                redirect('superAdmin/lock');
            }
        }
    }
    public function processUpdateSpt()
    {
        $data["type_company_id"]    = str_replace("'", "", $this->input->post("type_company_id"));
        $data["description"]        = str_replace("'", "", $this->input->post("description"));
        $data["description_en"]     = str_replace("'", "", $this->input->post("description-en"));
        $data["description_jpn"]    = str_replace("'", "", $this->input->post("description-jpn"));
        $data["description_cna"]    = str_replace("'", "", $this->input->post("description-cna"));
        $data["description_kor"]    = str_replace("'", "", $this->input->post("description-kor"));
        $data["update_date"]        = date("Y-m-d H:i:s");
        $this->M_table->updateTable("spt_tahunan", $data, ["id" => str_replace("'", "", $this->input->post("id"))]);
        redirect("SuperAdmin/finance_default/".$data["type_company_id"]);
    }
    public function createTypeCompanyClient()
    {
        $data["type_company"]   = str_replace("'", "", $this->input->post("type_company_id"));
        $data["client_id"]      = str_replace("'", "", $this->input->post("client_id"));
        $data["update_date"]    = date("Y-m-d H:i:s");
        $data["create_date"]    = date("Y-m-d H:i:s");
        $this->M_table->createTable("`type_company_client`", $data);
        redirect("SuperAdmin/finance_manage/".$data['client_id']);
    }
    public function updateSptClient()
    {
        $data["client_id"]          = str_replace("'", "", $this->input->post("client_id"));
        $data["type_company_id"]    = str_replace("'", "", $this->input->post("type_company_id"));
        $data["spt_date"]           = str_replace("'", "", $this->input->post("spt_date")."-02");
        $data["update_date"]        = date("Y-m-d H:i:s");
        $data["create_date"]        = date("Y-m-d H:i:s");
        $dataNew = $this->input->post("spk[]");
        $dataOld = [];
        $forFinance['client_id'] = $data['client_id'];
        $forFinance['data_date'] = $data['spt_date'];
        $forFinance["update_date"]        = date("Y-m-d H:i:s");
        $forFinance["create_date"]        = date("Y-m-d H:i:s");
        foreach ($this->M_table->get_spt_client($data["client_id"],$data['spt_date']) as $key) {
            array_push($dataOld, $key['spt_tahunan_id']);
        }
        if (empty($dataNew)) {
            $this->M_table->delete3Param("spt_tahunan_client", "client_id" ,$data['client_id'] . ' AND spt_date = ', $data['spt_date']);
            $this->M_table->delete3Param("client_finance", "client_id" ,$data['client_id'] . ' AND data_date = ', $data['spt_date']);
        } else{
            
            foreach ($dataOld as $key) {
                if (in_array($key, $dataNew)) { 
                    continue;
                } else {
                    $this->M_table->deleteTableCon("spt_tahunan_client", "spt_tahunan_id" ,$key);
                }
            }
            foreach ($dataNew as $rows) {
                if (in_array($rows, $dataOld)) { 
                    continue;
                } else {
                    $data['spt_tahunan_id'] = $rows;
                    $this->M_table->createTable("spt_tahunan_client", $data);
                }
            }
            if (empty($this->M_table->dataTableWhere2('client_finance','client_id',$data['client_id'] . ' AND data_date = ',$data['spt_date']))) {
                $this->M_table->createTable("client_finance", $forFinance);

        }
        }
        redirect('SuperAdmin/finance_manage/'.$data['client_id'].'/'.$this->input->post("spt_date"));
    }
    
    // ================== SPECIAL TASK ====================

    public function specialTask()
    {
        $id                   = $this->session->userdata("id");
        $data["user"]         = $this->M_user->profile($id);
        $data['dataTask']     = $this->M_table->getAllTask();
        $data['dataReport']     = $this->M_table->getAll('dailyreport');
        $this->load->view("superAdmin/v_specialTask", $data);
    } 
    public function detailSpecialTask()
    {
        $id                   = $this->session->userdata("id");
        $data["user"]         = $this->M_user->profile($id);
        $data['dataStaff']    = $this->M_table->getAll('employee');
        $data['dataCategory'] = $this->M_table->getAll('category_specialtask');
        $data['dataTask']     = $this->M_table->getAllTask();
        $this->load->view("superAdmin/v_specialTaskDetail", $data);
    }
    public function updateStatusTask()
    {
        $task_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($task_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($task_id)) {
                $task                           = $this->M_table->getById('specialtask',$task_id);
                if (empty($task)) {
                    redirect('SuperAdmin/lock');
                } else{
                    if ($task['status']=="do") {
                        $data['status'] = "done";
                    } else{
                        $data['status'] = "do";
                    }
                    $data["update_date"]                    = date("Y-m-d H:i:s");
                    $this->M_table->updateTable("specialtask",$data,array('id'=>$task_id));
                    redirect("SuperAdmin/detailSpecialTask");
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function processCreateTask()
    {
        $data["employee_id"]    = str_replace("'", "", $this->input->post("employee_id"));
        $data["task"]           = str_replace("'", "", $this->input->post("task"));
        $data["description"]    = str_replace("'", "", $this->input->post("description"));
        $data["estimasi"]       = str_replace("'", "", $this->input->post("estimasi"));
        $data["id_category"]    = str_replace("'", "", $this->input->post("category_id"));
        $data["update_date"]    = date("Y-m-d H:i:s");
        $data["create_date"]    = date("Y-m-d H:i:s");
        $this->M_table->createTable("specialtask", $data);
        redirect("SuperAdmin/detailSpecialTask"); 
    }
    public function updateTask()
    {
        $data["employee_id"]    = str_replace("'", "", $this->input->post("employee_id"));
        $data["task"]           = str_replace("'", "", $this->input->post("task"));
        $data["description"]    = str_replace("'", "", $this->input->post("description"));
        $data["estimasi"]       = str_replace("'", "", $this->input->post("estimasi"));
        $data["id_category"]    = str_replace("'", "", $this->input->post("category_id"));
        $data["update_date"]    = date("Y-m-d H:i:s");
        
        $this->M_table->updateTable("specialtask", $data,array('id'=>$this->input->post("task_id")));
        redirect("SuperAdmin/detailSpecialTask");
    }
    public function deleteTask()
    {
        $task_id                                = str_replace("'", "", $this->uri->rsegment(3));
        if ($task_id == "") {
            redirect("SuperAdmin/lock");
        } else {
            if (is_numeric($task_id)) {
                $task                           = $this->M_table->getById('specialtask',$task_id);
                if (empty($task)) {
                    redirect('SuperAdmin/lock');
                } else{
                    $this->M_table->deleteTable("specialtask", $task_id);
                    redirect("SuperAdmin/detailSpecialTask");
                }
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function dailyReport()
    {
        $data["dataEmployee"]   = $this->M_table->getEmployee();
        $date = $this->input->post("date");
        $type = $this->input->post("type");
        $employee_id = $this->input->post("employee_id");
        $data['employee_id'] = 0;
        $data['date'] = date('Y-m-d');

        if ($this->input->post("update") == "yes") {
            foreach ($this->M_employee->dR_ED($employee_id,$date) as $key) {
                if($this->input->post("report[]")){
                    if (in_array($key['id'],$this->input->post("report[]"))) {
                    $dataC['check'] = "yes";
                    } else{
                        $dataC['check'] = "no";
                    }
                } else{
                    $dataC['check'] = "no";
                }
                    $this->M_table->updateTable("dailyreport", $dataC,array('id'=>$key['id']));
            }
            $data['dailyReport']    = $this->M_employee->dR_ED($employee_id,$date);
            $data['message'] = 'search by ' . $data['dailyReport'][0]['employee_name'] .' date: ' . date("F j, Y", strtotime($date));
            $data['type'] = "employee";
            $data['employee_id'] = $this->M_table->getById('employee',$employee_id);
            $data['date'] = $date;
            return $this->load->view('superAdmin/v_dailyReport',$data);
        }

        $data['type'] = "all";
        $employee_id = $this->input->post("employee_id");
        $data['message'] = "show all data";
        if (!$type) {
            $data['dailyReport']    = $this->M_employee->getDailyReport();
        }
        else{
            $data['dailyReport']    = $this->M_employee->dR_AD($date);
            $data['message'] = 'search by date: '.' date: ' . date("F j, Y", strtotime($date));
            if ($employee_id) {
                $data['dailyReport']    = $this->M_employee->dR_ED($employee_id,$date);
                $data['employee_id'] = $this->M_table->getById('employee',$employee_id);
                $data['date'] = $date;
                $data['type'] = "employee";
                if (count($this->M_employee->dR_ED($employee_id,$date)) > 0) {
                    if($date == date('Y-m-d')){
                    $data['message'] = 'search by ' . $data['dailyReport'][0]['employee_name'] . ' <b class="text-success">today</b>';
                    } else{
                    $data['message'] = 'search by ' . $data['dailyReport'][0]['employee_name'] .' date: ' . date("F j, Y", strtotime($date));
                    }
                } else{
                    $data['message'] = "search by Employee and date";
                }
            }
        }
        $this->load->view('superAdmin/v_dailyReport',$data);
    }
    //============ training ============

	public function training()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $data["title_content"]                  = $this->M_table->joinThreeTable('content_training_title','content_training_category','content_training_level','id_category','id','content_training_title.id_level = content_training_level.id','content_training_title.*, content_training_category.content_training_category,content_training_level.content_level');
        $data["data_category"]                  = $this->M_table->getAll('content_training_category');
        $data["data_level"]                     = $this->M_table->getAll('content_training_level');
        $this->load->view("superAdmin/v_training", $data);   
    }
    public function create_content_title() {
        $data["content_title"]          = str_replace("'", "", $this->input->post("content_title"));
        $data["content_description"]    = str_replace("'", "", $this->input->post("content_description"));
        $data["id_level"]               = str_replace("'", "", $this->input->post("id_level"));
        $data["id_category"]            = str_replace("'", "", $this->input->post("id_category"));
        $data["create_date"]            = date("Y-m-d H:i:s");
        $data["update_date"]            = date("Y-m-d H:i:s");
        $this->M_table->createTable("content_training_title", $data);
        redirect("SuperAdmin/training");
    }
    public function update_content_title()
    {
        $data["content_title"]          = str_replace("'", "", $this->input->post("content_title"));
        $data["content_description"]    = str_replace("'", "", $this->input->post("content_description"));
        $data["id_level"]               = str_replace("'", "", $this->input->post("id_level"));
        $data["id_category"]            = str_replace("'", "", $this->input->post("id_category"));
        $data["update_date"]            = date("Y-m-d H:i:s");
        $this->M_table->updateTable("content_training_title", $data, ["id" => str_replace("'", "", $this->input->post("id"))]);
        redirect("SuperAdmin/training");
    }
    public function delete_content_title()
    {
        
        $id = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect('SuperAdmin/lock');
        }
        else{
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("content_training_title", "id", $id) == 0) {
                    redirect('SuperAdmin/lock');
                } else {
                    $this->M_table->deleteTable("content_training_title", $id);
                }
                redirect('SuperAdmin/training');
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function create_content_category() {
        $data["content_training_category"]                           = str_replace("'", "", $this->input->post("content_training_category"));
        $data["create_date"]                    = date("Y-m-d H:i:s");
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->createTable("content_training_category", $data);
        redirect("SuperAdmin/training");
    }
    public function update_content_category()
    {
        $data["content_training_category"]                           = str_replace("'", "", $this->input->post("content_training_category"));
        $data["update_date"]                    = date("Y-m-d H:i:s");
        $this->M_table->updateTable("content_training_category", $data, ["id" => str_replace("'", "", $this->input->post("id"))]);
        redirect("SuperAdmin/training");
    }
    public function delete_content_category()
    {
        
        $id  = str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect('SuperAdmin/lock');
        }
        else{
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("content_training_category", "id", $id) == 0) {
                    redirect('SuperAdmin/lock');
                } else {
                    $data['id_category'] = 1;
                    $data['update_date'] = date("Y-m-d H:i:s");
                    foreach ($this->M_table->dataTableWhere('content_training_title','id_category',$id) as $key) {
                        $this->M_table->updateTable("content_training_title", $data, ["id" => $key['id']]);
                    }
                    $this->M_table->deleteTable("content_training_category", $id);
                }
                redirect('SuperAdmin/training');
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }
    public function create_content_level() {
        $data["content_level"]    = str_replace("'", "", $this->input->post("content_level"));
        $data["create_date"]      = date("Y-m-d H:i:s");
        $data["update_date"]      = date("Y-m-d H:i:s");
        $this->M_table->createTable("content_training_level", $data);
        redirect("SuperAdmin/training");
    }
    public function delete_content_level()
    {
        $id= str_replace("'", "", $this->uri->rsegment(3));
        if ($id == "") {
            redirect('SuperAdmin/lock');
        }
        else{
            if (is_numeric($id)) {
                if ($this->M_table->totalByCon("content_training_level", "id", $id) == 0) {
                    redirect('SuperAdmin/lock');
                } else {
                    $data['id_level'] = 1;
                    $data['update_date'] = date("Y-m-d H:i:s");
                    foreach ($this->M_table->dataTableWhere('content_training_title','id_level',$id) as $key) {
                        $this->M_table->updateTable("content_training_title", $data, ["id" => $key['id']]);
                    }
                    $this->M_table->deleteTable("content_training_level", $id);
                }
                redirect('SuperAdmin/training');
            } else {
                redirect("SuperAdmin/lock");
            }
        }
    }

    
    
    public function update_content_level()
    {
        $data["content_level"]    = str_replace("'", "", $this->input->post("content_level"));
        $data["update_date"]      = date("Y-m-d H:i:s");
        $this->M_table->updateTable("content_training_level", $data, ["id" => str_replace("'", "", $this->input->post("id"))]);
        redirect("SuperAdmin/training");
    }

    public function content_training()
    {
        if ($this->scId($this->uri->rsegment(3),'content_training_title','id')) {
            $id                 = $this->session->userdata("id");
            $data["user"]       = $this->M_user->profile($id);
            $data['data_pdf']   = $this->M_table->dataTableWhere('content_training_type_pdf','id_content_title',$this->uri->rsegment(3));
            $data['data_ppt']   = $this->M_table->dataTableWhere('content_training_type_ppt','id_content_title',$this->uri->rsegment(3));
            $data['data_yt']   = $this->M_table->dataTableWhere('content_training_type_yt','id_content_title',$this->uri->rsegment(3));
            $data['id_title']   = $this->uri->rsegment(3);
            $this->load->view('superAdmin/v_content_training',$data);
        } else{
            redirect("SuperAdmin/lock");
        }
    }
    public function create_content()
    {
        $data["title"]              = str_replace("'", "", $this->input->post("title"));
        $data["content"]            = str_replace("'", "", $this->input->post("content"));
        $data["id_content_title"]   = str_replace("'", "", $this->input->post("id_content_title"));
        $data["create_date"]        = date("Y-m-d H:i:s");
        $data["update_date"]        = date("Y-m-d H:i:s");
        $table                      = "pdf";
        switch (str_replace("'", "", $this->input->post("type"))) {
            case 'pdf':
                $table = "content_training_type_pdf";
                break;
            case 'ppt':
                $table = "content_training_type_ppt";
                break;
            case 'yt':
                $table = "content_training_type_yt";
                break;
        }
        $this->M_table->createTable($table,$data);
        redirect('SuperAdmin/content_training/'.str_replace("'", "", $this->input->post("id_content_title")));
    }
    public function update_content()
    {
        $data["title"]              = str_replace("'", "", $this->input->post("title"));
        $data["content"]            = str_replace("'", "", $this->input->post("content"));
        $data["update_date"]        = date("Y-m-d H:i:s");
        $table                      = "pdf";
        switch (str_replace("'", "", $this->input->post("type"))) {
            case 'pdf':
                $table = "content_training_type_pdf";
                break;
            case 'ppt':
                $table = "content_training_type_ppt";
                break;
            case 'yt':
                $table = "content_training_type_yt";
                break;
        }
        $this->M_table->updateTable($table, $data, array('id' => $this->input->post("id")));
        redirect('SuperAdmin/content_training/'.str_replace("'", "", $this->input->post("id_content_title")));
    }
    public function delete_content()
    {
        if ($this->scId($this->uri->rsegment(3),'content_training_type_yt','id') || $this->scId($this->uri->rsegment(3),'content_training_type_pdf','id') || $this->scId($this->uri->rsegment(3),'content_training_type_ppt','id')) {
            if ($this->scId($this->uri->rsegment(5),'content_training_title','id')) {
                switch (str_replace("'", "", $this->uri->rsegment(4))) {
                case 'pdf':
                    $table = "content_training_type_pdf";
                    break;
                case 'ppt':
                    $table = "content_training_type_ppt";
                    break;
                case 'yt':
                    $table = "content_training_type_yt";
                    break;
                }
            }
            $this->M_table->deleteTable($table, $this->uri->rsegment(3));
            redirect('SuperAdmin/content_training/'.$this->uri->rsegment(5));
        } else{
            redirect("SuperAdmin/lock");
        }
        $data["title"]                           = str_replace("'", "", $this->input->post("title"));
        $data["content"]                           = str_replace("'", "", $this->input->post("content"));
        $data["id_content_title"]                           = str_replace("'", "", $this->input->post("id_content_title"));
        $table = "pdf";
        switch (str_replace("'", "", $this->input->post("type"))) {
            case 'pdf':
                $table = "content_training_type_pdf";
                break;
            case 'ppt':
                $table = "content_training_type_ppt";
                break;
            case 'yt':
                $table = "content_training_type_yt";
                break;
        }
        $this->M_table->createTable($table,$data);
        redirect('SuperAdmin/content_training/'.str_replace("'", "", $this->input->post("id_content_title")));
    }

	//============ tax update ============

	public function taxUpdate(){
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $this->load->view("superAdmin/v_taxUpdate", $data);   
    }

    //============ tax guest ============

    public function guestTHC()
    {
        $id= str_replace("'", "", $this->uri->rsegment(3));
        if ($id) {
           if ($id == "") {
            redirect('SuperAdmin/lock');
            }
            else{
                if (is_numeric($id)) {
                    if ($this->M_table->totalByCon("user", "id", $id) == 0) {
                        redirect('SuperAdmin/lock');
                    } else {
                        $data["client"]             = $this->M_user->profile($id);
                        $data["thc"]                = $this->M_table->getByCon('thc_guest','guest_id',$id);
                        $data['thc_guest_status']   = $this->M_guest->thc_guest_status($id);
                        $data['thc_guest']          = $this->M_guest->thc_guest($id);
                        $data['thc_guest_answer']   = $this->M_guest->thc_guest_answer($id);
                        $data['thc_status']   = $this->M_table->getAll('thc_status');
                        $data['thc_report']   = $this->M_table->dataTableWhere('thc_report','guest_id',$id);
                        $data['thc_nda']   = $this->M_table->dataTableWhere('thc_nda','guest_id',$id);
                        $data['thc_meeting']   = $this->M_table->dataTableWhere('thc_meeting','guest_id',$id);
                        $id                         = $this->session->userdata("id");
                        $data["user"]               = $this->M_user->profile($id);
                    }
                    $this->load->view("superAdmin/components/guest-document", $data);
                } else {
                    redirect("SuperAdmin/lock");
                }
            }
        } else{
            $id  = $this->session->userdata("id");
            $data["user"]         = $this->M_user->profile($id);
            $data["dataClient"]   = $this->M_user->getByWhere("status_id", 6);
            $this->load->view("superAdmin/v_guestTHC", $data);
        }
        
    }
    public function updateStatusThc()
    {
        $id = $this->input->post("id");
        $data['thc_status_id']               = str_replace("'", "", $this->input->post("status"));
        $this->M_table->updateTable('thc_guest_status', $data, array('guest_id' => $id));
        redirect('SuperAdmin/guestTHC/'.$id);
    }
    public function addReportThc()
    {
        $id = $this->input->post("guest_id");
        $data['title']               = str_replace("'", "", $this->input->post("title"));
        $data['description']               = str_replace("'", "", $this->input->post("description"));
        $data['guest_id']               = $id;
        $data["create_date"]      = date("Y-m-d H:i:s");
        $data["update_date"]      = date("Y-m-d H:i:s");
        
        if (!empty($_FILES["image"]["name"])) {
            $image                              = $this->_do_upload_Rthc();
            $data["report"]                      = $image;
        }
        $this->M_table->createTable("thc_report", $data);
        redirect('SuperAdmin/guestTHC/'.$id);
    }
    
    public function addMeetingThc()
    {
        $id                     = $this->input->post("guest_id");
        $data['title']          = str_replace("'", "", $this->input->post("title"));
        $data['description']    = str_replace("'", "", $this->input->post("description"));
        $data['link']           = str_replace("'", "", $this->input->post("link"));
        $data['meet']           = str_replace("'", "", $this->input->post("meet"));
        $data['date']           = str_replace("'", "", $this->input->post("date"));
        $data['guest_id']       = $id;
        $data["create_date"]    = date("Y-m-d H:i:s");
        $data["update_date"]    = date("Y-m-d H:i:s");
        
        $this->M_table->createTable("thc_meeting", $data);
        redirect('SuperAdmin/guestTHC/'.$id);
    }
    public function _do_upload_Rthc() {
        $image_name                             = time() . "-" . $_FILES["image"]["name"];
        $config["upload_path"]                  = "assets/upload/thc/report";
        $config["allowed_types"]                = "pdf|jpg|png|jpeg|xlsx|doc|odt";
        $config["file_name"]                    = $image_name;

        $this->load->library("upload", $config);
        if (!$this->upload->do_upload("image")) {
            $this->session->set_flashdata("msg", $this->upload->display_errors("", ""));
            redirect("");
        }
        return $this->upload->data("file_name");
    }
     //============ accountingUpdate ============

	public function accountingUpdate()
    {
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $this->load->view("superAdmin/v_accountingUpdate", $data);   
    }

	//============ employeeScore ============

	public function employeeScore(){
        $id  = $this->session->userdata("id");
        $data["user"]                           = $this->M_user->profile($id);
        $this->load->view("superAdmin/v_employeeScore", $data);   
    }
}