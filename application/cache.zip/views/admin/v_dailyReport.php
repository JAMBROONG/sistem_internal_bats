<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daily Report</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/select2/css/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/adminlte.min.css">

    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <script>
         function selects(){  
            var ele=document.getElementsByName('report[]');  
            for(var i=0; i<18; i++){ 
                if(ele[i].type=='checkbox'){
                    if(ele[i].checked==true){
                        ele[i].checked=false; 
                        document.getElementById('btnSelect').innerHTML = "Select All";
                    } else {
                        ele[i].checked=true;
                        document.getElementById('btnSelect').innerHTML = "Deselect All";
                    }
                }  
            }  
        }  
    </script>

</head>
</style>

<body class="hold-transition sidebar-mini mt-5">
    <div class="wrapper shadow rounded m-5">
        <section class="content p-2">
            <div class="main-body">
                <nav aria-label="breadcrumb" class="main-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Daily Report</li>
                    </ol>
                </nav>
            </div>
            <div class="card shadow-none">
                <div class="card-body table-responsive">
                    <form action="<?= base_url('Admin/dailyReport'); ?>" method="POST">
                        <div class="row">
                            <div class="col-md-10 offset-md-1">
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label>Select View</label>
                                            <select id="leave" onchange="onklik()" name="type" class="form-control select2" required>
                                                <option value="employee">Show By Employee</option>
                                                <option value="all">Show All Employee</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-5" id="selectE">
                                        <div class="form-group">
                                            <label>Select Employee</label>
                                            <select class="select2" id="selEmployee" name="employee_id" data-placeholder="select" style="width: 100%;">
                                                <?php
                                                if($employee_id){
                                                    ?>
                                                    <option value="<?= $employee_id['id']?>"><?=$employee_id['employee_name']?></option>
                                                    <?php
                                                }
                                                ?>
                                                <?php
                                            foreach ($dataEmployee as $key) {
                                                if ($key['status_id'] == 3 || $key['status_id'] == 4) {
                                                    if($key['id'] == $employee_id['id']){
                                                        continue;
                                                    }
                                                ?>
                                                <option value="<?=$key['id']?>"><?=$key['employee_name']?></option>
                                                <?php
                                                } else{
                                                    continue;
                                                }
                                            }
                                        ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label>Date:</label>
                                            <input type="date" name="date" class="form-control" value="<?= $date?>" id="" required>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-search mr-1"></i> search</button>
                                <a href="<?=base_url('Admin/dailyReport')?>" class="btn btn-sm btn-warning"><i class="fa fa-book-reader mr-1"></i> see all</a>
                            </div>
                        </div>
                    </form>
                    <p class="text-center p-3"><?=$message?></p>
                    <?php 
                    if ($type != 'all' && $dailyReport) {
                    ?>
                    <button type="button" onclick='selects()' id="btnSelect" class="btn btn-sm btn-outline-primary">Select All</button> 
                    <form action="<?= base_url('Admin/dailyReport') ?>" method="post">
                    <input type="hidden" name="date"  value="<?= ( empty($dailyReport[0]['date'])) ? '':$dailyReport[0]['date'];?>">
                    <input type="hidden" name="employee_id"  value="<?= ( empty($dailyReport[0]['date'])) ? '':$dailyReport[0]['employee_id'];?>">
                    <input type="hidden" name="update"  value="yes">
                        <?php
                        }
                        ?>
                        <table id="table" class="table table-hover table-striped">
                            <thead class="thead-inverse">
                                <tr>
                                    <th>No</th>
                                    <th>Employee</th>
                                    <th>Time</th>
                                    <?= ($type != "all")? '':'<th>Date</th>'  ?>
                                    <th>Plan</th>
                                    <th>Do</th>
                                    <th>Problem</th>
                                    <th>Solution</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                            $no = 1;
                            foreach ($dailyReport as $key) {
                                
                                if($no > 18){
                                     echo '<tr>' ;
                                }else{
                                    echo '<tr style="background-color: #F8F9D7;">';
                                };
                                ($key['check'] == 'no') ? $checked = "" : $checked = "checked"; 
                                ?>
                                    <td class="text-center"><?= $no ?></td>
                                    <td><?= $key['employee_name'] ?></td>
                                    <td><?= date("G:i - ", strtotime($key['start_time'])).date("G:i", strtotime($key['end_time'])) ?></td>
                                    
                                    <?= ($type != "all")? '': '<td>'. date("F j, Y", strtotime($key['date'])).'</td>'  ?>
                                    
                                    <td><?= $key['planing'] ?></td>
                                    <td><?= $key['doing'] ?></td>
                                    <td><?= ( $key['problem'] == 'nothing') ? '<small class="text-danger">'.$key['problem'].'</small>' : $key['problem']; ?></td>
                                    <td><?= ( $key['solution'] == 'nothing') ? '<small class="text-danger">'.$key['solution'].'</small>' : $key['solution']; ?>
                                    <td><?= ( $key['description'] == 'nothing') ? '<small class="text-danger">'.$key['description'].'</small>' : $key['description']; ?>
                                    <?php 
                                    if ($type != 'all') {
                                        ?>
                                    <td>
                                        <div class="icheck-primary d-inline">
                                            <input type="checkbox" class="mr-1 bg-success selectAll" <?= $checked ?> name="report[]" class="" value="<?= $key['id'];?>" id="check<?=$key['id']?>">
                                            <label for="check<?=$key['id']?>">
                                                <?php
                                                if ($key['check'] == "yes") {
                                                        echo '<small class="text-success">approved</small>';
                                                    } else{
                                                    echo '<small class="text-warning">waiting for approval</small>';
                                                    }
                                                ?>
                                            </label>
                                        </div>
                                    </td>
                                    <?php
                                    } else{
                                        if ($key['check'] == "yes") {
                                            echo '<td><small class="text-success">approved</small></td>';
                                        } else{
                                        echo '<td><small class="text-danger"> not approved</small></td>';
                                        }
                                    }
                                    ?>

                                </tr>
                                <?php
                                $no++;
                            }
                            ?>

                            </tbody>
                        </table>
                        <?php 
                if ($type != 'all' && $dailyReport) {
                    ?>
                        <button class="btn btn-sm btn-success"><i class="fa fa-save mr-1"></i> SAVE</button>
                    </form>
                    <?php
                }
                ?>

                </div>
            </div>
        </section>
    </div>


    <script src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/select2/js/select2.full.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/dist/js/demo.js"></script>
    <script>
        function onklik() {
            if (document.getElementById("leave").value == "all") {
                document.getElementById("selectE").style.display = "none";
                document.getElementById("selEmployee").value = "";
            } else {
                document.getElementById("selectE").style.display = 'block';
            }
        }
        $(function() {
            $('.select2').select2()
        });
    </script>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/jszip/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

    <script>
        $(function() {
            $("#table").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "bPaginate": false,
            });
        });
    </script>
</body>

</html>