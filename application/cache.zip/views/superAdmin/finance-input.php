<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Finance</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />
    <?php include 'header.php'; ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
</head>

<style>
/* The container */
.container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
</style>
<?php
$dataOld = [];
foreach ($sptClient as $key) {
    array_push($dataOld,$key['spt_tahunan_id']);
}
$checked = "";
?>
<body class="hold-transition sidebar-mini layout-boxed mt-5">
    <div class="wrapper shadow rounded">

        <section class="content">
            <div class="">
                <div class="main-body">
                    <nav aria-label="breadcrumb" class="main-breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?= base_url('SuperAdmin/Finances')?>">Finances</a></li>
                            <li class="breadcrumb-item"><a href="<?= base_url('SuperAdmin/finance_core/'.$user_id)?>">Core</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Set Default</li>
                        </ol>
                    </nav>
                </div>
                    <?php
                if (empty($date)) {
                ?>
                <style>
                    footer{
                        display: none   ;
                    }
                </style>
                <div class="card shadow-none">
                    <div class="card-body d-flex justify-content-center">
                        <div class="col-6 d-flex align-items-center justify-content-center text-center">
                            <p>Input data will be displayed by month and year, <br> please select the month and year you want to display</p>
                        </div>
                        <form action="<?= base_url('SuperAdmin/finance_input/'. $user_id)?>" class="form col-6" method="post">
                            <div class="form-group">
                                <label for="">Select Date</label>
                                <input type="hidden" name="client_id" value="<?= $user_id ?>">
                                <input type="month" name="date" id="date" class="form-control date" required>
                            </div>
                            <button type="submit"  class="btn btn-sm btn-success"><i class="fa fa-eye mr-2"></i> view data</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
<?php include 'footer.php'; ?>
<?php
    return false;
    } 
?>
            <div class="card shadow-none">
                    <div class="card-body d-flex justify-content-center">
                        <div class="col-6 d-flex align-items-center justify-content-center text-center">
                            <p>Input data will be displayed by month and year, <br> please select the month and year you want to display</p>
                        </div>
                        <form action="<?= base_url('SuperAdmin/finance_input/'. $user_id)?>" class="form col-6" method="post">
                            <div class="form-group">
                                <label for="">Select Date</label>
                                <input type="hidden" name="client_id" value="<?= $user_id ?>">
                                <div class="row">
                                    <div class="col">
                                        <input type="month" name="date" id="date" value="<?= $date ?>" class="form-control date" required>
                                    </div>
                                    <div class="col">
                                        <button type="submit"  class="btn btn-success"><i class="fa fa-eye mr-2"></i> view data</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <div class="card m-3 shadow-none">
                <div class="card-header">
                    <div class="card-title">
                        SPT <?= $client['name'] .' '.$company_type['type']?>    
                    </div>
                    <div class="card-tools">
                        <div class="card-title">Date: <b><?= date("F Y", strtotime($date));?></b></div>
                    </div>
                </div>
                <div class="card-body table-responsive">
                    <p class="text-danger"><?=$message?></p>
                    <form action="<?=base_url('SuperAdmin/updateValueSptClient')?>" method="post">
                    <input type="hidden" value="<?= $date ?>" name="spt_date">
                    <input type="hidden" value="<?= $user_id ?>" name="client_id">
                    <input type="hidden" value="<?= $company_type['id'] ?>" name="type_company_id">
                    <h5 class="mt-5">1. ELEMEN DARI NERACA</h5>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card p-3">
                                    <div class="card-header border-0">
                                        <div class="card-title ">Jumlah Asset </div>
                                        <div class="card-tools">
                                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body p-0">
                                        <table id="table1" class="table table-light table-hover">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Description (Indonesian)</th>
                                                    <th>(English)</th>
                                                    <th>Value</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                    $no = 1;
                                    foreach ($sptClient as $rows) {
                                        if ($rows['category_jumlah'] != "Jumlah Asset") {
                                            continue;
                                        }
                                        if (in_array($rows['id'],$dataOld)) {
                                            $checked = "checked";
                                        }
                                        ?>
                                                <tr>
                                                    <td><?=$no;?></td>
                                                    <td><?=$rows['description']?></td>
                                                    <td><?=$rows['en']?></td>
                                                    <td>
                                                        <input type="number" name="value<?= $rows['id'] ?>" value="<?= $rows['value'] ?>" class="form-control" placeholder="ex: 2000..">
                                                    </td>
                                                </tr>
                                                <?php
                                                $checked = "";
                                    $no++;
                                    }
                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="card p-3">
                                    <div class="card-header border-0">
                                        <div class="card-title ">Jumlah Kewajiban dan Ekuitas</div>
                                        <div class="card-tools">
                                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body p-0">
                                        <table id="table2" class="table table-light table-hover">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Description (Indonesian)</th>
                                                    <th>(English)</th>
                                                    <th>Value</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                    $no = 1;
                                    foreach ($sptClient as $row) {
                                        if ($row['category_jumlah'] != 'Jumlah Kewajiban dan Ekuitas') {
                                            continue;
                                        }
                                        
                                        if (in_array($row['id'],$dataOld)) {
                                            $checked = "checked";
                                        }
                                        ?>
                                                <tr>
                                                    <td><?=$no;?></td>
                                                    <td><?=$row['description']?></td>
                                                    <td><?=$row['en']?></td>
                                                    <td>
                                                        <input type="number" name="value<?= $row['id'] ?>" value="<?= $row['value'] ?>" class="form-control" placeholder="ex: 2000..">
                                                    </td>
                                                </tr>
                                                
                                                <?php
                                                $checked = "";
                                    $no++;
                                    }
                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h5 class="mt-5">2. ELEMEN DARI LAPORAN LABA/RUGI</h5>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card p-3">
                                    <div class="card-header border-0">
                                        <div class="card-tools">
                                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body p-0">
                                        <table id="table3" class="table table-light table-hover">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Description (Indonesian)</th>
                                                    <th>(English)</th>
                                                    <th>Value</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                    $no = 1;
                                    foreach ($sptClient as $rows) {
                                        if ($rows['category_jumlah'] != "") {
                                            continue;
                                        }
                                        
                                        if (in_array($rows['id'],$dataOld)) {
                                            $checked = "checked";
                                        }
                                        ?>
                                                <tr>
                                                    <td><?=$no;?></td>
                                                    <td><?=$rows['description']?></td>
                                                    <td><?=$rows['en']?></td>
                                                    <td>
                                                        <input type="number" name="value<?= $rows['id'] ?>" value="<?= $rows['value'] ?>" class="form-control block" placeholder="ex: 2000..">
                                                        <a href="<?=base_url('SuperAdmin')?>" target="blank" class="btn btn-sm mt-1 btn-block btn-secondary">use formula</a>
                                                    </td>
                                                </tr>
                                                <?php
                                                $checked = "";
                                                    $no++;
                                                        }
                                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-save mr-2"></i> save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo base_url(); ?>assets/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url(); ?>assets/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?php echo base_url(); ?>assets/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url(); ?>assets/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url(); ?>assets/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo base_url(); ?>assets/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo base_url(); ?>assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url(); ?>assets/dist/js/pages/dashboard.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>

<script src="<?php echo base_url(); ?>assets/plugins/toastr/toastr.min.js"></script>
<script>
    
    $(document).ready(function(){
            $('.checkall').click(function() {
                $('.list ').attr('checked', true); 

            });
        });
    function leaveChange() {
        if (document.getElementById("leave").value != "Elemen dari Neraca") {
            document.getElementById("jumlah").style.display = 'none';
            document.getElementById("category_jumlah").value = "";
        } else {
            document.getElementById("jumlah").style.display = 'block';
        }
    }
    $(function() {
        $("#table1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "paging": false
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    $(function() {
        $("#table2").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false    ,
            "paging": false

        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    $(function() {
        $("#table3").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "paging": false

        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });

    function close_window() {
        if (confirm("Close Window?")) {
            close();
        }
    }
</script>
</body>

</html>