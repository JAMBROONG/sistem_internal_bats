<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Progress Order</title>

    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />

    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/select2/css/select2.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">

    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <?php include 'header.php' ?>
    
    <!-- Resources -->
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

    <!-- Chart code -->
    <script>
        am5.ready(function() {

            // Create root element
            // https://www.amcharts.com/docs/v5/getting-started/#Root_element
            var root = am5.Root.new("chartdiv");


            // Set themes
            // https://www.amcharts.com/docs/v5/concepts/themes/
            root.setThemes([
                am5themes_Animated.new(root)
            ]);


            // Create chart
            // https://www.amcharts.com/docs/v5/charts/xy-chart/
            var chart = root.container.children.push(am5xy.XYChart.new(root, {
                panX: false,
                panY: false,
                wheelX: "panX",
                wheelY: "zoomX",
                layout: root.verticalLayout
            }));


            // Add legend
            // https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
            var legend = chart.children.push(am5.Legend.new(root, {
                centerX: am5.p50,
                x: am5.p50
            }))


            // Data
            var data = [{
                step: "Input",
                achievement: <?= $percentinput ?> ,
                target: 20
            }, {
                step: "Progress",
                achievement: <?= $percentprocess ?> ,
                target: 60
            }, {
                step: "Output",
                achievement: <?= $percentoutput ?> ,
                target: 20
            }];


            // Create axes
            // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
            var yAxis = chart.yAxes.push(am5xy.CategoryAxis.new(root, {
                categoryField: "step",
                renderer: am5xy.AxisRendererY.new(root, {
                    inversed: true,
                    cellStartLocation: 0.1,
                    cellEndLocation: 0.9
                })
            }));

            yAxis.data.setAll(data);

            var xAxis = chart.xAxes.push(am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererX.new(root, {}),
                min: 0
            }));


            // Add series
            // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
            function createSeries(field, name) {
                var series = chart.series.push(am5xy.ColumnSeries.new(root, {
                    name: name,
                    xAxis: xAxis,
                    yAxis: yAxis,
                    valueXField: field,
                    categoryYField: "step",
                    sequencedInterpolation: true,
                    tooltip: am5.Tooltip.new(root, {
                        pointerOrientation: "horizontal",
                        labelText: "[bold]{name}[/]\n{categoryY}: {valueX}"
                    })
                }));

                series.columns.template.setAll({
                    height: am5.p100
                });


                series.bullets.push(function() {
                    return am5.Bullet.new(root, {
                        locationX: 1,
                        locationY: 0.5,
                        sprite: am5.Label.new(root, {
                            centerY: am5.p50,
                            text: "{valueX} %",
                            populateText: true
                        })
                    });
                });

                series.bullets.push(function() {
                    return am5.Bullet.new(root, {
                        locationX: 1,
                        locationY: 0.5,
                        sprite: am5.Label.new(root, {
                            centerX: am5.p100,
                            centerY: am5.p50,
                            text: "{name}",
                            fill: am5.color(0xffffff),
                            populateText: true
                        })
                    });
                });

                series.data.setAll(data);
                series.appear();

                return series;
            }

            createSeries("achievement", "Achievement");
            createSeries("target", "Target");


            // Add legend
            // https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
            var legend = chart.children.push(am5.Legend.new(root, {
                centerX: am5.p50,
                x: am5.p50
            }));

            legend.data.setAll(chart.series.values);


            // Add cursor
            // https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
            var cursor = chart.set("cursor", am5xy.XYCursor.new(root, {
                behavior: "zoomY"
            }));
            cursor.lineY.set("forceHidden", true);
            cursor.lineX.set("forceHidden", true);


            // Make stuff animate on load
            // https://www.amcharts.com/docs/v5/concepts/animations/
            chart.appear(1000, 100);

        }); // end am5.ready()
    </script>


    <style>
        #chartdiv {
            width: 100%;
            height: 500px;
        }

        .file {
            visibility: hidden;
            position: absolute;
        }
    </style>
</head>

<body class="hold-transition sidebar-mini layout-boxed layout-fixed bg-dark">
    <div class="wrapper shadow bg-white"><?php include'top_nav.php'; ?>
        <aside class="main-sidebar bg-white elevation-2 layout-fixed">
            <a href="<?php echo base_url('SuperAdmin/profile'); ?>" class="brand-link d-flex align-items-center" style="background-color: #1A1A1A;">
                <img src="<?php echo base_url(); ?>assets/upload/images/<?=$user['image']?>" alt="AdminLTE Logo" class="brand-image" style="opacity: .8">
                <small class="text-white font-weight-light">Super Admin</small>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataProject'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-microchip"></i>
                                <p> Services </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataWorkflow'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-project-diagram"></i>
                                <p> Workflow </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataInformation'); ?>" class="nav-link">
                                <i class=" nav-icon fab fa-pied-piper-square"></i>
                                <p> Seminar </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataUser'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-users"></i>
                                <p> Users </p>
                            </a>
                        </li>
                        <li class="nav-header text-black  pt-2">EXTERNAL</li>
                        <li class="nav-item menu-is-opening menu-open">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user nav-icon"></i>
                                <p>
                                    Client
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#E9ECEF;">
                                <li class="nav-item rounded" style="background-color: #66b6d2;">
                                    <a href="<?php echo base_url('SuperAdmin/dataOrder'); ?>" class="nav-link text-white">
                                        <i class="nav-icon fas fa-book"></i>
                                        <p> Order
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataChatt'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-comments"></i>
                                        <p> Chat
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/finances'); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-file-invoice-dollar"></i>
                                        <p> Finance
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataCompany'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-building"></i>
                                        <p> Company </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataRecommendation'); ?>" class="nav-link">
                                        <i class=" nav-icon fa fa-record-vinyl"></i>
                                        <p> Service Recommendation </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataFeedback'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-envelope"></i>
                                        <p> Feedback </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                       <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-clock nav-icon"></i>
                                <p>
                                    Guest
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#E9ECEF;">
                                
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/guestTHC'); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-book-medical"></i>
                                        <p> Tax Health Check
                                        </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">INTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-friends nav-icon"></i>
                                <p>
                                    Employee
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#E9ECEF;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataEmployee'); ?>" class="nav-link text-white">
                                        <i class="nav-icon far fa-user"></i>
                                        <p> Data Employee </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/specialTask'); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-book-reader"></i>
                                        <p> Special Task </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/training'); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-chalkboard-teacher"></i>
                                        <p> Training</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">OTHER</li>
                        <?php include 'navbar_comingsoon.php'; ?>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataHistory'); ?>" class="nav-link">
                                <i class="nav-icon fa fa-history"></i>
                                <p> History </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="content-wrapper bg-white">
            <section class="content">
                <div class="container pt-3">
                    <div class="main-body">
                        <nav aria-label="breadcrumb" class="main-breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
                                <li class="breadcrumb-item"><a href="<?= base_url('SuperAdmin/dataOrder')?>">Order</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Progress</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row d-flex align-items-center">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <div id="chartdiv"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="card shadow-none">
                                <div class="card-body table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th class="bg-danger text-center">Step</th>
                                                <th class="bg-warning text-center">Percentage</th>
                                                <th class="bg-orange text-center">Achievement</th>
                                                <th class="bg-success text-center">Target</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="text-danger text-center" scope="row">Input</td>
                                                <td class="text-warning text-center"><?= $percentInputNow?>%</td>
                                                <td class="text-orange text-center"><?= $percentinput ?>%</td>
                                                <td class="text-success text-center">20%</td>
                                            </tr>
                                            <tr>
                                                <td class="text-danger text-center" scope="row">Progress</td>
                                                <td class="text-warning text-center"><?= $percentProgressNow ?>%</td>
                                                <td class="text-orange text-center"><?= $percentprocess ?>%</td>
                                                <td class="text-success text-center">60%</td>
                                            </tr>
                                            <tr>
                                                <td class="text-danger text-center" scope="row">Output</td>
                                                <td class="text-warning text-center">
                                                    <?php if ($percentoutput == 0 && $percentall == 0) {
                                                    echo 0;
                                                } else{
                                                    echo round(($percentoutput / $percentall) * 100 ,0);
                                                }?>%</td>
                                                <td class="text-orange text-center"><?= $percentoutput ?>%</td>
                                                <td class="text-success text-center">20%</td>
                                            </tr>

                                            <tr>
                                                <td class="text-danger text-bold text-center" colspan="2" scope="row">Total</td>
                                                <th class="text-orange text-center"><?= round($percentall,0)?>%</th>
                                                <th class="text-success text-center">100%</th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-default shadow-none"> <?php 
                            if (empty($dataOrder)) {
                            echo '
                            <div class="card-header bg-danger pt-3">

                            </div>
                            <div class="card-body text-center">
                                <div>
                                    <h2 class=" text-danger">Sorry, your jobtrack is not yet available <i class="fa fa-smile-beam text-danger"></i></h2>
                                    <p class="lead">Let Us Know Your Problem!<br>Phone: <a href="https://wa.me/628161105174">+6281 6110 5174</a></p>
                                </div>
                            </div>
                            ';
                            return false;
                            }
                            $doReport = [];
                            $doProcess = [];
                            foreach ($report as $row) {
                                array_push($doReport,$row['order_step_id']);
                            }
                            foreach ($dataProcess as $row) {
                                array_push($doProcess,$row['order_step_id']);
                            }
                            ?> <div class="card-header bg-danger pb-1">
                                    <div class="d-flex justify-content-between">
                                        <h5>Input</h5>
                                        <div class="card-tools">
                                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                <i class="fas fa-minus text-white"></i>
                                            </button>
                                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                <i class="fas fa-times text-white"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="card">
                                        <div class="card-header ui-sortable-handle bg-dark" style="cursor: move;">
                                            <h3 class="card-title">
                                                <i class="ion ion-clipboard mr-1"></i> Data List
                                            </h3>
                                            <div class="card-tools">
                                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                    <i class="fas fa-minus text-white"></i>
                                                </button>
                                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                    <i class="fas fa-times text-white"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <!-- /.card-header -->
                                        <div class="card-body table-responsive">
                                            <div class="col-md-12 mb-3 d-flex justify-content-center">
                                                <form action="<?= site_url('superAdmin/processCreateData/'.$dataOrder['id'].'/'.$dataOrder['user_id']) ?>" method="post">
                                                    <label for="">Add data to <strong class="text-danger"><?= $dataOrder['name']?></strong> order <strong class="text-danger"><?= $dataOrder['service_name']?></strong> </label>
                                                    <div class="input-group input-group-sm">
                                                        <input type="text" class=" form-control" name="data" placeholder="data name..">
                                                        <span class="input-group-append">
                                                            <button type="submit" class="btn btn-info btn-flat">save</button>
                                                        </span>
                                                    </div>
                                                </form>
                                            </div>
                                            <form action="<?= site_url('superAdmin/processUpdateData/'.$dataOrder['id']) ?>" method="post">
                                                <table id="table_data" class="table table-striped table-inverse ">
                                                    <thead class="thead-inverse">
                                                        <tr>
                                                            <th>No.</th>
                                                            <th>Name</th>
                                                            <th>Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $no = 1;
                                                            foreach ($letter as $row) {
                                                            if ($row['status']=="done") {
                                                                ?>
                                                        <tr>
                                                            <td class="text-center"><?= $no ?></td>
                                                            <td>
                                                                <div class="d-flex justify-content-between">
                                                                    <div class="">

                                                                        <span class="handle ui-sortable-handle">
                                                                            <i class="fas fa-ellipsis-v"></i>
                                                                            <i class="fas fa-ellipsis-v"></i>
                                                                        </span>
                                                                        <div class="icheck-primary d-inline ml-2">
                                                                            <input type="checkbox" value="<?= $row['id'] ?>" name="status[]" id="todoCheck<?=$no;?>" checked="">
                                                                            <label for="todoCheck<?=$no;?>"></label>
                                                                        </div>
                                                                        <span class="text"><?= $row['data'] ?></span>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td><small><?= $row['update_date'] ?></small></td>
                                                            <td><?php
                                                                        if ($row['data_id']!=1 && $row['data_id'] != 2) {
                                                                            ?>
                                                                <button type="button" class="btn text-danger btn-sm" data-toggle="modal" data-target="#modal-delete<?=$row['id']?>" class="text-danger btn-sm"><i class="fa fa-trash"></i> delete</button>
                                                                <?php
                                                                        }
                                                                        ?>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $no++;
                                                            }
                                                            ?>
                                                        <!-- modal for delete order -->
                                                        <div class="modal fade " id="modal-delete<?=$row['id']?>">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title text-danger">Are you sure?</h4>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p class="text-dark">Data <strong><?= $row['data'] ?></strong> </p>
                                                                    </div>
                                                                    <div class="modal-footer justify-content-between">
                                                                        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                                                                        <a href="<?= base_url('superAdmin/deleteData/'.$row['id'].'/'.$dataOrder['id'])?>" class="btn btn-danger">Yes delete</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.modal --> <?php
                                                        }
                                                        foreach ($letter as $row) {
                                                            
                                                            if ($row['status'] == "not yet") {
                                                                ?>

                                                        <tr>
                                                            <td class="text-center"><?= $no ?></td>
                                                            <td>

                                                                <div class="d-flex justify-content-between">
                                                                    <div class="">
                                                                        <span class="handle ui-sortable-handle">
                                                                            <i class="fas fa-ellipsis-v"></i>
                                                                            <i class="fas fa-ellipsis-v"></i>
                                                                        </span>
                                                                        <div class="icheck-primary d-inline ml-2">
                                                                            <input type="checkbox" value="<?= $row['id'] ?>" name="status[]" id="todoCheck<?=$no;?>">
                                                                            <label for="todoCheck<?=$no;?>"></label>
                                                                        </div>
                                                                        <span class="text"><?= $row['data'] ?></span>
                                                                    </div>
                                                                </div>
                                                            <td><small><?= $row['update_date'] ?></small></td>
                                                            <td><?php
                                                                        if ($row['data_id']!=1 && $row['data_id'] != 2) {
                                                                            ?>
                                                                <button type="button" class="btn text-danger btn-sm" data-toggle="modal" data-target="#modal-delete<?=$row['id']?>" class="text-danger btn-sm"><i class="fa fa-trash"></i> delete</button>
                                                                <?php
                                                                        }
                                                                        ?>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                            $no++;
                                                            }
                                                            ?>
                                                        <!-- modal for delete order -->
                                                        <div class="modal fade " id="modal-delete<?=$row['id']?>">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title text-danger">Are you sure?</h4>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p class="text-dark">Data <strong><?= $row['data'] ?></strong> </p>
                                                                    </div>
                                                                    <div class="modal-footer justify-content-between">
                                                                        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                                                                        <a href="<?= base_url('superAdmin/deleteData/'.$row['id'].'/'.$dataOrder['id'])?>" class="btn btn-danger">Yes delete</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /.modal --> <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                                <button type="submit" class="btn btn-sm pl-1 pr-1 btn-success mt-3"><i class="fa fa-save pr-1"></i> save</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header ui-sortable-handle bg-dark" style="cursor: move;">
                                            <h3 class="card-title">
                                                <i class="ion ion-clipboard mr-1"></i> Service Contract from <strong>Admin</strong>
                                            </h3>
                                            <div class="card-tools">
                                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                    <i class="fas fa-minus text-white"></i>
                                                </button>
                                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                    <i class="fas fa-times text-white"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card-body table-responsive">
                                            <table id="table_cfa" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Hardfile</th>
                                                        <th>Filename</th>
                                                        <th>Message</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                          $no = 1;
                                          foreach ($dataContract as $key) {
                                              if ($key['from'] == "admin") {
                                              ?>
                                                    <tr>
                                                        <td><?= $no; ?></td>
                                                        <td>
                                                            <?php 
                                                    if ($key['sent_hardfile'] == "no") {
                                                        echo'not yet sent';
                                                    } elseif ($key['sent_hardfile'] == "yes") {
                                                        if ($key['receive_hardfile'] == "yes") {
                                                            ?>
                                                            <p class="text-success">received on <i class="fa fa-check ml-2"></i>
                                                                <?php
                                                            echo '<small class="text-primary"> ('. date("F j, Y H:i a", strtotime($key['receive_date'])).')</small></p>';
                                                        } else{
                                                            echo 'sent on <small class="text-primary">('. date("F j, Y H:i a", strtotime($key['sent_date'])).')</small>';
                                                        }
                                                    }
                                                    ?>
                                                        </td>
                                                        <td>
                                                            <p><?=$key['filename']?></p>
                                                        </td>
                                                        <td><?=$key['message']?></td>
                                                        <td>
                                                            <?php
                                                    if ($key['status'] == "do") {
                                                        echo '<p class="text-warning">not fixed</p>';
                                                    } else{
                                                        echo '<p class="text-success">fixed <i class="fa fa-check"></i></p>';
                                                    }
                                                    ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if ($key['softfile'] != "") { ?>
                                                            <a href="<?= base_url();?>assets/upload/doc/<?=$key['softfile']?>" download class="btn btn-sm btn-primary mr-2"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                } else{?>
                                                            <a class="btn btn-sm btn-secondary mr-2 btn-disabled" data-toggle="modal" data-target="#modal-noDownload"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <?php
                                              $no++;
                                                }
                                          }
                                          ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header ui-sortable-handle bg-dark" style="cursor: move;">
                                            <h3 class="card-title">
                                                <i class="ion ion-clipboard mr-1"></i> Service Contract from <strong>Client</strong>
                                            </h3>
                                            <div class="card-tools">
                                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                    <i class="fas fa-minus text-white"></i>
                                                </button>
                                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                    <i class="fas fa-times text-white"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card-body table-responsive">
                                            <table id="table_cfc" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Hardfile</th>
                                                        <th>Filename</th>
                                                        <th>Message</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                          $no = 1;
                                          foreach ($dataContract as $key) {
                                              if ($key['from'] == "client") {
                                              ?>
                                                    <tr>
                                                        <td><?= $no; ?></td>
                                                        <td>
                                                            <?php 
                                                    if ($key['sent_hardfile'] == "no") {
                                                        echo'not yet sent';
                                                    } elseif ($key['sent_hardfile'] == "yes") {
                                                        if ($key['receive_hardfile'] == "yes") {
                                                            ?>
                                                            <p class="text-success">received on <i class="fa fa-check ml-2"></i>
                                                                <?php
                                                            echo '<small class="text-primary"> ('. date("F j, Y H:i a", strtotime($key['receive_date'])).')</small></p>';
                                                        } else{
                                                            echo 'sent on <small class="text-primary">('. date("F j, Y H:i a", strtotime($key['sent_date'])).')</small>';
                                                        }
                                                    }
                                                    ?>
                                                        </td>
                                                        <td>
                                                            <p><?=$key['filename']?></p>
                                                        </td>
                                                        <td><?=$key['message']?></td>
                                                        <td>
                                                            <?php
                                                    if ($key['status'] == "do") {
                                                        echo '<p class="text-warning">not fixed</p>';
                                                    } else{
                                                        echo '<p class="text-success">fixed <i class="fa fa-check"></i></p>';
                                                    }
                                                    ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if ($key['softfile'] != "") { ?>
                                                            <a href="<?= base_url();?>assets/upload/doc/<?=$key['softfile']?>" download class="btn btn-sm btn-primary mr-2"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                } else{?>
                                                            <a class="btn btn-sm btn-secondary mr-2 btn-disabled" data-toggle="modal" data-target="#modal-noDownload"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <?php
                                              $no++;
                                                }
                                          }
                                          ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="card">
                                        <div class="card-header ui-sortable-handle bg-dark" style="cursor: move;">
                                            <h3 class="card-title">
                                                <i class="ion ion-clipboard mr-1"></i> Invoices
                                            </h3>
                                            <div class="card-tools">
                                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                    <i class="fas fa-minus text-white"></i>
                                                </button>
                                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                    <i class="fas fa-times text-white"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card-body table-responsive">
                                            <table id="table_i" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Hardfile</th>
                                                        <th>Filename</th>
                                                        <th>Message</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                          $no = 1;
                                          foreach ($dataInvoice as $key) {
                                              ?>
                                                    <tr>
                                                        <td><?= $no; ?></td>
                                                        <td>
                                                            <?php 
                                                    if ($key['sent_hardfile'] == "no") {
                                                        echo'not yet sent';
                                                    } elseif ($key['sent_hardfile'] == "yes") {
                                                        if ($key['receive_hardfile'] == "yes") {
                                                            ?>
                                                            <p class="text-success">received on <i class="fa fa-check ml-2"></i></p>
                                                            <?php
                                                        } else{
                                                            echo 'sent on <small class="text-primary">('. date("F j, Y H:i a", strtotime($key['sent_date'])).')</small>';
                                                        }
                                                    }
                                                    ?>
                                                        </td>
                                                        <td>
                                                            <p><?=$key['filename']?></p>
                                                        </td>
                                                        <td><?=$key['message']?></td>
                                                        <td>
                                                            <?php
                                                    if ($key['status'] == "do") {
                                                        echo '<p class="text-warning">not fixed</p>';
                                                    } else{
                                                        
                                                        echo '<p class="text-success">fixed <i class="fa fa-check"></i></p>';
                                                    }
                                                    ?>
                                                        </td>
                                                        <td>

                                                            <?php
                                                            if ($key['softfile'] != "") { ?>
                                                            <a href="<?= base_url();?>assets/upload/invoice/<?=$key['softfile']?>" download class="btn btn-sm btn-primary mr-2"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                } else{?>
                                                            <a class="btn btn-sm btn-secondary mr-2 btn-disabled" data-toggle="modal" data-target="#modal-noDownload"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                }
                                                            ?>

                                                        </td>
                                                    </tr>
                                                    <?php
                                              $no++;
                                          }
                                          ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="card card-dark">
                                        <div class="card-header">
                                            <div class="d-flex justify-content-between">
                                                <h5>Proff of Payment</h5>
                                                <div class="card-tools">
                                                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                        <i class="fas fa-minus text-white"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                        <i class="fas fa-times text-white"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <table id="table_pop" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Filename</th>
                                                        <th>Message</th>
                                                        <th>Date</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                          $no = 1;
                                          foreach ($dataPayment as $key) {
                                              ?>
                                                    <tr>
                                                        <td><?= $no; ?></td>
                                                        <td>
                                                            <p><?=$key['filename']?></p>
                                                        </td>
                                                        <td><?=$key['message']?></td>
                                                        <td>
                                                            <?php
                                                            echo '<small class="text-primary">'. date("F j, Y H:i a", strtotime($key['create_date'])).'</small>';
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                            if ($key['softfile'] != "") { ?>
                                                            <a class="btn btn-sm btn-primary mr-2" href="<?= base_url();?>assets/upload/doc/<?=$key['softfile']?>" download><i class="fa fa-download"></i></a>
                                                            <?php
                                                                } else{?>
                                                            <a class="btn btn-sm btn-secondary mr-2 btn-disabled" data-toggle="modal" data-target="#modal-noDownload"><i class="fa fa-download"></i></a>
                                                            <?php
                                                                }
                                                            ?>
                                                        </td>
                                                    </tr>
                                                    <?php
                                              $no++;
                                          }
                                          ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header ui-sortable-handle bg-dark" style="cursor: move;">
                                            <h3 class="card-title">
                                                <i class="ion ion-clipboard mr-1"></i> Other Files
                                            </h3>
                                            <div class="card-tools">
                                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                    <i class="fas fa-minus text-white"></i>
                                                </button>
                                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                    <i class="fas fa-times text-white"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="card-body table-responsive">
                                            <table id="table_of" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Filename</th>
                                                        <th>Description</th>
                                                        <th>Link</th>
                                                        <th>Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody> <?php
                                                            $no = 1;
                                                            if (empty($dataFile)) {
                                                               ?> <tr role="row" class="odd">
                                                        <td class="dtr-control sorting_1" tabindex="0" colspan="6">
                                                            <h5 class="text-center">Data not yet</h5>
                                                        </td>
                                                    </tr> <?php
                                                            }
                                                            else{
                                                            foreach ($dataFile as $row) {
                                                        ?> <tr role="row" class="odd">
                                                        <td class="dtr-control sorting_1" tabindex="0"><?= $no;?></td>
                                                        <td><?= $row['filename']?></td>
                                                        <td><?= $row['description']?></td>
                                                        <td><?= $row['link']?> <a href="<?= $row['link']?>" target="blank"><i class="fa fa-external-link-alt ml-2"></i></a></td>
                                                        <td><?= date("F j, Y, g:i a",strtotime($row['create_date'])); ?></td>
                                                    </tr>
                                                    <?php
                                                            $no++;
                                                            }
                                                            }
                                                        ?> </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card card-default shadow-none">
                        <div class="card-header bg-danger border-0">
                            <h3 class="card-title">Process</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus text-white"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times text-white"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="card">
                                <div class="card-header border-0 bg-dark">
                                    <h3 class="card-title">Progress this service</h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                            <i class="fas fa-minus text-white"></i>
                                        </button>
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times text-white"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body table-responsive">
                                    <table id="table_process" class="table table-striped table-valign-middle">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Step</th>
                                                <th>Activities</th>
                                                <th>Status</th>
                                                <th>Estimasi</th>
                                                <th>Employee</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody> <?php
                                                $no = 1;
                                                $step = "";
                                                foreach ($dataProcess as $row) {
                                                    ?> <tr>

                                                <td class="text-center">
                                                    <?php
                                                    if($row['step'] == $step){
                                                        ?>
                                                    <p class="d-none"><?=$no?></p>
                                                    <?php
                                                    } else{
                                                        echo $no;
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if($row['step'] == $step){
                                                        echo " ";
                                                    } else{
                                                        
                                                        echo $row['step'];
                                                        
                                                        $step = $row['step'];
                                                        $no++;
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?= $row['subStep']?>
                                                </td>
                                                <td> <?php
                                                        if ($row['status']=='done') {
                                                            echo 'done <i class="fas fa-check-square text-success"></i>';
                                                        }
                                                        else{
                                                            echo 'do <i class="fas fa-cog fa-spin text-warning"></i> ';
                                                        }
                                                    ?> </td>
                                                <td>
                                                    <?php
                                                     $todayDateObj = new \DateTime(date('Y-m-d'));
                                                     $foundedDateObj = new \DateTime(date("Y-m-d", strtotime($row['estimasi'])));
                                                     $interval = $todayDateObj->diff($foundedDateObj);
                                                     $interval = $interval->format('%r%a') . "\n\n";
                                                     echo date("F j, Y", strtotime($row['estimasi']));
                                                     if ($interval > 0 ) {
                                                         ?>
                                                    <p class="text-success">(<?=$interval?>more days)</p>
                                                    <?php
                                                     }
                                                    else{
                                                        ?>
                                                    <p class="text-danger">(<?=$interval?>days ago)</p>
                                                    <?php
                                                    }
                                                     ?>
                                                </td>
                                                <td>
                                                    <img src="<?= base_url();?>assets/upload/images/employee/<?=$row['image']?>" alt="Product 1" class="img-circle img-size-32 mr-2"> <?=$row['employee_name'];?>
                                                </td>
                                                <td>
                                                    <a href="<?= base_url('SuperAdmin/updateProgress/'.$row['id']).'/'.$dataOrder['id'];?>" class="text-primary mr-1">detail</a>
                                                </td>
                                            </tr> <?php
                                                }
                                                ?> </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow-none">
                            <div class="card-body">
                                <div class="card">
                                    <div class="card-header bg-dark border-0">
                                        <h3 class="card-title">Create Progress</h3>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= site_url('superAdmin/processCreateProgress/'.$dataOrder['id']) ?>" method="post" class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Sub Step</label>
                                                    <input type="hidden" name="" value="<?= $dataOrder['id'] ?>">
                                                    <select class="form-control select2" name="order_step_id" style="width: 100%;"> <?php
                                        foreach ($subStep as $row) {
                                            if (in_array($row['id'],$doProcess)) {
                                                continue;
                                            }
                                            echo '<option value="'.$row['id'].'">'.$row['subStep'].'</option>';
                                        }
                                        ?> </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Estimasi</label>
                                                    <input type="date" name="estimasi" class=" form-control" id="" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Employee</label>
                                                    <select class="form-control select2" name="employee" style="width: 100%;"> <?php
                                        foreach ($dataStaff as $row) {
                                            echo '<option value="'.$row['id_employee'].'">'.$row['employee_name'].'</option>';
                                        }
                                        ?> </select>
                                                </div>
                                                <div class="form-group d-none">
                                                    <label>Status</label>
                                                    <select class="form-control select2" name="status" style="width: 100%;">
                                                        <option value="do">Do<i class="fas fa-cog fa-spin text-warning"></i></option>
                                                        <option value="done">Done<i class="fas fa-check-square text-success"></i></option>
                                                    </select>
                                                </div>
                                                <a href="<?=base_url('superAdmin/dataOrder') ?>" class="btn btn-danger  btn-sm"><i class="fa fa-arrow-left pr-1"></i> back</a>
                                                <button type="submit" class="btn btn-sm pl-1 pr-1 btn-success"><i class="fa fa-save pr-1"></i> save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card card-default shadow-none">
                        <div class="card-header bg-danger border-0">
                            <h3 class="card-title">Output</h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-minus text-white"></i>
                                </button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove">
                                    <i class="fas fa-times text-white"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="card card-dark">
                                <div class="card-header border-0">
                                    <h3 class="card-title">All Report
                                        <a type="button" class="btn p-0 text-warning btn-sm" data-toggle="modal" data-target="#modal-AllReport"><i class="fa fa-question"></i></a>
                                    </h3>
                                    <div class="card-tools">
                                        <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                            <i class="fas fa-minus text-white"></i>
                                        </button>
                                        <button type="button" class="btn btn-tool" data-card-widget="remove">
                                            <i class="fas fa-times text-white"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body table-responsive">
                                    <table id="table_AllReport" class="table table-striped table-valign-middle">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Activities</th>
                                                <th>Message</th>
                                                <th>Date</th>
                                                <th>Review by Ceo</th>
                                                <th>Review by Supervisor</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody> <?php
                                            $no = 1;
                                            foreach ($report as $row) {
                                            ?> <tr>
                                                <td><?=$no?></td>
                                                <td><?=$row['subStep']?></td>
                                                <td><?=$row['message']?></td>
                                                <td><?= date("F j, Y", strtotime($row['update_date']))?></td>
                                                <td>
                                                    <?php
                                                    if ($row['review_ceo'] == 'do') {
                                                        echo'<p class="text-warning">do <i class="fa fa-cog ml-1"></i></p>';
                                                    } else{
                                                        echo'<p class="text-success">done <i class="fa fa-check ml-1" ></i></p>';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if ($row['review_supervisor'] == 'do') {
                                                        echo'<p class="text-warning">do <i class="fa fa-cog ml-1" ></i></p>';
                                                    } else{
                                                        echo'<p class="text-success">done <i class="fa fa-check ml-1" ></i></p>';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-around">
                                                        <a href="<?=base_url()?>assets/upload/report/<?=$row['report']?>" class="btn mr-1 btn-sm btn-primary" download><i class="fa fa-download"></i></a>
                                                        <a href="<?= base_url('superAdmin/updateReport/'.$row['id']) ?>" class="btn mr-1 btn-sm btn-success">update</a>
                                                        <a type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#modal-delete-report<?=$row['id']?>"><i class="fa fa-trash"></i></a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <!-- modal for delete report -->
                                            <div class="modal fade " id="modal-delete-report<?=$row['id']?>">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title text-danger">Are you sure delete this report?</h4>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p class="text-dark">Sub Step: <br><strong><?= $row['subStep'] ?></strong> </p>
                                                            <p class="text-dark">Message: <br><strong><?= $row['message'] ?> </strong> </p>
                                                        </div>
                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                            <a href="<?= base_url('superAdmin/deleteReport/'.$row['id'].'/'.$dataOrder['id'])?>" class="btn btn-success">Yes delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- /.modal --> <?php
                                            $no++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="card shadow-none">
                            <div class="card-body">
                                <div class="card">
                                    <div class="card-header border-0  bg-dark">
                                        <h3 class="card-title">Create Report & Timeline Review</h3>
                                    </div>
                                    <div class="card-body">
                                        <form action="<?= site_url('superAdmin/processCreateReport') ?>" method="post" class="row" enctype="multipart/form-data">
                                            <div class="col-md-6">
                                                <h5 class="text-center">To Report</h5>
                                                <div class="form-group">
                                                    <label>Select Process</label>
                                                    <input type="hidden" name="order_id" value="<?= $dataOrder['id'] ?>">
                                                    <select class="form-control select2" name="process_id" style="width: 100%;"> <?php
                                                        foreach ($dataProcessDone as $row) {
                                                            if (in_array($row['order_step_id'],$doReport)) {
                                                                continue;
                                                            }
                                                            echo '<option value="'.$row['id'].'">'.$row['subStep'].'</option>';
                                                        }
                                                        ?> </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Message to this report</label>
                                                    <textarea name="message" id="" cols="30" rows="4" class="form-control" placeholder="message.."></textarea>
                                                </div>
                                                <div class="input-group">
                                                    <input type="file" name="image" class="file">
                                                    <div class="input-group my-3">
                                                        <input required type="text" class="form-control" disabled placeholder="Upload Gambar" id="file">
                                                        <div class="input-group-append">
                                                            <button type="button" id="pilih_gambar" class="browse btn btn-dark">Select File</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h5 class="text-center">To Review</h5>
                                                <div class="form-group">
                                                    <label>Ending Date</label>
                                                    <input type="date" name="ending_date" class="form-control" id="">
                                                </div>
                                                <a href="<?=base_url('superAdmin/dataOrder') ?>" class="btn btn-danger  btn-sm"><i class="fa fa-arrow-left pr-1"></i> back</a>
                                                <button type="submit" class="btn btn-sm pl-1 pr-1 btn-success"><i class="fa fa-save pr-1"></i> save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="card card-dark">
                                    <div class="card-header border-0">
                                        <h3 class="card-title">Reviewed by Supervisor <a type="button" class="btn p-0 text-warning btn-sm" data-toggle="modal" data-target="#modal-ReviewBySupervisor"><i class="fa fa-question"></i></a></h3>
                                        </h3>
                                    </div>
                                    <div class="card-body table-responsive">
                                        <table id="table_rbs" class="table table-striped table-valign-middle">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Activities</th>
                                                    <th>Message</th>
                                                    <th>Date</th>
                                                    <th>Review by Supervisor</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody> <?php
                                            $no = 1;
                                            foreach ($report as $row) {
                                                if ($row['review_supervisor'] == "done") {
                                            ?> <tr>
                                                    <td><?=$no?></td>
                                                    <td><?=$row['subStep']?></td>
                                                    <td><?=$row['message']?></td>
                                                    <td><?= date("F j, Y", strtotime($row['update_date']))?></td>
                                                    <td>
                                                        <?php
                                                    if ($row['review_supervisor'] == 'do') {
                                                        echo'<p class="text-warning">do <i class="fa fa-cog ml-1" ></i></p>';
                                                    } else{
                                                        echo'<p class="text-success">done <i class="fa fa-check ml-1" ></i></p>';
                                                    }
                                                    ?>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex justify-content-around">
                                                            <a href="<?=base_url()?>assets/upload/report/<?=$row['report']?>" class="btn mr-1 btn-sm btn-primary" download><i class="fa fa-download"><small class="ml-2">download</small></i></a>
                                                            <?php
                                                        if ($row['review_ceo'] == "done") {
                                                            ?>
                                                            <a type="button" class="btn btn-outline-danger btn-sm" data-toggle="modal" data-target="#modal-NreviewCeo<?=$row['id']?>"><i class="fa fa-ban"><small class="ml-1">Cancel</small></i></a>
                                                            <?php 
                                                        } else{
                                                        ?>
                                                            <a type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#modal-reviewCeo<?=$row['id']?>"><i class="fa fa-check"><small class="ml-1">Approved</small></i></a>
                                                            <?php
                                                        }
                                                        ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <!-- modal for delete report -->
                                                <div class="modal fade " id="modal-reviewCeo<?=$row['id']?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title text-danger">Are you sure?</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Reports that have been approved will be sent directly to the client for approval.</p>
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?= base_url('superAdmin/approveReport/'.$row['review_id'].'/'.$dataOrder['id'])?>" class="btn btn-success">Yes Approved</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade " id="modal-NreviewCeo<?=$row['id']?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title text-danger">Are you sure?</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>With this you will remove approval on this report.</p>
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?= base_url('superAdmin/approveReport/'.$row['review_id'].'/'.$dataOrder['id'])?>" class="btn btn-success">Yes Cancel</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /.modal --> <?php
                                            $no++;
                                                    }
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="card card-dark">
                                    <div class="card-header border-0">
                                        <h3 class="card-title">Final Report <a type="button" class="btn p-0 text-warning btn-sm" data-toggle="modal" data-target="#modal-finalReport"><i class="fa fa-question"></i></a></h3>
                                        </h3>
                                    </div>
                                    <div class="card-body table-responsive">
                                        <table id="table_fr" class="table table-striped table-valign-middle">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Activities</th>
                                                    <th>Message</th>
                                                    <th>Date</th>
                                                    <th>Review by Supervisor</th>
                                                    <th>Review by Ceo</th>
                                                    <th>Review by Client</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody> <?php
                                            $no = 1;
                                            foreach ($report as $row) {
                                                if ($row['review_supervisor'] == "done" && $row['review_ceo'] == "done" && $row['review_status'] == "done") {
                                            ?> <tr>
                                                    <td><?=$no?></td>
                                                    <td><?=$row['subStep']?></td>
                                                    <td><?=$row['message']?></td>
                                                    <td><?= date("F j, Y", strtotime($row['update_date']))?></td>
                                                    <td>
                                                        <?php
                                                    if ($row['review_supervisor'] == 'do') {
                                                        echo'<p class="text-warning">do <i class="fa fa-cog ml-1" ></i></p>';
                                                    } else{
                                                        echo'<p class="text-success">done <i class="fa fa-check ml-1" ></i></p>';
                                                    }
                                                    ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                    if ($row['review_ceo'] == 'do') {
                                                        echo'<p class="text-warning">do <i class="fa fa-cog ml-1" ></i></p>';
                                                    } else{
                                                        echo'<p class="text-success">done <i class="fa fa-check ml-1" ></i></p>';
                                                    }
                                                    ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                    if ($row['review_status'] == 'do') {
                                                        echo'<p class="text-warning">do <i class="fa fa-cog ml-1" ></i></p>';
                                                    } else{
                                                        echo'<p class="text-success">done <i class="fa fa-check ml-1" ></i></p>';
                                                    }
                                                    ?>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex justify-content-around">
                                                            <a href="<?=base_url()?>assets/upload/report/<?=$row['report']?>" class="btn mr-1 btn-sm btn-primary" download><i class="fa fa-download"><small class="ml-2">download</small></i></a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <!-- modal for delete report -->
                                                <div class="modal fade " id="modal-reviewCeo<?=$row['id']?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title text-danger">Are you sure?</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Reports that have been approved will be sent directly to the client for approval.</p>
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?= base_url('superAdmin/approveReport/'.$row['review_id'].'/'.$dataOrder['id'])?>" class="btn btn-success">Yes Approved</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade " id="modal-NreviewCeo<?=$row['id']?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title text-danger">Are you sure?</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>With this you will remove approval on this report.</p>
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?= base_url('superAdmin/approveReport/'.$row['review_id'].'/'.$dataOrder['id'])?>" class="btn btn-success">Yes Cancel</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /.modal --> <?php
                                            $no++;
                                                    }
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card card-default shadow-none">
                            <div class="card-body">
                                <div class="card card-dark">
                                    <div class="card-header border-0">
                                        <h3 class="card-title">Schedule Meeting</h3>
                                        <div class="card-tools">
                                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                                <i class="fas fa-minus text-white"></i>
                                            </button>
                                            <button type="button" class="btn btn-tool" data-card-widget="remove">
                                                <i class="fas fa-times text-white"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-end">
                                            <button data-toggle="modal" class="btn btn-sm btn-success mb-2" data-target="#modal-addMeeting"><i class="fa fa-plus"></i> add data</button>
                                        </div>
                                        <table id="table_meeting" class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Room</th>
                                                    <th>Link</th>
                                                    <th>Date</th>
                                                    <th>Message</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                              $no = 1;
                                              foreach ($dataMeeting as $row) {
                                              ?>
                                                <tr>
                                                    <td><?=$no?></td>
                                                    <td><?=$row['via']?></td>
                                                    <td><?=$row['link']?></td>
                                                    <td><?=$row['date']?></td>
                                                    <td><?=$row['message']?></td>
                                                    <td><?=$row['status']?></td>
                                                    <td>
                                                        <button class="btn btn-sm btn-danger mr-2" data-toggle="modal" data-target="#modal-deleteMeeting<?=$row['id']?>"><i class="fa fa-trash"></i></button>
                                                        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-editMeeting<?=$row['id']?>"><i class="fa fa-edit"></i></button>
                                                    </td>
                                                </tr>

                                                <div class="modal fade " id="modal-deleteMeeting<?=$row['id']?>">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title text-danger">Are you sure to Delete?</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-footer justify-content-between">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                <a href="<?= base_url('SuperAdmin/deleteMeeting/'.$row['id'].'/'.$dataOrder['id']) ?>" class="btn btn-success">Yes Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade " id="modal-editMeeting<?=$row['id']?>">
                                                    <div class="modal-dialog modal-xl">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">Are you sure to Update?</h4>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-md-6">
                                                                        <div class="card shadow-none">
                                                                            <div class="card-body">
                                                                                <h5 class="card-title">Meeting room</h5>
                                                                                <p class="card-text  text-muted"><?=$row['via']?></p>
                                                                                <h5 class="card-title">Link/Address</h5>
                                                                                <p class="card-text  text-muted"><?=$row['link']?></p>
                                                                                <h5 class="card-title">Date</h5>
                                                                                <p class="card-text  text-muted"><?=$row['date']?></p>
                                                                                <hr>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <h5 class="card-title">Permission display</h5> <?php
                                                                        if ($row['permission'] == 'no') {
                                                                            ?> <small class="text-danger ml-3"><strong>not approved </strong>
                                                                                            <i class="fas fa-times-circle"></i>
                                                                                        </small>
                                                                                        <br>
                                                                                        <a data-toggle="modal" data-target="#modal-updatePermission" class="btn btn-sm btn-success">turn on</a> <?php
                                                                        } else
                                                                        {
                                                                            ?> <small class="text-success ml-3"><strong>approved </strong>
                                                                                            <i class="fa fa-check-circle"></i>
                                                                                        </small>
                                                                                        <br>
                                                                                        <a href="<?= base_url('SuperAdmin/updateStatusMeetingP/'.$row['id'].'/'.$dataOrder['id']) ?>" class="btn btn-sm btn-danger">turn off</a>
                                                                                        <p class="text-danger">if it is disabled, the user cannot specify the meeting.</p> <?php
                                                                        }
                                                                        ?>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <h5 class="card-title">Fixed meeting</h5> <?php
                                                                        if ($row['fixed'] == 'no') {
                                                                            ?> <small class="text-danger ml-3"><strong>not fixed </strong>
                                                                                            <i class="fas fa-times-circle"></i>
                                                                                        </small>
                                                                                        <br>
                                                                                        <a data-toggle="modal" data-target="#modal-updateFixed" class="btn btn-sm btn-success">turn on</a> <?php
                                                                        } else
                                                                        {
                                                                            ?> <small class="text-success ml-3"><strong>fixed </strong>
                                                                                            <i class="fa fa-check-circle"></i>
                                                                                        </small>
                                                                                        <br>
                                                                                        <a href="<?= base_url('SuperAdmin/updateStatusMeetingF/'.$row['id'].'/'.$dataOrder['id']) ?>" class="btn btn-sm btn-danger">turn off</a>
                                                                                        <p class="text-danger">if it is deactivated, the meeting schedule can be changed again.</p><?php
                                                                        }
                                                                        ?>
                                                                                    </div>
                                                                                    <div class="col-md-6">
                                                                                        <br>
                                                                                        <h5 class="card-title">Status Meeting</h5>
                                                                                        <?php
                                                                                if ($row['status'] == 'do') {
                                                                                    ?> <small class="text-warning ml-3"><strong>do</strong>
                                                                                            <i class="fas fa-times-circle"></i>
                                                                                        </small>
                                                                                        <br>
                                                                                        <a href="<?= base_url('SuperAdmin/updateStatusMeeting/'.$row['id'].'/'.$dataOrder['id']) ?>" class="btn btn-sm btn-success">turn done</a>
                                                                                        <?php
                                                                                } else
                                                                                {
                                                                                    ?> <small class="text-success ml-3"><strong>done</strong>
                                                                                            <i class="fa fa-check-circle"></i>
                                                                                        </small>
                                                                                        <br>
                                                                                        <a href="<?= base_url('SuperAdmin/updateStatusMeeting/'.$row['id'].'/'.$dataOrder['id']) ?>" class="btn btn-sm btn-danger">turn do</a>
                                                                                        <?php
                                                                                }
                                                                                ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="card card-info">
                                                                            <div class="card-body"> <?php
                                                                        if ($row['fixed'] == 'yes') {
                                                                            ?> <form action="<?=base_url('SuperAdmin/updateMeeting')?>" method="post">
                                                                                    <div class="form-group">
                                                                                        <input id="my-input" class="form-control" type="hidden" name="id" value="<?=$row['id']?>">
                                                                                        <input id="my-input" class="form-control" type="hidden" name="order_id" value="<?= $dataOrder['id'] ?>">
                                                                                        <label for="my-input">Meeting room</label>
                                                                                        <input id="my-input" class="form-control" type="text" name="via" value="<?=$row['via']?>" disabled>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="my-input">Link/address</label>
                                                                                        <textarea name="link" id="" cols="30" rows="3" class=" form-control" disabled><?=$row['link']?></textarea>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="my-input">Date</label>
                                                                                        <div class="d-flex">
                                                                                            <input id="my-input" class="form-control" type="date" name="date" value="<?= date("Y-m-d", strtotime($row['date'])); ?>" disabled>
                                                                                            <input id="my-input" class="form-control" type="time" name="time" value="<?= date("H:i:s", strtotime($row['date'])); ?>" disabled>
                                                                                        </div>
                                                                                    </div>
                                                                                    <p class="text-danger">the final meeting has been agreed</p>
                                                                                </form> <?php
                                                                        } else
                                                                        {
                                                                            ?>
                                                                                <form action="<?=base_url('SuperAdmin/updateMeeting')?>" method="post">
                                                                                    <div class="form-group">
                                                                                        <input id="my-input" class="form-control" type="hidden" name="id" value="<?=$row['id']?>">
                                                                                        <input id="my-input" class="form-control" type="hidden" name="order_id" value="<?= $dataOrder['id'] ?>">
                                                                                        <label for="my-input">Meeting room</label>
                                                                                        <input id="my-input" class="form-control" type="text" name="via" value="<?=$row['via']?>">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="my-input">Link/address</label>
                                                                                        <textarea name="link" id="" cols="30" rows="3" class=" form-control"><?=$row['link']?></textarea>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="my-input">Date</label>
                                                                                        <div class="d-flex">
                                                                                            <input id="my-input" class="form-control" type="date" name="date" value="<?= date("Y-m-d", strtotime($row['date'])); ?>">
                                                                                            <input id="my-input" class="form-control" type="time" name="time" value="<?= date("H:i:s", strtotime($row['date'])); ?>">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-sm btn-success" type="submit"><i class="fa fa-save mr-2"></i> save</button>
                                                                                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
                                                                                </form> <?php
                                                                        }
                                                                        ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                              $no++;
                                              }
                                              ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="card bg-danger p-5">
                                    <div class="card-body text-center">
                                        <h4>Turn FINISH Order</h4>
                                        <button class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal-turnFinish">Done <i class="fa fa-check ml-2"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        
        <?php include 'footer.php'; ?>
        <!-- modal for delete report -->
        <div class="modal fade " id="modal-updatePermission">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title text-danger">Are you sure to update?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-danger">If activated, the client will have access to determine the meeting!</p>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <a href="<?= base_url('superAdmin/updateStatusMeetingP/'.$meeting['id'].'/'.$dataOrder['id']) ?>" class="btn btn-success">Yes update</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade " id="modal-noDownload">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body text-center">
                        <p>The data has been downloaded</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade " id="modal-turnFinish">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title text-danger">Are you sure to turn Finish?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="">With this the selected order status will be <strong class="text-success">completed</strong></p>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <a href="<?= base_url('superAdmin/turnFinishOrder/'.$dataOrder['id']) ?>" class="btn btn-success">Yes Finish</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal -->
        <!-- modal for delete report -->
        <div class="modal fade " id="modal-updateFixed">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title text-danger">Are you sure to update?</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-danger">hereby you have set a meeting schedule!</p>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <a href="<?= base_url('superAdmin/updateStatusMeetingF/'.$meeting['id'].'/'.$dataOrder['id']) ?>" class="btn btn-success">Yes update</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.modal -->

        <div class="modal fade" id="modal-addMeeting">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Create Schedule Meeting</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= site_url('SuperAdmin/createMeeting') ?>" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card shadow-none">
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label for="my-input">Date</label>
                                                <input type="hidden" name="id_order" value="<?= $dataOrder['id']?>" required>
                                                <div class="d-flex">
                                                    <input id="my-input" class="form-control" type="date" name="date" required>
                                                    <input id="my-input" class="form-control" type="time" name="time" required>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="my-input">Room</label>
                                                <input type="text" name="via" class="form-control" id="" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="my-input">Link/Address</label>
                                                <textarea name="link" id="" cols="30" rows="5" class="form-control" required></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card shadow-none">
                                        <div class="card-body">
                                            <div class="form-group">
                                                <label for="my-input">Message</label>
                                                <textarea name="message" id="" cols="30" rows="10" class="form-control" required></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-success"><i class="fa fa-save mr-2"></i> save</button>
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- MODAL -->
        <div class="modal fade " id="modal-AllReport">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title text-warning">explanation</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-dark">Contains all employee report data</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade " id="modal-ReviewBySupervisor">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title text-warning">explanation</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-dark">Contains a report that has been reviewed by the supervisor.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade " id="modal-finalReport">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title text-warning">explanation</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-dark">This is the final report, it has been approved by all parties.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page specific script -->

        <!-- Select2 -->
        <script src="<?php echo base_url(); ?>assets/plugins/select2/js/select2.full.min.js"></script>
        <!-- DataTables  & Plugins -->
        <script src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jszip/jszip.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/pdfmake/pdfmake.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/pdfmake/vfs_fonts.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>


        <script>
            $(function() {
                $('.select2').select2()
            });
        </script>
        <script>
            $(document).on("click", "#pilih_gambar", function() {
                var file = $(this).parents().find(".file");
                file.trigger("click");
            });
            $('input[type="file"]').change(function(e) {
                var fileName = e.target.files[0].name;
                $("#file").val(fileName);
                var reader = new FileReader();
                reader.onload = function(e) {
                    // document.getElementById("preview").src = e.target.result;
                };
                // read the image file as a data URL.
                reader.readAsDataURL(this.files[0]);
            });
            $(function() {
                $("#table_process").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_data").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": true,
                    "paging": false,
                    "ordering": true,
                    "info": false,
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_meeting").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_AllReport").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });

            $(function() {
                $("#table_rbs").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_fr").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_cfa").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_cfc").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_i").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_pop").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
            $(function() {
                $("#table_of").DataTable({
                    "responsive": true,
                    "lengthChange": false,
                    "autoWidth": false,
                    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
                }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            });
        </script>
</body>

</html>