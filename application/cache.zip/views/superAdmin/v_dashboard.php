<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Super Admin Dashboard</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" /> <?php include 'header.php';
  ?>

    <!-- Styles -->
    <style>
    #chartdiv {
            width: 100%;
            height: 500px;
        }
    .card {
        border-radius: 4px;
        background: #fff;
        box-shadow: 0 6px 10px rgba(0, 0, 0, .08), 0 0 6px rgba(0, 0, 0, .05);
        transition: 2.3s transform cubic-bezier(.155, 1.105, .295, 1.12), 2.3s box-shadow, 2.3s -webkit-transform cubic-bezier(.155, 1.105, .295, 1.12);
        cursor: pointer;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 10px 20px rgba(0, 0, 0, .12), 0 4px 8px rgba(0, 0, 0, .06);
    }
    .scale-up-bottom{-webkit-animation:scale-up-bottom 1s cubic-bezier(.39,.575,.565,1.000) both;animation:scale-up-bottom 1s cubic-bezier(.39,.575,.565,1.000) both}
@-webkit-keyframes scale-up-bottom{0%{-webkit-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:50% 100%;transform-origin:50% 100%}100%{-webkit-transform:scale(1);transform:scale(1);-webkit-transform-origin:50% 100%;transform-origin:50% 100%}}@keyframes scale-up-bottom{0%{-webkit-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:50% 100%;transform-origin:50% 100%}100%{-webkit-transform:scale(1);transform:scale(1);-webkit-transform-origin:50% 100%;transform-origin:50% 100%}}
</style>

</head>


<body class="hold-transition sidebar-mini layout-boxed layout-fixed bg-dark">
    <div class="wrapper shadow">
        <?php include'top_nav.php'; ?>
        <aside class="main-sidebar bg-white elevation-2 layout-fixed">
            <a href="<?php echo base_url('SuperAdmin/profile'); ?>" class="brand-link d-flex align-items-center" style="background-color: #1A1A1A;">
                <img src="<?php echo base_url(); ?>assets/upload/images/<?=$user['image']?>" alt="AdminLTE Logo" class="brand-image" style="opacity: .8">
                <small class="text-white font-weight-light">Super Admin</small>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item rounded" style="background-color: #E9ECEF;">
                            <a href="<?php echo base_url('SuperAdmin'); ?>" class="nav-link text-dark ">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataProject'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-microchip"></i>
                                <p> Services </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataWorkflow'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-project-diagram"></i>
                                <p> Workflow </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataInformation'); ?>" class="nav-link">
                                <i class=" nav-icon fab fa-pied-piper-square"></i>
                                <p> Seminar </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataUser'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-users"></i>
                                <p> Users </p>
                            </a>
                        </li>
                        <li class="nav-header text-black  pt-2">EXTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user nav-icon"></i>
                                <p>
                                    Client
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#E9ECEF;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataOrder'); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-book"></i>
                                        <p> Order
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataChatt'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-comments"></i>
                                        <p> Chat
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/finances'); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-file-invoice-dollar"></i>
                                        <p> Finance
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataCompany'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-building"></i>
                                        <p> Company </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataRecommendation'); ?>" class="nav-link">
                                        <i class=" nav-icon fa fa-record-vinyl"></i>
                                        <p> Service Recommendation </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataFeedback'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-envelope"></i>
                                        <p> Feedback </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                       <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-clock nav-icon"></i>
                                <p>
                                    Guest
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#E9ECEF;">
                                
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/guestTHC'); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-book-medical"></i>
                                        <p> Tax Health Check
                                        </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">INTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-friends nav-icon"></i>
                                <p>
                                    Employee
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#E9ECEF;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/dataEmployee'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-user"></i>
                                        <p> Data Employee </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/specialTask'); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-book-reader"></i>
                                        <p> Special Task </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('SuperAdmin/training'); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-chalkboard-teacher"></i>
                                        <p> Training</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">OTHER</li>
                        <?php include 'navbar_comingsoon.php'; ?>
                        <li class="nav-item">
                            <a href="<?php echo base_url('SuperAdmin/dataHistory'); ?>" class="nav-link">
                                <i class="nav-icon fa fa-history"></i>
                                <p> History </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="content-wrapper bg-white">
            <section class="content">
                <div class="container pt-3">
                    <div class="main-body">
                        <nav aria-label="breadcrumb" class="main-breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active" aria-current="page">Home</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <div class="container">
                    <div class="main-body">
                        <div class="row rounded scale-up-bottom" style="background: url(<?php echo base_url(); ?>assets/image/background/bgDashboardE.jpg); background-position:center center; background-size:cover; box-shadow:inset 0 0 0 2000px rgba(0, 0, 0, 0.3);">
                            <div class="col-md-7"></div>
                            <div class="col-md-5">
                                <h2 class=" display-4 text-bold text-white">BATS <br> INTEGRATION <br> SYSTEM</h2>
                                <h5 class="text-white text-justify">&nbsp;&nbsp;&nbsp;&nbsp;This application was developed to make it easier for us to see the workflow and be able to see the progress of the project. In addition, it is hoped that us can easily get information related to taxes that is updated by the BATS Consulting company.</h5>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-3">
                        <div class="col-md-4 scale-up-bottom">
                            <div class="card">
                                <div class="card-header d-flex justify-content-center">
                                    <p class="card-title">All Order</p>
                                </div>
                                <div class="card-body">
                                    <div class="progress-group">
                                        All
                                        <span class="float-right"><?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-success" style="width: 
                                            <?php
                                            if ($orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo $orderAll* 100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-group">
                                        On Progress
                                        <span class="float-right"><b><?=$orderDo?></b>/<?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-primary" style="width: 
                                            <?php
                                            if ($orderDo == 0 && $orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo ($orderDo / $orderAll) * 100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-group">
                                        <span class="progress-text">Done</span>
                                        <span class="float-right"><b><?=$orderDone?></b>/<?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-success" style="width: 
                                            <?php
                                            if ($orderDone == 0 && $orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo $orderDone / $orderAll *100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-group">
                                        Cancel
                                        <span class="float-right"><b><?=$orderCancel?></b>/<?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-primary" style="width: 
                                            <?php
                                            if ($orderCancel == 0 && $orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo $orderCancel / $orderAll *100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 scale-up-bottom">
                            <div class="card">
                                <div class="card-header">
                                    <div class="card-title">
                                        Daily Report Today
                                    </div>
                                    <div class="text-right"><?= date('l, j F Y') ?></div>
                                </div>
                                <div class="card-body table-responsive">
                                    <table class="table table-light table-striped table-hover">
                                        <thead>
                                            <th>
                                                <tr>
                                                    <td>No.</td>
                                                    <td>Employee</td>
                                                    <td>Time</td>
                                                </tr>
                                            </th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            $names = [];
                                            foreach ($reportToday as $key) {
                                                if (in_array($key['employee_id'],$names)) {
                                                    continue;
                                                } else{
                                                    ?>
                                                    <tr>
                                                        <td><?= $no ?></td>
                                                        <td><?=$key['employee_name']?></td>
                                                        <td><?= date('h:i a', strtotime($key['create_date']))?></td>
                                                    </tr>
                                                    <?php
                                                    array_push($names,$key['employee_id']);
                                                }
                                                $no++;
                                            }
                                           ?>
                                            
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-6 scale-up-bottom">
                            <div class="small-box">
                                <div class="inner">
                                    <h3><?= $totalClient; ?></h3>
                                    <p>Client</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users text-dark"></i>
                                </div>
                                <a href="<?php echo base_url('SuperAdmin/dataClient'); ?>" class="small-box-footer bg-dark">More<i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 scale-up-bottom">
                            <div class="small-box">
                                <div class="inner">
                                    <h3><?= $totalAdmin; ?></h3>
                                    <p>Admin</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-user-ninja text-dark"></i>
                                </div>
                                <a href="<?php echo base_url('SuperAdmin/dataAdmin'); ?>" class="small-box-footer bg-dark">More<i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 scale-up-bottom">
                            <div class="small-box">
                                <div class="inner">
                                    <h3><?= $totalFeedback; ?></h3>
                                    <p>Feedback</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-comment text-dark"></i>
                                </div>
                                <a href="<?php echo base_url('SuperAdmin/dataFeedback'); ?>" class="small-box-footer bg-dark">More<i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 scale-up-bottom">
                            <div class="small-box">
                                <div class="inner">
                                    <h3><?= $totalCompany; ?></h3>
                                    <p>Company</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-building text-dark"></i>
                                </div>
                                <a href="<?php echo base_url('SuperAdmin/dataCompany'); ?>" class="small-box-footer bg-dark">More<i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 scale-up-bottom">
                            <div class="small-box">
                                <div class="inner">
                                    <h3><?= $totalProject; ?></h3>
                                    <p>Project</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-book-open text-dark"></i>
                                </div>
                                <a href="<?php echo base_url('SuperAdmin/dataProject'); ?>" class="small-box-footer bg-dark">More<i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6 scale-up-bottom">
                            <div class="small-box">
                                <div class="inner">
                                    <h3><?= $totalWorkflow; ?></h3>
                                    <p>Workflow</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-project-diagram text-dark"></i>
                                </div>
                                <a href="<?php echo base_url('SuperAdmin/dataWorkflow'); ?>" class="small-box-footer bg-dark">More<i class="fas fa-arrow-circle-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <h4 class="mb-3 mt-5">Seminar Information</h4>
                    <?php
                             if (empty($news)) {
                                echo '<h5 class="text-center">Information not yet available</h5>';
                            }
                            ?>
                    <div class="row">
                        <?php
                                $no = 1;
                                foreach ($news as $row) {
                                    ?>
                        <div class="col-md-12 col-lg-6 col-xl-4 mt-2 scale-up-bottom">
                            <a href="<?= base_url('SuperAdmin/detailInformation/'.$row['id'])?>" class="card mb-2 text-dark">
                                <img class="card-img-top rounded" src="<?php echo base_url(); ?>assets/upload/images/news/<?=$row['image']?>" alt="Dist Photo 3" style="height: 150px;object-fit: cover; overflow: hidden; ">
                                <div class="card-body">
                                    <h5 class="card-title"><?=$row['title']?></h5>
                                </div>
                                <div class="card-footer">
                                    <small><?= date("F j, Y h:m a", strtotime( $row['create_date']))?></small>
                                </div>
                            </a>
                        </div>
                        <?php
                                    $no++;
                                }
                                ?>
                    </div>
                    
                </div>
            </section>
        </div> <?php include 'footer.php';?>
</body>

</html>