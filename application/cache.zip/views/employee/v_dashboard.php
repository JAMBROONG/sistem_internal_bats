<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Employee Dashboard</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />
    <?php 
include 'header.php';
?>
</head>

<body class="hold-transition bg-info sidebar-mini    layout-fixed">
    <div class="wrapper shadow bg-white">
    <?php include'top_nav.php'; ?>
        <aside class="main-sidebar bg-white elevation-2 layout-fixed">
            <a href="<?php echo base_url('Employee/profile'); ?>" class="brand-link d-flex align-items-center" style="background-color: #1A1A1A;">
                <img src="<?php echo base_url(); ?>assets/upload/images/employee/<?=$user['image']?>" alt="AdminLTE Logo" class="brand-image" style="opacity: .8">
                <small class="text-white font-weight-light">Employee</small>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee'); ?>" class="nav-link bg-info">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataProject/'. md5('ko')) ?>" class="nav-link">
                                <i class="nav-icon fas fa-microchip"></i>
                                <p> Services </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataWorkflow/'. md5('kow')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-project-diagram"></i>
                                <p> Workflow </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataInformation/'. md5('kddo')); ?>" class="nav-link">
                                <i class=" nav-icon fab fa-pied-piper-square"></i>
                                <p> Seminar </p>
                            </a>
                        </li>
                        <li class="nav-header text-black  pt-2">EXTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user nav-icon"></i>
                                <p>
                                    Client
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color: #eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/order/'. md5('cumaiseng')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-cogs"></i>
                                        <p>My Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/report/'. md5('paanci')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-edit"></i>
                                        <p>Report to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/review/'. md5('review')) ?>" class="nav-link">
                                        <i class="nav-icon fa fa-comment-medical"></i>
                                        <p>Review to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/feedback'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-envelope"></i>
                                        <p>Feedback from Client</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">INTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-friends nav-icon"></i>
                                <p>
                                    Me
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/dailyReport/'. md5('initipuan'));?>" target="blank"class="nav-link">
                                        <i class="nav-icon far fa-calendar-check"></i>
                                        <p> Daily Report </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/specialTask/'. md5('initipuandd')); ?>" target="blank" class="nav-link">
                                        <i class="nav-icon fa fa-book-reader"></i>
                                        <p> Special Task </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/training/'. md5('initipuandd')) ?>" class="nav-link">
                                        <i class="nav-icon fa fa-chalkboard-teacher"></i>
                                        <p> Training </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">OTHER</li>
                        <?php include 'navbar_comingsoon.php'; ?>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/history'); ?>" class="nav-link">
                                <i class="nav-icon fa fa-history"></i>
                                <p> History </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <div class="content-wrapper bg-white pt-3" style="padding-left: 10%;padding-right: 10%;">
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <img src="https://picsum.photos/400/200" alt="" class="rounded">
                            </div>
                        </div>
                        <div class="col-md-6 d-flex align-items-center justify-content-center">
                            <div class="text-center">
                                <h6 for="">Hai <?=$user['employee_name']?></h6>
                                <br>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="background: url(<?php echo base_url(); ?>assets/image/background/bgDashboardE.jpg); background-position:center center; background-size:cover; box-shadow:inset 0 0 0 2000px rgba(0, 0, 0, 0.3);">
                        <div class="card-body">
                            <div class="row rounded">
                                <div class="col-md-7"></div>
                                <div class="col-md-5">
                                    <h1 class=" display-4 text-bold text-white">BATS <br> INTEGRATION <br> SYSTEM</h1>
                                    <h4 class="text-white text-justify">&nbsp;&nbsp;&nbsp;&nbsp;This application was developed to make it easier for us to see the workflow and be able to see the progress of the project. In addition, it is hoped that us can easily get information related to taxes that is updated by the BATS Consulting company.</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card card-danger">
                                <div class="card-header d-flex justify-content-center">
                                    <p class="card-title">Your Order</p>
                                </div>
                                <div class="card-body">
                                    <div class="progress-group">
                                        On Progress
                                        <span class="float-right"><b><?=$orderDo?></b>/<?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-primary" style="width: 
                                            <?php
                                            if ($orderDo == 0 && $orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo $orderDo / $orderAll *100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-group">
                                        <span class="progress-text">Done</span>
                                        <span class="float-right"><b><?=$orderDone?></b>/<?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-success" style="width: 
                                            <?php
                                            if ($orderDone == 0 && $orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo $orderDone / $orderAll *100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progress-group">
                                        Cancel
                                        <span class="float-right"><b><?=$orderCancel?></b>/<?=$orderAll?></span>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar bg-primary" style="width: 
                                            <?php
                                            if ($orderCancel == 0 && $orderAll == 0) {
                                                echo 0;
                                            } else{
                                                echo $orderCancel / $orderAll *100;
                                                }
                                                ?>%">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card card-danger">
                                <div class="card-header">
                                    <div class="card-title">Approaching deadline</div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <?php
                                    $no = 1;
                                    foreach ($deadline as $row) {
                                        $ending =  date("Y-m-d", strtotime($row['estimasi']));
                                        $todayDateObj = new \DateTime(date('Y-m-d'));
                                        $foundedDateObj = new \DateTime(date("Y-m-d", strtotime($row['estimasi'])));
                                        $interval = $todayDateObj->diff($foundedDateObj);
                                        $interval = $interval->format('%r%a') . "\n\n";
                                        if ($interval  < 1) {
                                            ?>
                                        <div class="col-md-4">
                                            <div class="card card-outline card-warning">
                                                <div class="card-body">
                                                    <p class="card-text"><?=$row['subStep']?></p>
                                                    <p class="card-text">Estimasi:
                                                        <?php
                                                        $ending =  date("Y-m-d", strtotime($row['estimasi']));
                                                        $todayDateObj = new \DateTime(date('Y-m-d'));
                                                        $foundedDateObj = new \DateTime(date("Y-m-d", strtotime($row['estimasi'])));
                                                        $interval = $todayDateObj->diff($foundedDateObj);
                                                        $interval = $interval->format('%r%a') . "\n\n";
                                                        echo date("F j, Y", strtotime($row['estimasi']));
                                                        if ($interval > 0 ) {
                                                            ?>
                                                        <small class="text-success">(<?=$interval?>more days)</small>
                                                        <?php
                                                        }
                                                    else{
                                                        ?>
                                                        <small class="text-danger">(<?=$interval?>days ago)</small>
                                                        <?php
                                                    }
                                                        ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        }
                                        if ($interval < 1) {
                                            ?>
                                        <script>
                                            setTimeout(function() {
                                                $('#myModal').modal('show');
                                            }, 0);
                                        </script>
                                        <div class="modal fade" id="myModal">
                                            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                                <div class="modal-content bg-yellow">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">WARNING!!</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body d-flex justify-content-center align-items-center pb-0">
                                                        <p>Please, you have some work to finish quickly!!</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn button-close btn-danger" data-dismiss="modal">Ok</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        }
                                        $no++;
                                    }
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <a href="<?php echo base_url('Employee/history'); ?>" class="info-box link-black">
                            <span class="info-box-icon elevation-1" style="background-color: #E15350; color:white;"><i class="fas fa-history"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">History</span>
                                <span class="info-box-number"><?= $history; ?>
                                </span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo base_url('Employee/order'); ?>" class="info-box link-black mb-3">
                            <span class="info-box-icon elevation-1" style="background-color: #E15350; color:white;"><i class="fas fa-shopping-cart"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Order</span>
                                <span class="info-box-number"><?= $order; ?></span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo base_url('Employee/report'); ?>" class="info-box link-black mb-3">
                            <span class="info-box-icon elevation-1" style="background-color: #E15350; color:white;"><i class="fas fa-edit"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Report</span>
                                <span class="info-box-number"><?= $report; ?></span>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo base_url('Employee/feedback'); ?>" class="info-box link-black mb-3">
                            <span class="info-box-icon elevation-1" style="background-color: #E15350; color:white;"><i class="fas fa-envelope"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Feedback</span>
                                <span class="info-box-number"><?= $feedback; ?></span>
                            </div>
                        </a>
                    </div>
                </div>
            </section>
        </div> <?php include 'footer.php';?>
</body>

</html>