<section id="why-us" class="why-us">
    <div class="container">
        <div class="row">
            <div class="col-lg-4" data-aos="fade-up">
                <div class="box">
                    <span>01</span>
                    <h4>Knowledge</h4>
                    <p class="justify">Para Karyawan yang dilatih diharapkan mendapatkan Ilmu yang
                        cukup untuk dapat mengerjakan tugasnya yang akan diberikan.</p>
                </div>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="150">
                <div class="box">
                    <span>02</span>
                    <h4>Skill</h4>
                    <p class="justify">Para Karyawan yang dilatih diharapkan dapat dan mampu
                        melakukan tugas saat ditempatkan pada proses yang telah ditentukan.</p>
                </div>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
                <div class="box">
                    <span>03</span>
                    <h4>
                        Attitude</h4>
                    <p class="justify">Setelah melakukan pelatihan diharapkan para karyawan baru
                        dapat memiliki minat dan kesadaran atas pekerjaan yang akan dilakukannya.</p>
                </div>
            </div>
        </div>
    </div>
</section>