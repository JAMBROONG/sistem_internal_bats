<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Review</title>
    <script src="<?php echo base_url(); ?>assets/md5/js/md5.min.js"></script>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" /> <?php include 'header.php';
  ?>
</head>

<body class="hold-transition bg-info sidebar-mini    layout-fixed">
    <div class="wrapper shadow bg-white">
        <?php include'top_nav.php'; ?>
        <aside class="main-sidebar bg-white elevation-2 layout-fixed">
            <a href="<?php echo base_url('Employee/profile'); ?>" class="brand-link d-flex align-items-center" style="background-color: #1A1A1A;">
                <img src="<?php echo base_url(); ?>assets/upload/images/employee/<?=$user['image']?>" alt="AdminLTE Logo" class="brand-image" style="opacity: .8">
                <small class="text-white font-weight-light">Employee</small>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataProject/'. md5('ko')) ?>" class="nav-link">
                                <i class="nav-icon fas fa-microchip"></i>
                                <p> Services </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataWorkflow/'. md5('kow')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-project-diagram"></i>
                                <p> Workflow </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataInformation/'. md5('kddo')); ?>" class="nav-link">
                                <i class=" nav-icon fab fa-pied-piper-square"></i>
                                <p> Seminar </p>
                            </a>
                        </li>
                        <li class="nav-header text-black  pt-2">EXTERNAL</li>
                        <li class="nav-item menu-open">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user nav-icon"></i>
                                <p>
                                    Client
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color: #eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/order/'. md5('cumaiseng')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-cogs"></i>
                                        <p>My Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/report/'. md5('paanci')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-edit"></i>
                                        <p>Report to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/review/'. md5('review')) ?>" class="nav-link bg-info">
                                        <i class="nav-icon fa fa-comment-medical"></i>
                                        <p>Review to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/feedback'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-envelope"></i>
                                        <p>Feedback from Client</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">INTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-friends nav-icon"></i>
                                <p>
                                    Me
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/dailyReport/'. md5('initipuan'));?>" target="blank" class="nav-link">
                                        <i class="nav-icon far fa-calendar-check"></i>
                                        <p> Daily Report </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/specialTask/'. md5('initipuandd')); ?>" target="blank" class="nav-link">
                                        <i class="nav-icon fa fa-book-reader"></i>
                                        <p> Special Task </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/training/'. md5('initipuansdd')) ?>" class="nav-link">
                                        <i class="nav-icon fa fa-chalkboard-teacher"></i>
                                        <p> Training </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">OTHER</li>
                        <?php include 'navbar_comingsoon.php';?>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/history'); ?>" class="nav-link">
                                <i class="nav-icon fa fa-history"></i>
                                <p> History </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
         <div class="content-wrapper bg-white" style="padding-left: 10%;padding-right: 10%;">
            <section class="content pt-3">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header bg-info">
                            <h5 class="card-title">Order for You Now</h5>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped dataTable dtr-inline" role="grid" aria-describedby="example1_info">
                                <thead class="thead-inverse">
                                    <tr>
                                        <th>No. </th>
                                        <th>Service</th>
                                        <th>Company</th>
                                        <th>Partner</th>
                                        <th>Manager</th>
                                        <th>Supervisor</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no =1;
                                    foreach ($orderDo as $row) {
                                        ?>
                                    <tr>
                                        <td scope="row"><?= $no; ?></td>
                                        <td><?= $row['service_name']; ?></td>
                                        <td><?= $row['company']; ?></td>
                                        <td><?= $row['partner']; ?></td>
                                        <td><?= $row['manager']; ?></td>
                                        <td><?= $row['supervisor']; ?></td>
                                        <td><?= date("F j, Y, g:i a", strtotime($row['create_date'])); ?></td>
                                        <td>
                                            <a href="<?=base_url('Employee/reportReview/'.$row['id'])?>" class="btn btn-sm btn-success"><i class="fas fa-comment-medical mr-2"></i> view review</a>
                                        </td>
                                    </tr>
                                    <?php
                                        $no++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header bg-info">
                            <h5 class="card-title">Order for You Done</h5>
                        </div>
                        <div class="card-body">
                            <table id="example2" class="table table-bordered table-striped dataTable dtr-inline" role="grid" aria-describedby="example2_info">
                                <thead class="thead-inverse">
                                    <tr>
                                        <th>No. </th>
                                        <th>Service</th>
                                        <th>Company</th>
                                        <th>Partner</th>
                                        <th>Manager</th>
                                        <th>Supervisor</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no =1;
                                    foreach ($orderDone as $row) {
                                        ?>
                                    <tr>
                                        <td scope="row"><?= $no; ?></td>
                                        <td><?= $row['service_name']; ?></td>
                                        <td><?= $row['company']; ?></td>
                                        <td><?= $row['partner']; ?></td>
                                        <td><?= $row['manager']; ?></td>
                                        <td><?= $row['supervisor']; ?></td>
                                        <td><?= date("F j, Y, g:i a", strtotime($row['create_date'])); ?></td>
                                        <td>
                                            <a href="<?=base_url('Employee/reportReview/'.$row['id'])?>" class="btn btn-sm btn-success"><i class="fa fa-book mr-2"></i> view review</a>
                                        </td>
                                    </tr>
                                    <?php
                                        $no++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    <?php 
include 'footer.php';

?>
</body>

</html>