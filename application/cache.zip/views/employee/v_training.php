<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Training</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" /> 
<?php 
include 'header.php';
?>
<style>
.card {
  text-align:center;
 box-shadow: 0px 0px 0px grey; 
 -webkit-transition:  box-shadow .6s ease-out;
 box-shadow: .8px .9px 3px grey;

}
.card:hover{ 
     box-shadow: 1px 8px 20px grey;
    -webkit-transition:  box-shadow .5s ease-in;
  }
 
</style>
</head>  

<body class="hold-transition bg-info sidebar-mini  layout-fixed">
    <div class="wrapper bg-white">
        <?php include'top_nav.php'; ?>
        <aside class="main-sidebar bg-white elevation-2 layout-fixed">
            <a href="<?php echo base_url('Employee/profile'); ?>" class="brand-link d-flex align-items-center" style="background-color: #1A1A1A;">
                <img src="<?php echo base_url(); ?>assets/upload/images/employee/<?=$user['image']?>" alt="AdminLTE Logo" class="brand-image" style="opacity: .8">
                <small class="text-white font-weight-light">Employee</small>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataProject/'. md5('ko')) ?>" class="nav-link">
                                <i class="nav-icon fas fa-microchip"></i>
                                <p> Services </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataWorkflow/'. md5('kow')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-project-diagram"></i>
                                <p> Workflow </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataInformation/'. md5('kddo')); ?>" class="nav-link">
                                <i class=" nav-icon fab fa-pied-piper-square"></i>
                                <p> Seminar </p>
                            </a>
                        </li>
                        <li class="nav-header text-black  pt-2">EXTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user nav-icon"></i>
                                <p>
                                    Client
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color: #eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/order/'. md5('cumaiseng')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-cogs"></i>
                                        <p>My Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/report/'. md5('paanci')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-edit"></i>
                                        <p>Report to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/review/'. md5('review')) ?>" class="nav-link">
                                        <i class="nav-icon fa fa-comment-medical"></i>
                                        <p>Review to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/feedback'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-envelope"></i>
                                        <p>Feedback from Client</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">INTERNAL</li>
                        <li class="nav-item menu-open">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-friends nav-icon"></i>
                                <p>
                                    Me
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/dailyReport/'. md5('initipuan'));?>" target="blank" class="nav-link">
                                        <i class="nav-icon far fa-calendar-check"></i>
                                        <p> Daily Report </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/specialTask/'. md5('initipuandd')); ?>" target="blank" class="nav-link">
                                        <i class="nav-icon fa fa-book-reader"></i>
                                        <p> Special Task </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/training/'. md5('initipuansdd')) ?>" class="nav-link bg-info">
                                        <i class="nav-icon fa fa-chalkboard-teacher"></i>
                                        <p> Training </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">OTHER</li>
                        <?php include 'navbar_comingsoon.php';?>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/history'); ?>" class="nav-link">
                                <i class="nav-icon fa fa-history"></i>
                                <p> History </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="content-wrapper bg-white" style="padding-left: 10%;padding-right: 10%;">
            <section class="content">
                <div class="container-fluid  pt-3">
                    <div class="jumbotron bg-white">
                        <h1 class="display-4">Training</h1>
                        <p class="lead">Selamat datang di Traing BATS</p>
                        <hr class="my-4">
                        <p>Kami menyediakan berbagai macam materi baik berbentuk file untuk dibaca ataupun video agar bisa didengar dan dilihat. Guna mampu mendorong pengguna untuk bisa meng <i>upgrade</i> diri mereka. Materi bisa kalian akses dibawah ini, SEMANGAT!!!</p>
                    </div>
                    <div class="row">
                        <?php
                        foreach ($data_category as $key) {
                            ?>
                            <div class="col-md-4">
                                <a class="card bg-info disabled p-3" href="<?=base_url('Employee/dtraining/'.$key['id'].'/'.md5("kepo"))?>" target="blank">
                                    <div class="card-body">
                                        <h5 class="card-title" ><?= $key['content_training_category'] ?></h5>
                                    </div>
                                </a>
                            </div>
                            <?php
                        }
                        ?>
                        <div class="col">
                        </div>
                    </div>
                    <hr>
                    <p class="text-center p-4">Fitur yang akan segera dikembangkan</p>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-text-width"></i>
                                    Taraining bertarget
                                </h3>
                            </div>
                            <div class="card-body">
                                <blockquote class="quote-secondary">
                                <p>Kita diharuskan melakukan training dalam jumlah dan diwaktu tertentu. Guna meningkatkan kualitas kemampuan diri.</p>
                                <small>status: <cite title="Source Title" class="text-warning">masih perencanaan</cite></small>
                                </blockquote>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-text-width"></i>
                                    Ujian
                                </h3>
                            </div>
                            <div class="card-body clearfix">
                                <blockquote class="quote-secondary">
                                <p>Akan diadakan ujian diwaktu tertentu, guna melihat perkembangan diri kita setelah dan sebelum melakukan training.</p>
                                <small>status: <cite title="Source Title" class="text-warning">masih perencanaan</cite></small>
                                </blockquote>
                            </div>
                            </div>
                        </div>
                        </div>
                </div>
            </section>
        </div> 
    <?php include 'footer.php';?>
</body>

</html>