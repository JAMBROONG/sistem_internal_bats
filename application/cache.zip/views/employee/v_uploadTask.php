<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Review</title>
    <script src="<?php echo base_url(); ?>assets/md5/js/md5.min.js"></script>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />
    
    <?php include'header.php' ?>
    <style>
        .file {
            visibility: hidden;
            position: absolute;
        }
    </style>
</head>

<body class="hold-transition bg-info sidebar-mini    layout-fixed">
    <div class="wrapper shadow bg-white">
        <?php include'top_nav.php'; ?>
        <aside class="main-sidebar bg-white elevation-2 layout-fixed">
            <a href="<?php echo base_url('Employee/profile'); ?>" class="brand-link d-flex align-items-center" style="background-color: #1A1A1A;">
                <img src="<?php echo base_url(); ?>assets/upload/images/employee/<?=$user['image']?>" alt="AdminLTE Logo" class="brand-image" style="opacity: .8">
                <small class="text-white font-weight-light">Employee</small>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee'); ?>" class="nav-link">
                                <i class="nav-icon fas fa-tachometer-alt"></i>
                                <p> Dashboard
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataProject/'. md5('ko')) ?>" class="nav-link">
                                <i class="nav-icon fas fa-microchip"></i>
                                <p> Services </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataWorkflow/'. md5('kow')); ?>" class="nav-link">
                                <i class="nav-icon fas fa-project-diagram"></i>
                                <p> Workflow </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/dataInformation/'. md5('kddo')); ?>" class="nav-link">
                                <i class=" nav-icon fab fa-pied-piper-square"></i>
                                <p> Seminar </p>
                            </a>
                        </li>
                        <li class="nav-header text-black  pt-2">EXTERNAL</li>
                        <li class="nav-item">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user nav-icon"></i>
                                <p>
                                    Client
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color: #eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/order/'. md5('cumaiseng')); ?>" class="nav-link">
                                        <i class="nav-icon fa fa-cogs"></i>
                                        <p>My Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/report/'. md5('paanci')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-edit"></i>
                                        <p>Report to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/review/'. md5('review')) ?>" class="nav-link">
                                        <i class="nav-icon fa fa-comment-medical"></i>
                                        <p>Review to Order</p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/feedback'); ?>" class="nav-link">
                                        <i class="nav-icon far fa-envelope"></i>
                                        <p>Feedback from Client</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">INTERNAL</li>
                        <li class="nav-item menu-open">
                            <a href="#" class="nav-link ">
                                <i class="fa fa-user-friends nav-icon"></i>
                                <p>
                                    Me
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview rounded" style="display: none; background-color:#eeeef0;">
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/dailyReport/'. md5('initipuan'));?>" target="blank" class="nav-link">
                                        <i class="nav-icon far fa-calendar-check"></i>
                                        <p> Daily Report </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/specialTask/'. md5('initipuandd')); ?>" target="blank" class="nav-link bg-info">
                                        <i class="nav-icon fa fa-book-reader"></i>
                                        <p> Special Task </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo base_url('Employee/training/'. md5('initipuansdd')) ?>" class="nav-link">
                                        <i class="nav-icon fa fa-chalkboard-teacher"></i>
                                        <p> Training </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-header text-black  pt-2">OTHER</li>
                        <?php include 'navbar_comingsoon.php';?>
                        <li class="nav-item">
                            <a href="<?php echo base_url('Employee/history'); ?>" class="nav-link">
                                <i class="nav-icon fa fa-history"></i>
                                <p> History </p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
         <div class="content-wrapper bg-white" style="padding-left: 10%;padding-right: 10%;">
            <section class="content pt-3">
                <div class="container-fluid">
                    <div class="row d-flex justify-content-center">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-info">
                                    Upload Task
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="">Task</label>
                                            <input type="text" name="" value="<?=$dataTask['task']?>" class="form-control" readonly id="">
                                            <label for="">Estimasi</label>
                                            <input type="text" name="" value="<?php echo date("F j, Y", strtotime($dataTask['estimasi']));?>" class="form-control" readonly id="">
                                            <?php
                                                    $todayDateObj = new \DateTime(date('Y-m-d'));
                                                    $foundedDateObj = new \DateTime(date("Y-m-d", strtotime($dataTask['estimasi'])));
                                                    $interval = $todayDateObj->diff($foundedDateObj);
                                                    $interval = $interval->format('%r%a') . "\n\n";
                                                    if ($interval >= 0 ) {
                                                        echo '<p class="text-success">('.$interval.' more days)</p>';
                                                    } else
                                                    if ($interval == 0) {
                                                        echo '<p class="text-success">Today</p>';
                                                    }
                                                else{
                                                    echo '<p class="text-danger">('.$interval .'days ago)</p>';
                                                        
                                                }
                                                    ?>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="">Upload File</label> <small> (max size 2Mb)</small>
                                            <form action="<?= site_url('Employee/processUploadTask') ?>" method="post" class="row" enctype="multipart/form-data">
                                                <div class="input-group">
                                                    <input type="file" name="image" id="file2" class="file">
                                                    <p>Format: <br><small class=" text-danger">pdf / jpg / png / jpeg / xlsx / doc / odt</small></p>
                                                    <div class="input-group">
                                                        <input type="hidden" name="task_id" value="<?=$dataTask['id']?>">
                                                        <input required type="text" class="form-control" disabled placeholder="Upload Task" id="file">
                                                        <div class="input-group-append">
                                                            <button type="button" id="pilih_gambar" class="browse btn btn-dark">Select File</button>
                                                        </div>
                                                    </div>
                                                    <p class="text-danger" id="message"></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Description</label>
                                                    <textarea name="description" class="textarea" id="" placeholder="ex: Filenya saya kirim WhatsApp ya pak" cols="30" rows="20">
                                                    <?=$dataTask['description']?></textarea>
                                                </div>
                                                <a href="<?= base_url('Employee/specialTask') ?>" class="btn btn-sm btn-danger"><i class="fa fa-arrow-left mr-2"></i>back</a>
                                                <button class="btn btn-sm btn-success ml-2" name="submit" type="submit"><i class="fa fa-save mr-2"></i> save</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <?php include'footer.php' ?>
    <script>
        function getExtension(filename) {
            var parts = filename.split('.');
            return parts[parts.length - 1];
        }
        function bytesToSize(bytes) {
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']
            if (bytes === 0) return 'n/a'
            const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10)
            if (i === 0) return `${bytes} ${sizes[i]})`
            return `${(bytes / (1024 ** i)).toFixed(1)} ${sizes[i]}`
        }
        document.forms[0].addEventListener('submit', function( evt ) {
            var file = document.getElementById('file2').files[0];
            var msg = document.getElementById('message');
            if(file && file.size < 2485760) {
                var ext = getExtension(file.name);
                switch (ext.toLowerCase()) {
                    case 'jpg':
                    case 'pdf':
                    case 'jpeg':
                    case 'png':
                    case 'xlsx':
                    case 'doc':
                    case 'odt':
                    return true;
                }
                msg.innerHTML = "*format not met, your current format: " + ext;
                evt.preventDefault();
            } else {
                msg.innerHTML = "*file size exceeds the limit, your current size: " + bytesToSize(file.size);
                evt.preventDefault();
            }
        }, false);

        $(document).on("click", "#pilih_gambar", function() {
            var file = $(this).parents().find(".file");
            file.trigger("click");
        });
        $('input[type="file"]').change(function(e) {
            var fileName = e.target.files[0].name;
            $("#file").val(fileName);
            var reader = new FileReader();
            reader.onload = function(e) {
            };
            reader.readAsDataURL(this.files[0]);
        });
    </script>
</body>

</html>