<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daily Report</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/select2/css/select2.min.css">
    <!-- iCheck for checkboxes and radio inputs -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/adminlte.min.css">
<style>
    .select2-results__options li{
        color: black;
    }
    footer{
        display: none;
    }
</style>
<?php $url = base_url('Employee/createTemplateReport'); ?>
<script type="text/javascript">
    function disableButton(btn) {
        document.getElementById(btn.id).disabled = true;
        window.location.href = "<?= $url ?>";
    }
    function disableButton2(btn) {
        $("form.form-once-only").submit(function () {
            $(this).find(':button').prop('disabled', true);
        });
    }
</script>
</head>
</style>

<body class="hold-transition bg-info sidebar-mini  mt-5 bg-info">
    <h3 class="text-center">Daily Report BATS Consulting</h3>
    <p class="text-center mb-5">Jangan lupa mengisi laporan harian yaa, semangat <?= $user['employee_name'] ?>!! :D</p>
    <div class="wrapper shadow rounded bg-white mb-5" style="margin:3em;">
        <section class="content p-2">
            <div class="main-body">
                <nav aria-label="breadcrumb" class="main-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= base_url()?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Daily Report</li>
                    </ol>
                </nav>
            </div>
            <div class="card shadow-none">
                <div class="card-body">
                    <form action="<?= base_url('Employee/dailyReport'); ?>" method="POST">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Find By:</label>
                                    <select name="type" onchange="onklik()" id="type" class="select2 form-control">
                                        <option value="day">Day</option>
                                        <option value="month">Month</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-sm mt-1 btn-success"><i class="fa fa-search mr-1"></i> search</button> <small></small>
                            </div>
                            <div class="col-md-3" id="day">
                                <div class="form-group">
                                    <label>Select date:</label>
                                    <input type="date" name="day" class="form-control" value="<?= date("Y-m-d") ?>" id="" required>
                                </div>
                            </div>
                            <div class="col-md-3" id="month" style="display: none;">
                                <div class="form-group">
                                    <label>Select month:</label>
                                    <input type="month" name="month" class="form-control" value="<?= date("Y-m") ?>" id="" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="callout callout-warning">
                                    <h6>Please Read!!</h6>
                                    <ul>
                                        <li>Pembuatan template <i>daily report</i> hanya dapat dilakukan pada hari yang sama 😁</li>
                                        <li>Background kuning adalah batas minimum <i>daily report</i> kamu yaa, selebihnya itu terserah</li>
                                        <li>Agak lama simpannya, soalnya disimpan kolom satu per satu, sabar :v </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="d-flex justify-content-between mt-3 align-items-md-end">
                        <small><?=$message?></small>
                        <div>
                            <?php
                            if ($date == date('Y-m-d') && empty($dailyReport)) {
                                ?>
                            <a href="" class="btn btn-outline-info btn-sm mr-2" data-toggle="modal" data-target="#getTemplate"> <i class="fab fa-app-store mr-1"></i> get template</a>
                            <div id="getTemplate" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <p>Mengambil template akan membuat schema tabel secara otomatis, fitur ini hanya ada saat anda belum melakukan pengisian data.</p>
                                            <input type="button" id="btn1" value="create template" class="btn btn-sm btn-outline-info"  onclick="disableButton(this)">
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <?php
                            }?>
                        </div>
                    </div>
                        <form method="post" action="<?= base_url('Employee/dailyReport') ?>" class="form-once-only" id="formAll">
                        <input type="hidden" name="date" value="<?=$date?>">
                        <table id="table" class="table table-hover table-inverse table-striped">
                            <thead class="thead-inverse">
                                <tr>
                                    <th>No</th>
                                    <th>Time</th>
                                    <th>Plan</th>
                                    <th>Do</th>
                                    <th>Problem</th>
                                    <th>Solution</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                            $no = 1;
                            foreach ($dailyReport as $key) {
                                if($no > 18){
                                     echo '<tr>' ;
                                }else{
                                    echo '<tr style="background-color: #F8F9D7;">';
                                };
                                    $readonly = "";
                                if ($key['check'] == "yes") {
                                    $readonly = "readonly";
                                }
                                ?>
                                    <input type="hidden" name="report_id<?= $no ?>" value="<?=$key['id']?>">
                                    <td class="text-center"><?= $no ?></td>
                                    <td><?= date("G:i - ", strtotime($key['start_time'])).date("G:i", strtotime($key['end_time'])) ?></td>
                                    <td><input type="text" <?=$readonly?> name="planing<?=$key['id']?>" class="form-control <?php if($key['check'] == "yes"){echo "bg-light";}?>" style="background-color:<?php if(empty($key['planing'])){echo "white";}else{ echo "#5FD068; color : white";}?>" value="<?= $key['planing'] ?>"></td>
                                    <td><input  type="text" <?=$readonly?> name="doing<?=$key['id']?>" class="form-control <?php if($key['check'] == "yes"){echo "bg-light";}?>" value="<?= $key['doing'] ?>" style="background-color:<?php if(empty($key['doing'])){echo "white";}else{ echo "#5FD068; color : white";}?>"></td>
                                    <td><input type="text" <?=$readonly?> name="problem<?=$key['id']?>" class="form-control <?php if($key['check'] == "yes"){echo "bg-light";}?>"  value="<?= $key['problem'] ?>" style="background-color:<?php if(empty($key['problem'])){echo "white";}else{ echo "#5FD068; color : white";}?>"></td>
                                    <td><input type="text" <?=$readonly?> name="solution<?=$key['id']?>" class="form-control <?php if($key['check'] == "yes"){echo "bg-light";}?>"  value="<?= $key['solution'] ?>" style="background-color:<?php if(empty($key['solution'])){echo "white";}else{ echo "#5FD068; color : white";}?>"></td>
                                    <td>
                                        <input name="description<?=$key['id']?>" <?=$readonly?> type="text" class="form-control <?php if($key['check'] == "yes"){echo "bg-light";}?>" value="<?= $key['description'] ?>" style="background-color:<?php if(empty($key['description'])){echo "white";}else{ echo "#5FD068; color : white";}?>">
                                    </td>
                                    <td class="bg-white text-center">
                                        <?php
                                        if ($key['planing']&&$key['doing']) {
                                            echo ( $key['check'] == 'yes') ? '<small class="text-success"> approved</small>' : '<small class="text-warning"> waiting for approval</small>' ; 
                                        } else {
                                            echo '<small class="text-danger">not filled in</small>' ; 
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                $no++;
                            }
                            ?>

                            </tbody>
                        </table>
                            <input type="hidden" name="totalData" value="<?= $no; ?>">
                            <?php
                            if ($type == "day") {?> 
                            <button type="submit" id="btn2" form="formAll" class="btn btn-sm btn-success mt-3" onclick="disableButton2(this)"><i class="fa fa-save mr-2"></i> update report</button>
                            <?php
                            }
                            ?>
                            </form>
                </div>
            </div>
        </section>
    </div>
    <?php include'footer.php' ?>
    <script>
        function onklik() {
            if (document.getElementById("type").value == "month") {
                document.getElementById("month").style.display = "block";
                document.getElementById("day").style.display = "none";
                document.getElementById("day").value = "";
            } else {
                document.getElementById("month").style.display = "none";
                document.getElementById("day").style.display = "block   ";
                document.getElementById("month").value = "";
            }
        }
        $(function() {
            $('.select2').select2()
        });
    </script>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/jszip/jszip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

    <script>
        $(function() {
            $("#table").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "searching": false,
"bPaginate": false,
            });
        });
    </script>
</body>

</html>