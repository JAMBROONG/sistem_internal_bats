<?php
class M_user extends CI_Model{
    public function __construct()
	{
        parent::__construct();
        
	}
	function pilih_semua()
	{
		$sql    = "SELECT * FROM user";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getById($id)
    {
        $sql    = "SELECT * FROM user where id = $id";
		$query  = $this->db->query($sql);
        $rows   = $query-> row_array();
		return $rows;
	}
	public function getByWhere($condition,$id)
    {
        $sql    = "SELECT user.*, company.company FROM user INNER JOIN company ON company.id = user.company_id where $condition = $id";
		$query  = $this->db->query($sql);
        $rows   = $query-> result_array();
		return $rows;
	}

	// ============ PROFILE ============

    public function profile($id)
	{
		$sql = "SELECT user.*, user.image as image_user,company.company,status.status,company.image,
		company.NPWP AS company_NPWP,company.typeBusiness, company.addressOfDomicile,
		company.company_phone,company.businessEntity,company.company_email,c.company AS to_company, c.SKMHHAM, c.deeds_of_establishment, c.deeds_of_revisions,company.website
		FROM user
		JOIN status
		ON user.status_id = status.id
		JOIN company
		ON user.company_id = company.id 
		JOIN company c
		ON user.user_to_company_id = c.id 
		WHERE user.id = $id;
		";
		$query = $this -> db -> query($sql);
		$rows = $query -> row_array();
        return $rows;
	}
	public function person($id)
	{
		$sql = "SELECT pr.* FROM person_responsible pr
		inner join `order` o on o.id = pr.order_id
		WHERE o.id = $id;
		";
		$query = $this -> db -> query($sql);
		$rows = $query -> row_array();
        return $rows;
	}

    // ============ FEEBBACK ============

    function dataFeedback($user_id,$order_id)
	{
		$sql    = "SELECT feedback.*,employee.employee_name,user.name FROM feedback 
		INNER JOIN user ON user.id = feedback.user_id
		INNER JOIN employee ON employee.id = feedback.employee_id
		WHERE feedback.user_id = $user_id  AND feedback.order_id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	function dataFeedback2($id)
	{
		$sql    = "SELECT feedback.*, categoryfeedback.category_feedback, employee.employee_name, user.name FROM feedback inner join categoryfeedback ON categoryfeedback.id = feedback.categoryFeedback_id inner join employee on employee.id = feedback.employee_id inner JOIN user ON user.id = feedback.user_id WHERE categoryfeedback.id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	function dataFeedback3($id)
	{
		$sql    = "SELECT feedback.*, categoryfeedback.category_feedback, user.name FROM feedback inner join categoryfeedback ON categoryfeedback.id = feedback.categoryFeedback_id inner JOIN user ON user.id = feedback.user_id WHERE categoryfeedback.id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	function validatefeedback($id,$id2)
	{
		$sql    = "SELECT * FROM feedback WHERE feedback.user_id = $id and categoryFeedback_id = $id2";
		$query  = $this->db->query($sql);
		return $query->num_rows();
	}
    function detailFeedback($id)
	{
		$sql    = "SELECT feedback.*, employee.employee_name FROM feedback inner join employee on employee.id = feedback.employee_id WHERE feedback.id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	function companyFeedback($order_id)
	{
		$sql    = "SELECT * FROM feedback WHERE order_id = $order_id and categoryFeedback_id = 2";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	function detailFeedback1($id)
	{
		$sql    = "SELECT feedback.*, employee.employee_name,employee.phone as e_phone,employee.address as e_address, employee.position, user.name, user.phone,user.email,user.address FROM feedback inner JOIN employee on employee.id = feedback.employee_id inner JOIN user ON user.id = feedback.user_id WHERE feedback.id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	function detailFeedback2($id)
	{
		$sql    = "SELECT feedback.*, user.name, user.phone,user.email,user.address FROM feedback inner JOIN user ON user.id = feedback.user_id WHERE feedback.id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	public function getCriteria()
	{
		$sql    = "SELECT criteria.*,category_criteria.category_criteria FROM criteria INNER JOIN category_criteria ON criteria.category_id = category_criteria.id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getStaffFromFeedback($order_id)
	{
		$sql    = "SELECT * FROM feedback_criteria WHERE order_id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getLogin($user_id)
	{
		$sql    = "SELECT * FROM history_login INNER JOIN user ON user.id = history_login.user_id WHERE history_login.user_id = $user_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getLoginE($e_id)
	{
		$sql    = "SELECT * FROM history_login_employee hl INNER JOIN user u ON u.id = hl.employee_id WHERE hl.employee_id = $e_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getAction($user_id)
	{
		$sql    = "SELECT * FROM history_action_client INNER JOIN user ON user.id = history_action_client.client_id WHERE history_action_client.client_id = $user_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getActionA($user_id)
	{
		$sql    = "SELECT * FROM history_action_admin INNER JOIN user ON user.id = history_action_admin.admin_id WHERE history_action_admin.admin_id = $user_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	function getReview($report_id)
	{
		$sql    = "SELECT * FROM report_review rr WHERE report_id = $report_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
}