<?php
class M_administrasi extends CI_Model{
	public function __construct()
	{
		parent::__construct();
	}
    function getContract($order_id)
	{
		$sql    = "SELECT ec.* FROM employment_contract ec INNER JOIN `order` o ON o.id = ec.order_id WHERE o.id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	function getInvoice($order_id)
	{
		$sql    = "SELECT i.* FROM invoice i INNER JOIN `order` o ON o.id = i.order_id WHERE o.id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	function getFile($order_id)
	{
		$sql    = "SELECT i.* FROM client_file i INNER JOIN `order` o ON o.id = i.order_id WHERE o.id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
}