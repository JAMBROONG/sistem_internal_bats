<?php
class M_table extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    function getAll($tabel)
    {
        $sql = "SELECT * FROM $tabel";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getById($tabel, $id)
    {
        $sql = "SELECT * FROM `$tabel` where id = $id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getByCon($tabel, $where, $id)
    {
        $sql = "SELECT * FROM `$tabel`  where $where = $id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function totalByCon($tabel, $where, $id)
    {
        $sql = "SELECT * FROM `$tabel`  where $where = $id";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        return $rows;
    }
    public function dataTableWhere($tabel, $kondisi, $id)
    {
        $sql = "SELECT * FROM `$tabel` where $kondisi = $id ";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    public function dataTableWhere2($tabel, $kondisi, $id,$add)
    {
        $sql = "SELECT * FROM `$tabel` where $kondisi = $id '$add'";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    public function totalDataTableWhere($tabel, $kondisi, $id)
    {
        $sql = "SELECT * FROM `$tabel` where $kondisi = $id";
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    public function updateTable($table, $data, $where)
    {
        $this->db->update($table, $data, $where);
    }
    public function createTable($table, $data)
    {
        $this->db->insert($table, $data);
    }
    public function deleteTable($table, $id)
    {
        $this->db->delete($table, ["id" => $id]);
    }
    public function deleteTableCon($table, $con, $id)
    {
        $this->db->delete($table, [$con => $id]);
    }
    
    public function getTotalData($table)
    {
        $sql = "SELECT * FROM $table";
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    public function delete3Param($table,$where,$id,$add)
    {
        $sql =  "DELETE FROM $table WHERE $where = $id '$add'";
        $query = $this->db->query($sql);
    }
    public function totalLogin()
    {
        $sql = "SELECT * FROM history_login hl INNER JOIN user u ON u.id = hl.user_id 
        WHERE u.status_id = 1";
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    public function totalLoginA()
    {
        $sql = "SELECT * FROM history_login hl INNER JOIN user u ON u.id = hl.user_id 
        WHERE u.status_id = 2";
        $query = $this->db->query($sql);
        return $query->num_rows();
    }
    public function activityClient()
    {
        $sql = "SELECT * FROM history_action_client hac INNER JOIN user u ON u.id = hac.client_id 
        WHERE u.status_id = 1";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
    public function createTableOrder($table, $data)
    {
        $this->db->insert($table, $data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }
    function dataOrder($status)
    {
        $sql = "SELECT `order`.*,user.name,user.user_to_company_id, services.service_name,employee.employee_name, statusorder.status,company.image,company.company FROM `order` INNER JOIN services ON `order`.service_id = services.id INNER JOIN user ON user.id = `order`.user_id INNER JOIN employee ON employee.id = `order`.partner_id INNER JOIN statusorder ON statusorder.id = `order`.statusOrder_id INNER JOIN company ON company.id = user.company_id WHERE statusorder.status = $status ";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function dataOrderAll()
    {
        $sql = "SELECT `order`.*,user.name,user.user_to_company_id, services.service_name,employee.employee_name, statusorder.status,company.image,company.company FROM `order` INNER JOIN services ON `order`.service_id = services.id INNER JOIN user ON user.id = `order`.user_id INNER JOIN employee ON employee.id = `order`.partner_id INNER JOIN statusorder ON statusorder.id = `order`.statusOrder_id INNER JOIN company ON company.id = user.company_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function dataOrder2($id_user)
    {
        $sql = " SELECT `order`.*, user.name, services.service_name,company.image,company.company FROM `order` 
					INNER JOIN services ON `order`.service_id = services.id 
					INNER JOIN user ON user.id = `order`.user_id
					INNER JOIN company ON company.id = user.company_id 
					WHERE `order`.user_id = $id_user";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function dataOrder3($id_user)
    {
        $sql = " SELECT `order`.*, services.service_name FROM `order` 
					INNER JOIN services ON `order`.service_id = services.id 
					INNER JOIN user ON user.id = `order`.user_id
					INNER JOIN company ON company.id = user.company_id 
					WHERE `order`.statusOrder_id =1 AND `order`.user_id = $id_user";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function orderId($id)
    {
        $sql = "SELECT `order`.*,services.service_name,services.description FROM `order` inner join services on `order`.service_id = services.id  where user_id = $id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    public function getOrder($id)
    {
        $sql = "SELECT `order`.*,services.service_name,services.description FROM `order` inner join services on `order`.service_id = services.id  where `order`.id = $id ";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getDataOrder($order_id)
    {
        $sql = "SELECT o.*, 
		u.name, u.address AS client_address, u.phone AS client_phone,u.position AS client_position,u.email,
		c.company,c.image AS company_image,
		services.service_name, services.id AS service_id, 
		p.employee_name AS partner_name, p.image AS partner_image,  p.address AS partner_address, p.phone AS partner_phone, p.id AS partner_id,
		m.employee_name AS manager_name, m.image AS manager_image, m.phone AS manager_phone, m.id AS manager_id,
		s.employee_name AS supervisor_name, s.image AS supervisor_image, s.phone AS supervisor_phone, s.id AS supervisor_id
		FROM `order` o
		JOIN user u ON u.id = o.user_id
		JOIN company c ON c.id = u.company_id
		JOIN employee p ON p.id = o.partner_id
		JOIN employee m ON m.id = o.manager_id
		JOIN employee s ON s.id = o.supervisor_id
		JOIN services ON services.id = o.service_id WHERE o.id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getAllDataOrder($order_id)
    {
        $sql = "SELECT o.*, 
		u.name, u.address AS client_address, u.phone AS client_phone,u.position AS client_position,u.email,
		c.company,c.image AS company_image,
		services.service_name, services.id AS service_id, 
		p.employee_name AS partner_name, p.image AS partner_image,  p.address AS partner_address, p.phone AS partner_phone, p.id AS partner_id,
		m.employee_name AS manager_name, m.image AS manager_image, m.phone AS manager_phone, m.id AS manager_id,
		s.employee_name AS supervisor_name, s.image AS supervisor_image, s.phone AS supervisor_phone, s.id AS supervisor_id
		FROM `order` o
		JOIN user u ON u.id = o.user_id
		JOIN company c ON c.id = u.company_id
		JOIN employee p ON p.id = o.partner_id
		JOIN employee m ON m.id = o.manager_id
		JOIN employee s ON s.id = o.supervisor_id
		JOIN services ON services.id = o.service_id WHERE o.id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getDataStaff($order_id)
    {
        $sql = "SELECT employee.employee_name,employee.id AS id_employee, employee.phone, employee.image from order_staff JOIN employee ON order_staff.employee_id = employee.id WHERE order_staff.order_id=$order_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    // ============ LETTER ============

    public function letter($id)
    {
        $sql = "SELECT data.*, detaildata.data from data inner join detaildata on data.data_id = detaildata.id where data.order_id =$id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function percenLetter($order_id, $status)
    {
        $sql = "SELECT data.*, detaildata.data from data inner join detaildata on data.data_id = detaildata.id where data.order_id =$order_id and data.status = '$status'";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    // ============ CHATT ============

    function chatt($id_order)
    {
        $sql = "SELECT * FROM chatt where order_id = $id_order";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function dataChatt($id_order)
    {
        $sql = "SELECT chatt.*,user.name, company.image FROM chatt INNER JOIN user ON chatt.user_id = user.id INNER JOIN company ON company.id = user.company_id where order_id = $id_order ORDER BY chatt.create_date";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function dataOrderChatt()
    {
        $sql =
            "SELECT `order`.*,user.name,user.user_to_company_id, services.service_name,employee.employee_name, statusorder.status,company.image,company.company FROM `order` INNER JOIN services ON `order`.service_id = services.id INNER JOIN user ON user.id = `order`.user_id INNER JOIN employee ON employee.id = `order`.partner_id INNER JOIN statusorder ON statusorder.id = `order`.statusOrder_id INNER JOIN company ON company.id = user.company_id WHERE statusorder.status ='do' ORDER BY `order`.create_date DESC ";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function selectOrder($order_id)
    {
        $sql = "SELECT `order`.*,user.name,user.user_to_company_id,user.phone,user.position,user.address,user.email, services.service_name,employee.employee_name, statusorder.status,company.image,company.company FROM `order` INNER JOIN services ON `order`.service_id = services.id INNER JOIN user ON user.id = `order`.user_id INNER JOIN employee ON employee.id = `order`.partner_id INNER JOIN statusorder ON statusorder.id = `order`.statusOrder_id INNER JOIN company ON company.id = user.company_id WHERE statusorder.status ='do' AND `order`.id = $order_id ";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    // ================ FLOW =============
    function getFlow($id_order)
    {
        $sql = "SELECT order_step.*, step.step,step.description FROM order_step INNER JOIN substep ON substep.id = order_step.subStep_id INNER JOIN step ON step.id = substep.step_id where order_id = $id_order ORDER BY step.id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    function getSubFlow($id_order)
    {
        $sql = "SELECT order_step.*,step.step,step.description,substep.subStep,substep.id AS sub_id,substep.step_id FROM order_step INNER JOIN substep ON substep.id = order_step.subStep_id INNER JOIN step ON step.id = substep.step_id where order_id = $id_order ORDER BY UNIX_TIMESTAMP(substep.create_date)";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getFlowByService($service_id)
    {
        $sql = "SELECT * FROM step INNER JOIN substep ON substep.step_id = step.id WHERE step.service_id = $service_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getSubFlowByService($service_id)
    {
        $sql = "SELECT step.*,substep.subStep,substep.id AS sub_id FROM step INNER JOIN substep ON substep.step_id = step.id WHERE step.service_id = $service_id ORDER BY step.step, UNIX_TIMESTAMP(substep.create_date) ";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    //============== PROCCESS =============

    public function getProcess($order_id)
    {
        $sql = "SELECT p.*,st.step,s.subStep,e.employee_name,e.image 
		FROM process p
		INNER JOIN `order` o ON o.id = p.order_id
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep s ON s.id = os.subStep_id
		INNER JOIN step st ON st.id = s.step_id
		INNER JOIN employee e ON p.employee_id = e.id
		WHERE  p.order_id = $order_id ORDER BY p.id, st.id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getProcessDone($order_id)
    {
        $sql = "SELECT p.*,st.step,s.subStep,e.employee_name,e.image 
		FROM process p
		INNER JOIN `order` o ON o.id = p.order_id
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep s ON s.id = os.subStep_id
		INNER JOIN step st ON st.id = s.step_id
		INNER JOIN employee e ON p.employee_id = e.id
		WHERE  p.order_id = $order_id AND p.status = 'done' ORDER BY p.id DESC ";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getProcessByStep($order_id)
    {
        $sql = "SELECT process.*,step.step,substep.subStep,substep.id AS subStep_id,order_step.id AS os_id,employee.employee_name,employee.image,employee.position FROM process 
		INNER JOIN order_step ON order_step.id = process.order_step_id
		INNER JOIN substep ON substep.id = order_step.subStep_id
		INNER JOIN step ON step.id = substep.step_id
		INNER JOIN employee ON employee.id = process.employee_id
		WHERE  process.id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }

    //============== OUTPUT =============

    public function getOutput($order_id)
    {
        $sql = "SELECT output.*,meeting.meeting,meeting.date,meeting.message FROM output 
				   INNER JOIN meeting ON meeting.output_id = output.id WHERE output.order_id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getOutputYes($order_id)
    {
        $sql = "SELECT output.*,meeting.meeting,meeting.date,meeting.message FROM output
				INNER JOIN meeting ON meeting.output_id = output.id WHERE output.order_id = $order_id AND output.status = 'yes'";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        return $rows;
    }
    public function getReport($order_id)
    {
        $sql = "SELECT pr.*,e.employee_name,s.subStep,p.order_step_id,rr.id AS review_id, rr.review_ceo, rr.review_supervisor, rr.review_status  FROM process_report pr
        INNER JOIN process p ON p.id = pr.process_id
        INNER JOIN employee e ON e.id = p.employee_id
        INNER JOIN order_step os ON os.id = p.order_step_id
        INNER JOIN substep s ON s.id = os.subStep_id
        INNER JOIN report_review rr ON rr.report_id = pr.id
		WHERE p.order_id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function detailReport($report_id)
    {
        $sql = "SELECT pr.*,e.employee_name,s.subStep,p.order_step_id,step.step,ser.service_name,p.order_id,ser.id AS service_id FROM process_report pr
		INNER JOIN process p ON p.id = pr.process_id
		INNER JOIN employee e ON e.id = p.employee_id
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep s ON s.id = os.subStep_id
		INNER JOIN step ON step.id = s.step_id
		INNER JOIN services ser ON ser.id = step.service_id
		WHERE pr.id = $report_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }

    public function getReview($order_id)
	{
		$sql    = "SELECT rr.*, pr.report, ss.subStep  FROM report_review rr 
		INNER JOIN process_report pr ON pr.id = rr.report_id
		INNER JOIN process p ON p.id = pr.process_id
		INNER JOIN order_step os ON  os.id = p.order_step_id
		INNER JOIN substep ss ON ss.id = os.subStep_id
		WHERE p.order_id = $order_id AND rr.message IS NOT NULL";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
    public function getReviewByReport($report_id)
	{
		$sql    = "SELECT * FROM report_review WHERE report_id = $report_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
    public function getMeeting($order_id)
    {
        $sql = "SELECT * FROM output ou 
        INNER JOIN `order` o ON o.id = ou.order_id
        INNER JOIN meeting m ON m.output_id = ou.id
        WHERE ou.order_id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getAllMeeting($order_id)
    {
        $sql = "SELECT * FROM output ou 
        INNER JOIN `order` o ON o.id = ou.order_id
        INNER JOIN meeting m ON m.output_id = ou.id
        WHERE ou.order_id = $order_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    //============== WORKFLOW =============

    public function getService($category_id)
    {
        $sql = "SELECT * FROM services WHERE category_service_id = $category_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    //============== EMPLOYEE =============

    public function getEmployee()
    {
        $sql =
            "SELECT employee.*,position.status, company.company FROM employee INNER JOIN position ON employee.status_id = position.id INNER JOIN company ON company.id = employee.company_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getEmployeeById($id)
    {
        $sql = "SELECT employee.*,position.status,company.company FROM employee INNER JOIN position ON employee.status_id = position.id INNER JOIN company ON company.id = employee.company_id WHERE employee.id = $id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getEmployeeStatus($status_id)
    {
        $sql = "SELECT employee.*,position.status FROM employee INNER JOIN position ON employee.status_id = position.id WHERE employee.status_id = $status_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    //============== RECOMMENDATION =============

    public function getServRecommendation($id)
    {
        $sql = "SELECT sr.*, s.service_name FROM service_recommendation sr INNER JOIN user u ON u.id = sr.user_id INNER JOIN services s ON s.id = sr.service_id WHERE u.id = $id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getServRecommendationById($id,$r_id)
    {
        $sql = "SELECT * FROM service_recommendation sr INNER JOIN user u ON u.id = sr.user_id INNER JOIN services s ON s.id = sr.service_id WHERE u.id = $id AND sr.id = $r_id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }

    // ========== resume ==========
    public function getResume($id)
    {
        $sql = "SELECT u.*,r.id AS resume_id, r.image FROM resume r INNER JOIN user u ON u.id = r.user_id WHERE u.id =  $id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getSubResume($id)
    {
        $sql = "SELECT sr.*, scr.id AS scr_id,scr.subCategory FROM sub_resume sr 
        INNER JOIN sub_category_resume scr ON scr.id = sr.subCategory_id 
        INNER JOIN resume r ON r.id = sr.resume_id WHERE r.user_id = $id ";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    // ========== TASK ===========

    public function getAllTask()
    {
        $sql = "SELECT s.*,e.employee_name,e.company_id, cs.category FROM specialtask s INNER JOIN employee e ON e.id = s.employee_id INNER JOIN category_specialtask cs ON cs.id = s.id_category";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function getTaskByEmployee($employee_id)
    {
        $sql = "SELECT s.*,e.employee_name,cs.category FROM specialtask s INNER JOIN employee e ON e.id = s.employee_id INNER JOIN category_specialtask cs ON cs.id = s.id_category WHERE s.employee_id = $employee_id ORDER BY s.update_date desc";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

    // ============== FEEDBACK ===============

    function dataFeedbackFromCEO($order_id)
	{
		$sql    = "SELECT feedback_from_ceo.*,employee.employee_name FROM feedback_from_ceo 
		INNER JOIN employee ON employee.id = feedback_from_ceo.employee_id
		WHERE feedback_from_ceo.order_id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
    public function getStaffFromFeedbackFromCeo($order_id)
	{
		$sql    = "SELECT * FROM feedback_criteria_from_ceo WHERE order_id = $order_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
    function detailFeedback($id)
	{
		$sql    = "SELECT feedback_from_ceo.*, employee.employee_name FROM feedback_from_ceo inner join employee on employee.id = feedback_from_ceo.employee_id WHERE feedback_from_ceo.id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
    public function getFeedback($order_id,$employee_id)
	{
		$sql    = "SELECT f.*,c.image,c.company,u.* FROM feedback_from_ceo f 
		INNER JOIN `order` o ON o.id = f.order_id
		INNER JOIN user u ON u.id = o.user_id
		INNER JOIN company c ON c.id = u.company_id
		WHERE f.order_id = $order_id AND f.employee_id = $employee_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
    
	public function getCriteria($order_id,$employee_id)
	{
		$sql    = "SELECT fc.*,c.criteria,cc.category_criteria FROM feedback_criteria_from_ceo fc
		INNER JOIN criteria c ON c.id = fc.criteria_id
		INNER JOIN category_criteria cc ON cc.id = c.category_id		
		WHERE fc.order_id = $order_id AND fc.employee_id = $employee_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
    public function totalStatusOrder($status, $id_employee)
    {
        $sql = "SELECT s.`status` FROM `order` o INNER JOIN order_staff os ON os.order_id = o.id INNER JOIN statusorder s ON s.id = o.statusOrder_id WHERE os.employee_id = $id_employee AND o.statusOrder_id = $status";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        return $rows;
    }
    public function totalStatusOrderAll($status)
    {
        $sql = "SELECT s.`status` FROM `order` o INNER JOIN statusorder s ON s.id = o.statusOrder_id INNER JOIN user ON user.id = o.user_id WHERE o.statusOrder_id = $status";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        return $rows;
    }

    public function get_spt_client($client_id, $date)
	{
		$sql    = "SELECT stc.*, st.description, st.description_en AS en, st.description_jpn AS jpn, st.description_kor AS kor, 
        st.description_cna AS cna, st.category_jumlah FROM spt_tahunan_client stc 
        INNER JOIN spt_tahunan st ON st.id = stc.spt_tahunan_id 
        INNER JOIN user u ON u.id = stc.client_id WHERE u.id = $client_id AND stc.spt_date = '$date' ORDER BY stc.spt_tahunan_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
    public function get_formula_finance($client_id, $date)
	{
		$sql    = "SELECT * FROM client_finance cf WHERE cf.client_id = $client_id AND cf.data_date = '$date'";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
    
    public function get_spt_clientDate($client_id,$date)
	{
		$sql    = "SELECT stc.*, st.description, st.description_en AS en, st.description_jpn AS jpn, st.description_kor AS kor, 
        st.description_cna AS cna, st.category_jumlah FROM spt_tahunan_client stc 
        INNER JOIN spt_tahunan st ON st.id = stc.spt_tahunan_id 
        INNER JOIN user u ON u.id = stc.client_id WHERE u.id =  $client_id AND stc.spt_date = '$date' ";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}

    //================= JOIN TABLE =================

    public function joinTwoTable($table1,$table2,$con1, $con2,$con)
    {
        $sql = "SELECT $con FROM $table1 INNER JOIN $table2 ON $table1.$con1 = $table2.$con2";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
    public function joinThreeTable($tabel1,$tabel2,$tabel3,$con1, $con2,$con3,$con)
    {
        $sql = "SELECT $con FROM $tabel1 INNER JOIN $tabel2 ON $tabel1.$con1 = $tabel2.$con2 INNER JOIN $tabel3 on $con3";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
}