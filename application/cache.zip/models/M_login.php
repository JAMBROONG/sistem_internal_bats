<?php
class M_login extends CI_Model{
	public function __construct()
	{
		parent::__construct();

	}
	function getUser($email, $password)
	{
		$sql    = "SELECT * FROM user  WHERE email = '$email' and password='$password' ";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	function getEmployee($email, $password)
	{
		$sql    = "SELECT * FROM employee  WHERE email = '$email' and password='$password'";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
}