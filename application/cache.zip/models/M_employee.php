<?php
class M_employee extends CI_Model{
	public function __construct()
	{
		parent::__construct();

	}function getEmployee($id)
	{
		$sql    = "SELECT * FROM employee  WHERE id = $id ";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	public function totalOrder($employee_id)
    {
        $sql    = "SELECT * FROM order_staff WHERE employee_id = $employee_id";
		$query  = $this->db->query($sql);
        $rows   = $query-> num_rows();
		return $rows;
	}
	public function totalDone($employee_id)
    {
        $sql    = "SELECT * FROM process WHERE employee_id = $employee_id AND status = 'done'";
		$query  = $this->db->query($sql);
        $rows   = $query-> num_rows();
		return $rows;
	}
	public function totalReport($employee_id)
    {
        $sql    = "SELECT * FROM process_report INNER JOIN process ON process.id = process_report.process_id WHERE process.employee_id = $employee_id";
		$query  = $this->db->query($sql);
        $rows   = $query-> num_rows();
		return $rows;
	}
	public function totalTable($table,$where,$employee_id)
    {
        $sql    = "SELECT * FROM $table where $where = $employee_id";
		$query  = $this->db->query($sql);
        $rows   = $query-> num_rows();
		return $rows;
	}
	public function totalFeedback($employee_id)
    {
        $sql    = "SELECT * FROM feedback WHERE employee_id = $employee_id";
		$query  = $this->db->query($sql);
        $rows   = $query-> num_rows();
		return $rows;
	}
	public function totalFeedbackOrder($order_id,$employee_id)
    {
        $sql    = "SELECT * FROM feedback WHERE employee_id = $employee_id AND order_id = $order_id";
		$query  = $this->db->query($sql);
        $rows   = $query-> num_rows();
		return $rows;
	}
	// =========== order ===========

	function dataOrder($status,$employee_id)
	{
		$sql    = "SELECT o.*, p.employee_name AS partner, m.employee_name AS manager, s.employee_name AS supervisor,se.service_name,c.company FROM `order` o 
		INNER JOIN order_staff os ON o.id = os.order_id 
		INNER JOIN employee p ON o.partner_id = p.id
		INNER JOIN employee m ON o.manager_id = m.id
		INNER JOIN employee s ON o.supervisor_id = s.id
		INNER JOIN services se ON se.id = o.service_id
		INNER JOIN user u ON u.id = o.user_id
		INNER JOIN company c ON c.id = u.company_id
		WHERE os.employee_id = $employee_id 
		AND o.statusOrder_id = $status";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getProcess($order_id,$employee_id,$status)
	{
		$sql    = "SELECT p.*,st.step,s.subStep,e.employee_name,e.image FROM process p
		INNER JOIN `order` o ON o.id = p.order_id
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep s ON s.id = os.subStep_id
		INNER JOIN step st ON st.id = s.step_id
		INNER JOIN employee e ON p.employee_id = e.id
		WHERE  p.order_id = $order_id AND p.employee_id = $employee_id AND p.status = '$status' ORDER BY p.id DESC ";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}

	// =========== report ============

	public function getReport($order_id,$id)
	{
		$sql    = "SELECT pr.*,e.employee_name,s.subStep,p.order_step_id,rr.id AS review_id, rr.review_ceo, rr.review_supervisor, rr.review_status FROM process_report pr
		INNER JOIN process p ON p.id = pr.process_id
		INNER JOIN employee e ON e.id = p.employee_id
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep s ON s.id = os.subStep_id
        INNER JOIN report_review rr ON rr.report_id = pr.id
		WHERE p.order_id = $order_id AND p.employee_id = $id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getProcessDone($order_id,$id)
	{
		$sql    = "SELECT p.*,st.step,s.subStep,e.employee_name,e.image 
		FROM process p
		INNER JOIN `order` o ON o.id = p.order_id
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep s ON s.id = os.subStep_id
		INNER JOIN step st ON st.id = s.step_id
		INNER JOIN employee e ON p.employee_id = e.id
		WHERE  p.order_id = $order_id AND p.status = 'done' AND p.employee_id = $id ORDER BY p.id DESC ";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}

	// =========== review ============

	public function reviewByCon($order_id,$employee_id)
	{
		$sql    = "SELECT rr.*, pr.report, ss.subStep  FROM report_review rr 
		INNER JOIN process_report pr ON pr.id = rr.report_id
		INNER JOIN process p ON p.id = pr.process_id
		INNER JOIN order_step os ON  os.id = p.order_step_id
		INNER JOIN substep ss ON ss.id = os.subStep_id
		WHERE p.order_id = $order_id AND p.employee_id = $employee_id AND rr.message IS NOT NULL";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}

	// =========== feedback ============

	public function getFeedback($order_id,$employee_id)
	{
		$sql    = "SELECT f.*,c.image,c.company,u.* FROM feedback f 
		INNER JOIN `order` o ON o.id = f.order_id
		INNER JOIN user u ON u.id = o.user_id
		INNER JOIN company c ON c.id = u.company_id
		WHERE f.order_id = $order_id AND f.employee_id = $employee_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> row_array();
		return $rows;
	}
	public function getCriteria($order_id,$employee_id)
	{
		$sql    = "SELECT fc.*,c.criteria,cc.category_criteria FROM feedback_criteria fc
		INNER JOIN criteria c ON c.id = fc.criteria_id
		INNER JOIN category_criteria cc ON cc.id = c.category_id		
		WHERE fc.order_id = $order_id AND fc.employee_id = $employee_id";
		$query  = $this->db->query($sql);
		$rows   = $query-> result_array();
		return $rows;
	}
	public function getAction($employee_id)
	{
		$sql = "SELECT ha.*,e.employee_name FROM history_action_employee ha INNER JOIN employee e ON e.id = ha.employee_id WHERE e.id = $employee_id ORDER BY update_date DESC";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
	}
	public function getLoginById($user_id)
	{
		$sql = "SELECT ha.*, e.employee_name FROM history_login_employee ha INNER JOIN employee e ON e.id = ha.employee_id WHERE ha.employee_id = $user_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
	}
	public function getLogin()
	{
		$sql = "SELECT * FROM history_login_employee";
        $query = $this->db->query($sql);
        $rows = $query->num_rows();
        return $rows;
	}
	public function processDeadline($user_id)
	{
		$sql = "SELECT p.*,ss.subStep, s.step FROM `order` o INNER JOIN process p ON p.order_id = o.id  
		INNER JOIN order_step os ON os.id = p.order_step_id
		INNER JOIN substep ss ON ss.id = os.subStep_id
		INNER JOIN step s ON s.id = ss.step_id 
		WHERE o.statusOrder_id = 1 AND p.`status` = 'do' AND p.employee_id = $user_id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
	}

	// ============ RESUME ===========

	public function getResume($id)
    {
        $sql = "SELECT e.*,r.id AS resume_id FROM resume r INNER JOIN employee e ON e.id = r.user_id WHERE e.id =  $id";
        $query = $this->db->query($sql);
        $rows = $query->row_array();
        return $rows;
    }
    public function getSubResume($id)
    {
        $sql = "SELECT sr.*, scr.id AS scr_id,scr.subCategory FROM sub_resume sr 
        INNER JOIN sub_category_resume scr ON scr.id = sr.subCategory_id 
        INNER JOIN resume r ON r.id = sr.resume_id WHERE r.user_id = $id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }

	// ============ DAILY REPORT ==========

	public function getDailyReport()
    {
        $sql = "SELECT d.*, e.employee_name FROM dailyreport d INNER JOIN employee e ON e.id = d.employee_id ORDER BY d.create_date";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
	public function dR_AD($date)
    {
        $sql = "SELECT d.*, e.employee_name FROM dailyreport d INNER JOIN employee e ON e.id = d.employee_id WHERE d.date = '$date' ORDER BY d.update_date";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
	public function dR_ED($id, $date)
    {
        $sql = "SELECT d.*, e.employee_name FROM dailyreport d INNER JOIN employee e ON e.id = d.employee_id WHERE e.id = $id AND d.date = '$date' ORDER BY d.id";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
	public function dR_ED_Month($id,$m, $y)
    {
        $sql = "SELECT d.*, e.employee_name FROM dailyreport d INNER JOIN employee e ON e.id = d.employee_id WHERE e.id = $id AND MONTH(date) ='$m' AND YEAR(date) ='$y' ORDER BY d.update_date";
        $query = $this->db->query($sql);
        $rows = $query->result_array();
        return $rows;
    }
}