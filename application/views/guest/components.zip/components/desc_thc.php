<div class="card">
    <div class="card-header d-flex justify-content-center bg-orange">
        <div class="card-title">Tax Health Check
</div>
    </div>
    <div class="card-body text-center">
        <div class="d-flex justify-content-between align-items-center">
            <?php
            $no = 1;
        foreach ($thc_status as $key) {
            if ($key['status'] == $thc_guest_status['status'] ) {?>
                <div class="btn border bg-orange"><?=$no.'. '.$key['status']?></div>
            <?php
            } else{
                ?>
                
            <div class="btn border"><?=$no.'. '.$key['status']?></div>
                <?php
            }
            ?>
            <?php
            if ($no < count($thc_status)) {
                echo ' <i class="fa fa-arrow-alt-circle-right"></i>';
            }
            $no++;
        }
        ?>
        </div>
        <hr>
        <h5 class="<?= $thc_guest_status['text-color'] ?>"><?= $thc_guest_status['status'] ?></h5>
        <p><?= $thc_guest_status['description'] ?></p>
        <a href="https://wa.me/628161105174" class="btn btn-sm btn-success"><i class="fab fa-whatsapp mr-2"></i> hubungi admin</a>
    </div>
</div>