<hr>
<h5 class="text-center pt-4">Pengisian NDA</h5>
<p class="text-center pb-4">silahkan download file dan tandatangani lalu upload kembali</p>
<form action="<?= site_url('Guest/uploadThc') ?>" method="post" enctype="multipart/form-data">
    <div class="row d-flex justify-content-center">
        <div class="col-md-4 mb-3">
            <div id="lk1" class="info-box mb-3 bg-warning">
                <span class="info-box-icon">
                    <i class="fas fa-upload"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-number form-file-text">Laporan Keuangan Audited (excel, pdf)</span>
                </div>
            </div>
            <input type="file" name="image1">
        </div>
        <div class="col-md-4 mb-3">
            <div id="lk1" class="info-box mb-3 bg-warning">
                <span class="info-box-icon">
                    <i class="fas fa-upload"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-number form-file-text">Buku Besar (excel, pdf)</span>
                </div>
            </div>
            <input type="file" name="image2">
        </div>
        <div class="col-md-4 mb-3">
            <div id="lk1" class="info-box mb-3 bg-warning">
                <span class="info-box-icon">
                    <i class="fas fa-upload"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-number form-file-text">SPT Masa PPN </span>
                </div>
            </div>
            <input type="file" name="image3">
        </div>
        <div class="col-md-4 mb-3">
            <div id="lk1" class="info-box mb-3 bg-warning">
                <span class="info-box-icon">
                    <i class="fas fa-upload"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-number form-file-text">SPT Masa PPh</span>
                </div>
            </div>
            <input type="file" name="image4">
        </div>
        <div class="col-md-4 mb-3">
            <div id="lk1" class="info-box mb-3 bg-warning">
                <span class="info-box-icon">
                    <i class="fas fa-upload"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-number form-file-text">SPT Tahunan PPh Badan</span>
                </div>
            </div>
            <input type="file" name="image5">
        </div>
        <div class="col-md-4 mb-3">
            <label for="">Tahun Pajak</label>
           <input type="text" class="form-control" name="tahun_check" placeholder="ex: 2010">
        </div>
    <div class="row">
        <div class="col-md-12 text-center p-3">
            <button class="btn btn-sm btn-success" type="submit"><i class="fa fa-save mr-2"></i>kirim berkas</button>
        </div>
    </div>
</form>