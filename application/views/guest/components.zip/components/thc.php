<style>
    .file {
        display: none;
    }
</style>
<hr>
<div class="card" id="thc">
    <div class="card-header d-flex justify-content-center bg-orange">
        <div class="card-title">3. Fast - Tax Health Check</div>
    </div>
    <div class="card-body">
        <h5 class="text-center pt-4">Upload Data</h5>
        <p class="text-center pb-4">data dibawah ini merupakan data yang diperlukan untuk Tax Health Check</p>
        <form action="<?= site_url('Guest/uploadThc') ?>" method="post" enctype="multipart/form-data">
            <div class="row d-flex justify-content-center">
                <div class="col-md-4">
                    <a type="button" onclick="klik1()" id="lk1" class="info-box mb-3 bg-warning">
                        <span class="info-box-icon">
                            <i class="fas fa-upload"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-number form-file-text">Laporan Keuangan Audited / Non Audited (excel, pdf)</span>
                        </div>
                    </a>
                    <div class="card" id="ds1" style="display: none ;">
                        <div class="card-body">
                            <span id="filenamelk1"></span><br>
                            <span id="filedesclk1"></span><br>
                        </div>
                    </div>
                    <input type="file" name="image1" class="file" id="file1" onchange="lk1()" required>
                </div>
                <div class="col-md-4">
                    <a type="button" onclick="klik2()" id="lk2" class="info-box mb-3 bg-warning">
                        <span class="info-box-icon">
                            <i class="fas fa-upload"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-number form-file-text">Buku Besar (wajib excel)</span>
                        </div>
                    </a>
                    <div class="card" id="ds2" style="display: none ;">
                        <div class="card-body">
                            <span id="filenamelk2"></span><br>
                            <span id="filedesclk2"></span><br>
                        </div>
                    </div>
                    <input type="file" name="image2" class="file" id="file2" onchange="lk2()" required>
                </div>

                <div class="col-md-4">
                    <a type="button" onclick="klik5()" id="lk5" class="info-box mb-3 bg-warning">
                        <span class="info-box-icon">
                            <i class="fas fa-upload"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-number form-file-text">SPT Tahunan PPh Badan (wajib pdf dan Kertas Kerja Perhitungan)</span>
                        </div>
                    </a>
                    <div class="card" id="ds5" style="display: none ;">
                        <div class="card-body">
                            <span id="filenamelk5"></span><br>
                            <span id="filedesclk5"></span><br>
                        </div>
                    </div>
                    <input type="file" name="image5" class="file" id="file5" onchange="lk5()" required>
                </div>
                <div class="col-md-4">
                    <a type="button" onclick="klik4()" id="lk4" class="info-box mb-3 bg-warning">
                        <span class="info-box-icon">
                            <i class="fas fa-upload"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-number form-file-text">SPT Masa PPh (21,23,4(2),15,22) (wajib pdf)</span>
                            <small>Januari - Desember <br> (disatukan menjadi satu file pdf atau keseluruhan disatukan dalam bentuk rar/zip)</small>
                        </div>
                    </a>
                    <div class="card" id="ds4" style="display: none ;">
                        <div class="card-body">
                            <span id="filenamelk4"></span><br>
                            <span id="filedesclk4"></span><br>
                        </div>
                    </div>
                    <input type="file" name="image4" class="file" id="file4" onchange="lk4()" required>
                </div>
                <div class="col-md-4">
                    <a type="button" onclick="klik3()" id="lk3" class="info-box mb-3 bg-warning">
                        <span class="info-box-icon">
                            <i class="fas fa-upload"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-number form-file-text">SPT Masa PPN (wajib pdf)</span>
                            <small>Januari - Desember <br> (disatukan menjadi satu file pdf atau keseluruhan disatukan dalam bentuk rar/zip)</small>
                        </div>
                    </a>
                    <div class="card" id="ds3" style="display: none ;">
                        <div class="card-body">
                            <span id="filenamelk3"></span><br>
                            <span id="filedesclk3"></span><br>
                        </div>
                    </div>
                    <input type="file" name="image3" class="file" id="file3" onchange="lk3()" required>
                </div>
                <div class="col-md-4">
                    <a type="button" onclick="klik6()" id="lk6" class="info-box mb-3 bg-warning">
                        <span class="info-box-icon">
                            <i class="fas fa-upload"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-number form-file-text">Transfer Pricing Documentation (Master and Local file) (wajib pdf)</span> <small>Abaikan jika tidak ada</small>
                        </div>
                    </a>
                    <div class="card" id="ds6" style="display: none ;">
                        <div class="card-body">
                            <span id="filenamelk6"></span><br>
                            <span id="filedesclk6"></span><br>
                        </div>
                    </div>
                    <input type="file" name="image6" class="file" id="file6" onchange="lk6()">
                </div>
                <div class="col-md-4">
                <a type="button" onclick="klik7()" id="lk7" class="info-box mb-3 bg-warning">
                    <span class="info-box-icon">
                        <i class="fas fa-upload"></i>
                    </span>
                    <div class="info-box-content">
                        <span class="info-box-number form-file-text">Daftar Penyusutan dan Amortisasi Fiskal</span>
                    </div>
                </a>
                <div class="card" id="ds7" style="display: none ;">
                    <div class="card-body">
                        <span id="filenamelk7"></span><br>
                        <span id="filedesclk7"></span><br>
                    </div>
                </div>
                <input type="file" name="image7" class="file" id="file7" onchange="lk7()" required>
            </div>
            <div class="col-md-4">
                <a type="button" onclick="klik8()" id="lk8" class="info-box mb-3 bg-warning">
                    <span class="info-box-icon">
                        <i class="fas fa-upload"></i>
                    </span>
                    <div class="info-box-content">
                        <span class="info-box-number form-file-text">Dokumen SP2DK/SPHP terbaru (pdf)</span>
                    </div>
                </a>
                <div class="card" id="ds8" style="display: none ;">
                    <div class="card-body">
                        <span id="filenamelk8"></span><br>
                        <span id="filedesclk8"></span><br>
                    </div>
                </div>
                <input type="file" name="image8" class="file" id="file8" onchange="lk8()" required>
            </div>
            <div class="col-md-4">
                <a type="button" onclick="klik9()" id="lk9" class="info-box mb-3 bg-warning">
                    <span class="info-box-icon">
                        <i class="fas fa-upload"></i>
                    </span>
                    <div class="info-box-content">
                        <span class="info-box-number form-file-text">Kertas Kerja Perhitungan Aset Tetap (wajib excel)</span>
                    </div>
                </a>
                <div class="card" id="ds9" style="display: none ;">
                    <div class="card-body">
                        <span id="filenamelk9"></span><br>
                        <span id="filedesclk9"></span><br>
                    </div>
                </div>
                <input type="file" name="image9" class="file" id="file9" onchange="lk9()" required>
            </div>
            </div>
            <div class="col-md-4 mb-3">
                <label for="">Tahun Pajak</label>
                <input type="text" class="form-control" name="tahun_check" placeholder="ex: 2010" required>
            </div>
            <div class="row">
                <div class="col-md-12 text-center p-3">
                    <button class="btn btn-sm btn-success" type="submit"><i class="fa fa-save mr-2"></i>kirim berkas</button>
                </div>
            </div>
        </form>
    </div>
</div>


<script>
    function klik1() {
        var file = document.getElementById('file1');
        file.click();
    }

    function klik2() {
        var file = document.getElementById('file2');
        file.click();
    }

    function klik3() {
        var file = document.getElementById('file3');
        file.click();
    }

    function klik4() {
        var file = document.getElementById('file4');
        file.click();
    }

    function klik5() {
        var file = document.getElementById('file5');
        file.click();
    }

    function klik6() {
        var file = document.getElementById('file6');
        file.click();
    }

    function klik7() {
        var file = document.getElementById('file7');
        file.click();
    }

    function klik8() {
        var file = document.getElementById('file8');
        file.click();
    }

    function klik9() {
        var file = document.getElementById('file9');
        file.click();
    }

    function lk1() {
        var fileName = document.getElementById('file1')
            .files[0].name;
        var fileSize = document.getElementById('file1')
            .files[0].size;
        document.getElementById('ds1')
            .style.display = "block";
        document.getElementById('lk1')
            .style.display = "none";
        document.getElementById('filenamelk1')
            .innerHTML = fileName;
        document.getElementById('filedesclk1')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }

    function lk2() {
        var fileName = document.getElementById('file2')
            .files[0].name;
        var fileSize = document.getElementById('file2')
            .files[0].size;
        document.getElementById('ds2')
            .style.display = "block";
        document.getElementById('lk2')
            .style.display = "none";
        document.getElementById('filenamelk2')
            .innerHTML = fileName;
        document.getElementById('filedesclk2')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }

    function lk3() {
        var fileName = document.getElementById('file3')
            .files[0].name;
        var fileSize = document.getElementById('file3')
            .files[0].size;
        document.getElementById('ds3')
            .style.display = "block";
        document.getElementById('lk3')
            .style.display = "none";
        document.getElementById('filenamelk3')
            .innerHTML = fileName;
        document.getElementById('filedesclk3')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }

    function lk4() {
        var fileName = document.getElementById('file4')
            .files[0].name;
        var fileSize = document.getElementById('file4')
            .files[0].size;
        document.getElementById('ds4')
            .style.display = "block";
        document.getElementById('lk4')
            .style.display = "none";
        document.getElementById('filenamelk4')
            .innerHTML = fileName;
        document.getElementById('filedesclk4')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }

    function lk5() {
        var fileName = document.getElementById('file5')
            .files[0].name;
        var fileSize = document.getElementById('file5')
            .files[0].size;
        document.getElementById('ds5')
            .style.display = "block";
        document.getElementById('lk5')
            .style.display = "none";
        document.getElementById('filenamelk5')
            .innerHTML = fileName;
        document.getElementById('filedesclk5')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }

    function lk6() {
        var fileName = document.getElementById('file6')
            .files[0].name;
        var fileSize = document.getElementById('file6')
            .files[0].size;
        document.getElementById('ds6')
            .style.display = "block";
        document.getElementById('lk6')
            .style.display = "none";
        document.getElementById('filenamelk6')
            .innerHTML = fileName;
        document.getElementById('filedesclk6')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }

    function lk7() {
        var fileName = document.getElementById('file7')
            .files[0].name;
        var fileSize = document.getElementById('file7')
            .files[0].size;
        document.getElementById('ds7')
            .style.display = "block";
        document.getElementById('lk7')
            .style.display = "none";
        document.getElementById('filenamelk7')
            .innerHTML = fileName;
        document.getElementById('filedesclk7')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }
    
    function lk8() {
        var fileName = document.getElementById('file8')
            .files[0].name;
        var fileSize = document.getElementById('file8')
            .files[0].size;
        document.getElementById('ds8')
            .style.display = "block";
        document.getElementById('lk8')
            .style.display = "none";
        document.getElementById('filenamelk8')
            .innerHTML = fileName;
        document.getElementById('filedesclk8')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }
    function lk9() {
        var fileName = document.getElementById('file9')
            .files[0].name;
        var fileSize = document.getElementById('file9')
            .files[0].size;
        document.getElementById('ds9')
            .style.display = "block";
        document.getElementById('lk9')
            .style.display = "none";
        document.getElementById('filenamelk9')
            .innerHTML = fileName;
        document.getElementById('filedesclk9')
            .innerHTML = '(' + fileSize / 1000 + "kb)";
    }
</script>