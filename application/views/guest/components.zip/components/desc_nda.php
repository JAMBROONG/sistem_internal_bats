<div id="nda" class="row d-flex justify-content-center mb-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-orange d-flex justify-content-center ">
                <div class="card-title">1. NDA</div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 text-center">
                        <h6><?= $thc_nda['nda'] ?></h6>
                        <a href="<?=base_url()?>assets/upload/nda/<?= $thc_nda['nda'] ?>" class="card-text">download</a>
                    </div>
                    
                    <div class="col-md-6 text-center">
                        <h6>Upload Date</h6>
                        <?= (date('Y-m-d', strtotime($thc_nda['upload_date'])) == date('Y-m-d')) ? '<small class="text-success text-bold">today ' .date('G:i a', strtotime($thc_nda['upload_date'])).'</small>' : '<small>'.date('F j, Y G:i:s a', strtotime($thc_nda['upload_date'])).'</small>'?>
                    </div>
                </div>
            </div>
        </div>
        <p class="text-center text-sm">any problem? contact to <a href="https://wa.me/628161105174" target="blank">admin</a></p>
    </div>
</div>