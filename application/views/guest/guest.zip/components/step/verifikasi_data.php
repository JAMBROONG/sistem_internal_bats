<div class="row">
    <div class="col-md-6">
        <?php include 'list_file.php' ?>
    </div>
    <div class="col-md-6">
        <div class="p-5">
            <h5 class="<?= $thc_guest_status['text-color'] ?>"><?= $thc_guest_status['status'] ?></h5>
            <p><?= $thc_guest_status['description'] ?></p>
            <a href="https://wa.me/628161105174" class="btn btn-sm btn-success">
                <i class="fab fa-whatsapp mr-2"></i>
                contact to admin</a>
        </div>
    </div>
</div>