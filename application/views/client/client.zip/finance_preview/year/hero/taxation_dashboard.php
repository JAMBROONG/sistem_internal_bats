
<div class="bg-light">
    <?php $this->load->view('elements/element_table_tax_client_year.php');?>
</div>

<script>
const selectedBtn = document.getElementById("td");
selectedBtn.classList.remove("btn-light");
selectedBtn.classList.add("btn-dark");
</script>