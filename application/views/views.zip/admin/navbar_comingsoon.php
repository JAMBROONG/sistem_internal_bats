
<li class="nav-item">
    <a href="#" class="nav-link text-warning">
    <i class="nav-icon fas fa-tools"></i>
    <p>
        Coming Soon
        <i class="right fas fa-angle-left"></i>
    </p>
    </a>
    <ul class="nav nav-treeview" style="display: none;">
        <li class="nav-item">
            <a href="<?php echo base_url('Admin/training'); ?>" class="nav-link">
                <i class="nav-icon fa fa-chalkboard-teacher"></i>
                <p> Training</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo base_url('Admin/taxUpdate'); ?>" class="nav-link">
                <i class="nav-icon fa fa-newspaper"></i>
                <p> TAX Update </p>
                </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo base_url('Admin/accountingUpdate'); ?>" class="nav-link">
                <i class="nav-icon fab fa-airbnb"></i>
                <p> Accounting Update</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo base_url('Admin/employeeScore'); ?>" class="nav-link">
                <i class="nav-icon fa fa-star"></i>
                <p> Employee Score </p>
            </a>
        </li>
    </ul>
</li>