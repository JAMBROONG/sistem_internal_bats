<div class="card" id="thc">
<div class="card-header text-white"   style="background-color: #2F2F2F;">
        <div class="card-title">3. Fast - Tax Health Check</div>
        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus text-white"></i>
            </button>
        </div>
    </div>
    <div class="card-body">
        <p class="text-center text-danger">access is not yet available</p>
    </div>
</div>
<script src="<?=base_url()?>assets/dist/js/thc.js"></script>