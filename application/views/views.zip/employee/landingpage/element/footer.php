<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright
            <strong>
                <span>2022 BATS Consulting</span></strong>.
        </div>
        <div class="credits">
            Designed by
            <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
    </div>
</footer>

<a href="#"
    class="back-to-top d-flex align-items-center justify-content-center">
    <i class="bi bi-arrow-up-short"></i>
</a>

<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="<?=base_url()?>assets/landingpage/assets/vendor/aos/aos.js"></script>
<script
    src="<?=base_url()?>assets/landingpage/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script
    src="<?=base_url()?>assets/landingpage/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script
    src="<?=base_url()?>assets/landingpage/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script
    src="<?=base_url()?>assets/landingpage/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script
    src="<?=base_url()?>assets/landingpage/assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="<?=base_url()?>assets/landingpage/assets/js/main.js"></script>