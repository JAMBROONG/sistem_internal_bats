<li class="nav-item">
    <a href="#" class="nav-link text-warning">
    <i class="nav-icon fas fa-tools"></i>
    <p>
        Coming Soon
        <i class="right fas fa-angle-left"></i>
    </p>
    </a>
    <ul class="nav nav-treeview" style="display: none;">
        <li class="nav-item">
            <a href="#>" class="nav-link disabled" >
                <i style="color: #eeeef0;" class="nav-icon fa fa-newspaper"></i>
                <p style="color: #eeeef0;"> TAX Update </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link disabled">
                <i style="color: #eeeef0;" class="nav-icon fab fa-airbnb"></i>
                <p style="color: #eeeef0;"> Accounting Update</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link disabled">
                <i style="color: #eeeef0;" class="nav-icon fa fa-star"></i>
                <p style="color: #eeeef0;"> Employee Score </p>
            </a>
        </li>
    </ul>
</li>