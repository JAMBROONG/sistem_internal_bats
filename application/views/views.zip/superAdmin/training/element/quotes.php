<section id="cta" class="cta">
    <div class="container" data-aos="zoom-in">
        <div class="text-center">
            <h3>Lemony Snicket</h3>
            <p> Kalau mau menunggu hingga siap, kita akan menghabiskan waktu hidup kita hanya untuk menunggu.</p>
        </div>
    </div>
</section>