<?php
function format_angka($angka) {
  $satuan = ['', 'k', 'M', 'B', 'T', 'Q', 'Qt', 'Sx', 'Sp', 'Oc', 'No', 'De'];
  $ukuran = count($satuan) - 1;
  $i = 0;
  $abs_angka = abs($angka);
  if ($angka < 0) {
    $tanda = '-';
  } else {
    $tanda = '';
  }
  while ($abs_angka >= 1000 && $i < $ukuran) {
    $abs_angka /= 1000;
    $i++;
  }
  return 'Rp. '. $tanda . round($abs_angka, 1) . '' . $satuan[$i];
} 

function getcolor($num)
{
  if ($num < 0) {
    return array(
      'color' => 'text-danger',
      'bg_color' => 'bg-danger',
      'hex' => '#D82724',
      'num' => $num
    );
  } if ($num == 0) {
    return array(
      'color' => 'text-dark',
      'bg_color' => 'bg-dark',
      'hex' => '#000000',
      'num' => $num
    );
  } 
  else{
    return array(
      'color' => 'text-success',
      'bg_color' => 'bg-success',
      'hex' => '#24D627',
      'num' => '+'.$num
    );
  }
}

function getvalknob($num)
{
  if ($num < 0) {
    return array(
      'max' => 100,
      'min' => $num
    );
  } if ($num > 100) {
    return array(
      'max' => $num,
      'min' => 0
    );
  } 
  else{
    return array(
      'max' => 100,
      'min' => 0
    );
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="icon" href="<?php echo base_url(); ?>assets/image/logo/icon.png" />
    <?php $this->load->view('client/header'); ?>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/adminlte.min.css">

    <script src="<?php echo base_url();?>assets/plugins/jquery/jquery.min.js"></script>
    <script nonce="undefined" src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.bundle.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/jquery-knob/jquery.knob.min.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>

    <style>
        .select2-results__options li {
            color: black;
        }

        .quote-card {
            background: #fff;
            color: #222222;
            padding: 20px;
            padding-left: 50px;
            box-sizing: border-box;
            box-shadow: 0 2px 4px rgba(34, 34, 34, 0.12);
            position: relative;
            overflow: hidden;
            min-height: 120px;
        }

        .quote-card p {
            /* font-size: 22px; */
            line-height: 1.5;
            margin: 0;
            max-width: 80%;
        }

        .quote-card cite {
            font-size: 16px;
            margin-top: 10px;
            display: block;
            font-weight: 200;
            opacity: 0.8;
        }

        .quote-card:before {
            font-family: Georgia, serif;
            content: "“";
            position: absolute;
            top: 10px;
            left: 10px;
            font-size: 5em;
            color: rgba(238, 238, 238, 0.8);
            font-weight: normal;
        }

        .quote-card:after {
            font-family: Georgia, serif;
            content: "”";
            position: absolute;
            bottom: -110px;
            line-height: 100px;
            right: -32px;
            font-size: 25em;
            color: rgba(238, 238, 238, 0.8);
            font-weight: normal;
        }

        @media (max-width: 640px) {
            .quote-card:after {
                font-size: 22em;
                right: -25px;
            }
        }
    </style>
</head>
<?php
    $url = "https://www.bats-consulting.com/news/";
?>

<body class="hold-transition bg-dark">
    <div class="wrapper">
        <?php $this->load->view('client/navbar'); ?>
        <div class="content-wrapper bg-white">
            <section class="content">
                <div class="m-1 m-lg-5" id="cash_md">
                    <div class="card rounded-0 text-left">
                        <div class="card-body">
                            <h6>Displays the financial dashboard of <b><?=$user['company']?></b> </h6>
                            <hr>
                            <div class="d-flex justify-content-between flex-column flex-lg-row">
                                <table>
                                    <tr>
                                        <td>Type</td>
                                        <td>: <b class="bg-warning rounded" style="padding:3px; font-size:12px">Monthly</b></td>
                                    </tr>
                                    <tr>
                                        <td>Date</td>
                                        <td>: <b> <?= date('F, Y' , strtotime($date)) ?></b></td>
                                    </tr>
                                </table>
                                <div class="form-group">
                                    <label for=""></label>

                                    <select class="js-example-basic-single" style="width:100%;" name="date" id="id_month" onchange="redirectToPage()">
                                    
                                    <option value="<?= date('Y-m', strtotime($date)) ?>"><?= date('F Y', strtotime($date))?></option>
                                            <?php
                                    foreach ($list_month as $key) {
                                        if ($key['bulan'] == $date.'-02') {
                                            continue;
                                        }
                                        ?>
                                            <option value="<?= date('Y-m', strtotime($key['bulan'])) ?>"><?= date('F Y', strtotime($key['bulan']))?></option>
                                            <?php
                                    }
                                    ?>
                                        </select>                                    
                                        <small id="helpId" class="text-muted">Change Date</small>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end">

                            </div>
                        </div>

                    </div>
                </div>
                <div class="m-lg-5">
                    <div class="card card-dark card-tabs shadow-none">
                        <div class="card-header p-2">
                            <ul class="nav nav-tabs d-flex border-0 flex-column flex-lg-row justify-content-around" id="custom-tabs-one-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="rounded nav-link active" id="tab1" data-toggle="pill" href="#tab_cmd" role="tab" aria-controls="tab_cmd" aria-selected="true">Cash Management Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="rounded nav-link" id="tab2" data-toggle="pill" href="#tab_fkd" role="tab" aria-controls="tab_fkd" aria-selected="false">Financial KPI Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="rounded nav-link" id="tab3" data-toggle="pill" href="#tab_pald" role="tab" aria-controls="tab_pald" aria-selected="false">Profit and Loss Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="rounded nav-link" id="tab4" data-toggle="pill" href="#tab_cd" role="tab" aria-controls="tab_cd" aria-selected="false">CFO Dashboard</a>
                                </li>
                                <li class="nav-item">
                                    <a class="rounded nav-link" id="tab5" data-toggle="pill" href="#tab_fpd" role="tab" aria-controls="tab_fpd" aria-selected="false">Financial Performance Dashboard</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body p-0 pt-3">
                            <div class="tab-content" id="custom-tabs-one-tabContent">
                                <div class="tab-pane fade active show" id="tab_cmd" role="tabpanel" aria-labelledby="tab1">
                                    <?php include 'hero/cash_management_dashboard.php'; ?>
                                </div>
                                <div class="tab-pane fade" id="tab_fkd" role="tabpanel" aria-labelledby="tab2">
                                    <?php include 'hero/financial_kpi_dashboard.php';?>
                                </div>
                                <div class="tab-pane fade" id="tab_pald" role="tabpanel" aria-labelledby="tab3">
                                    <?php include 'hero/profit_and_loss_dashboard.php'; ?>
                                </div>
                                <div class="tab-pane fade" id="tab_cd" role="tabpanel" aria-labelledby="tab4">
                                    <?php include 'hero/cfo_dashboard.php'; ?>
                                </div>
                                <div class="tab-pane fade" id="tab_fpd" role="tabpanel" aria-labelledby="tab5">
                                    <?php include 'hero/finance_peformance_dashboard.php'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="m-1 m-lg-5">
                    <div class="text-center bg-dark pb-3 pt-3">
                        <h1 class=" d-none d-md-block">OUR RECOMMENDATION</h1>
                        <h6 class="d-md-none">OUR RECOMMENDATION</h6>
                    </div>
                    <?php $this->load->view('elements/our_recommendationClient.php');?>
                    <div class="text-center bg-dark pb-3 pt-3">
                        <h1 class=" d-none d-md-block">DATA TAX</h1>
                        <h6 class="d-md-none">DATA TAX</h6>
                    </div>
                    <div class="bg-light">
                        <?php $this->load->view('elements/element_table_tax_client.php');?>
                    </div>
                </div>

            </section>
        </div>
        <footer class="main-footer">
            <strong>Copyright &copy; 2022
                <a href="https://bats-consulting.com/">Bats Consulting</a>.</strong>
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b>
                1.0
            </div>
        </footer>
        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    </div>
    <script src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        function fun_submit(x, y) {
            var y = document.getElementById(y).value;
            if (y == "") {
                alert('Field tidak boleh kosong');
            } else {
                $(x).submit();
            }
        }

        function redirectToPage() {
            var bulan = document.getElementById("id_month").value;
            window.location.href = "<?= base_url()?>Finance_client/finance_month?type=month&date=" + bulan + '&show=<?=md5('5g7d8fyyes5g7d8fy')?>';
        }
        $('#nav_financial_dashboard').addClass('nav_select');
        $(document).ready(function() {
            $('.js-example-basic-single').select2();
        });
    </script>
</body>

</html>