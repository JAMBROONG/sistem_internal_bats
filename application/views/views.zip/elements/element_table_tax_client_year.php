
<style>
    .checkbox {
  display: block;
  position: relative;
  padding-left: 30px;
  margin-bottom: 20px;
  cursor: pointer;
  font-size: 16px;
  user-select: none;
}

.checkbox input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

.checkmark {
  position: absolute;
  left: 2px;
  height: 20px;
  width: 20px;
  background-color: #eee;
  border-radius: 4px;
}

.checkbox:hover input ~ .checkmark {
  background-color: #ccc;
}

.checkbox input:checked ~ .checkmark {
  background-color: #2196F3;
}

.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

.checkbox input:checked ~ .checkmark:after {
  display: block;
}

.checkbox .checkmark:after {
  left: 7px;
  top: 3px;
  width: 6px;
  height: 12px;
  border: solid white;
  border-width: 0 3px 3px 0;
  transform: rotate(45deg);
}
</style>
<?php
if (empty($this->M_table->getByCon("tax_client_year","date", "'".$date . "' AND user_id = " . $user_id))) {?>
<div class="alert alert-default" role="alert">
  <h4 class="alert-heading text-center">Sorry, data not yet available</h4>
</div>
<?php
} else {
  $dataNew = $this->M_table->joinTwoTable("jenis_pajak","tax_client_year","id","jenis_pajak_id AND tax_client_year.date = '".$date."'  AND user_id = " .$user_id,"*")[0];
?>
<form action="<?=base_url('Finance_client/update_tax_year')?>" id="formPerpajakan" method="post" class="form bg-white">
<input type="hidden" name="date" value="<?=$date?>">
<input type="hidden" value="<?=$dataNew['id']?>" name="id">
<input type="hidden" value="<?=$dataNew['batas_pembayaran']?>" name="batas_pembayaran">
<input type="hidden" value="<?=$dataNew['batas_pelaporan']?>" name="batas_pelaporan">
<div class="card text-white mt-3 rounded-0"  style="background-color:#<?=$this->M_table->getByCon("color_theme","name","'color1'")['code'];?>">
  <div class="card-body text-center">
    <h4>Corporate Income Tax normal rate 22%</h4>
    Transaction Date
    <input type="date" name="tanggal_transaksi" value="<?=$dataNew['tanggal_transaksi']?>" class="border rounded" id="">
    <div class="row">
      <div class="col-md-6">

      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
    <div class="card mt-3 rounded-0">
      <div class="card-header text-white"  style="background-color:#<?=$this->M_table->getByCon("color_theme","name","'color1'")['code'];?>">
        <div class="card-title">
        Payment
        </div>
      </div>
      <div class="card-body">
        <div class="mb-3">
          <label>Payment status</label>
          <div class="p-2 bg-light">
            
          <?= $dataNew['status_pembayaran'] ?>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="">Payment Date</label>
              <input type="date" name="tanggal_bayar"  value="<?=$dataNew['tanggal_bayar']?>" class="form-control" placeholder="" aria-describedby="helpId">
            </div>
            <div class="form-group">
              <label for="">Payment (Rp.)</label>
              <input type="text"  name="nominal_pembayaran"  value="Rp. <?= number_format($dataNew['nominal_pembayaran'], 0, ',', '.'); ?>" class="form-control text-right" placeholder="" aria-describedby="helpId">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="">Payment Limit</label>
              <div class="form-control bg-light">
              <?php
                if ($dataNew['batas_pembayaran'] == '0000-00-00') {
                    echo '-';
                } else{
                    echo date('d-m-Y', strtotime($dataNew['batas_pembayaran']));
                }
                ?>
              </div>
            </div>
            <div class="form-group">
              <label for="">NTPN</label>
              <input type="text" name="ntpn" value="<?=$dataNew['ntpn']?>" class=" form-control text-right" placeholder="" aria-describedby="helpId">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mt-3 rounded-0">
      <div class="card-header text-white"  style="background-color:#<?=$this->M_table->getByCon("color_theme","name","'color1'")['code'];?>">
        <div class="card-title">
         Reporting
        </div>
      </div>
      <div class="card-body">
        <div class="mb-3">
          <label>Reporting Status</label>
          <div class="p-2 bg-light">
            
          <?= $dataNew['status_pelaporan'] ?>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="">Report Date</label>
              <input type="date" name="tanggal_pelaporan"  value="<?=$dataNew['tanggal_pelaporan']?>" class="form-control" placeholder="" aria-describedby="helpId">
            </div>
            <div class="form-group">
              <label for="">Reporting (Rp.)</label>
              <input type="text"  name="nominal_pelaporan"  value="Rp. <?= number_format($dataNew['nominal_pelaporan'], 0, ',', '.'); ?>" class="form-control text-right" placeholder="" aria-describedby="helpId">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="">Reporting Limits</label>
              <div class="form-control bg-light">
              <?php
                if ($dataNew['batas_pelaporan'] == '0000-00-00') {
                    echo '-';
                } else{
                    echo date('d-m-Y', strtotime($dataNew['batas_pelaporan']));
                }
                ?>
              </div>
            </div>
            <div class="form-group">
              <label for="">No. BPE</label>
              <input type="text" name="bpe" value="<?=$dataNew['bpe']?>" class="form-control text-right" placeholder="" aria-describedby="helpId">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> 
<button type="submit" id="btnPerpajakan" form="formPerpajakan" class="btn btn-sm btn-success mt-3" style="width:auto;" onclick="disableButton2(this)"><i class="fa fa-save mr-2"></i>Save Tax Data</button>
</form>
<?php
}
?>